import sql from "@/app/api/utils/sql";
import { getUserIdFromRequest } from "@/app/api/utils/validate-token";

export async function GET(request) {
  try {
    // Validate bearer token from Authorization header
    const authUserId = await getUserIdFromRequest(request);

    if (!authUserId) {
      return Response.json(
        { ok: false, error: "Invalid or expired token" },
        { status: 401 },
      );
    }

    // Get user info
    const users = await sql`
      SELECT id, email, name
      FROM auth_users
      WHERE id = ${authUserId}
      LIMIT 1
    `;

    if (users.length === 0) {
      return Response.json(
        { ok: false, error: "User not found" },
        { status: 404 },
      );
    }

    const user = users[0];

    return Response.json({
      ok: true,
      user: {
        id: String(user.id),
        email: user.email,
        name: user.name,
      },
    });
  } catch (error) {
    console.error("Mobile me endpoint error:", error);
    return Response.json(
      { ok: false, error: "Failed to validate session" },
      { status: 500 },
    );
  }
}
