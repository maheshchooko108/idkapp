import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { userId, missionId, proofType, proofText, proofMediaUrl } = body;

    if (!userId) {
      return Response.json({ error: "User ID is required" }, { status: 400 });
    }

    if (!missionId) {
      return Response.json(
        { error: "Mission ID is required" },
        { status: 400 },
      );
    }

    if (!proofText || proofText.trim().length < 10) {
      return Response.json(
        {
          error: "Please write at least a short reflection about what you did",
        },
        { status: 400 },
      );
    }

    // Find the in_progress record
    const existing = await sql`
      SELECT id, status FROM user_progress
      WHERE user_id = ${userId}
      AND mission_id = ${missionId}
      AND DATE(completed_at) = CURRENT_DATE
      AND status = 'in_progress'
    `;

    if (existing.length === 0) {
      return Response.json(
        {
          error: "Mission not started or already submitted",
        },
        { status: 400 },
      );
    }

    // Update to pending_approval
    await sql`
      UPDATE user_progress
      SET 
        status = 'pending_approval',
        completion_requested_at = NOW(),
        proof_type = ${proofType || "none"},
        proof_text = ${proofText},
        proof_media_url = ${proofMediaUrl || null}
      WHERE id = ${existing[0].id}
    `;

    return Response.json({
      ok: true,
      message: "Completion request sent to your parent!",
    });
  } catch (error) {
    console.error("Error requesting completion:", error);
    return Response.json(
      { error: "Failed to request completion" },
      { status: 500 },
    );
  }
}
