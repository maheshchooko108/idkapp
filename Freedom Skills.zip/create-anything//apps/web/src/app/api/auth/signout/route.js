import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const formData = await request.formData();
    const callbackUrl = formData.get("callbackUrl") || "/account/signin";

    // Get session token from cookie
    const cookies = request.headers.get("cookie") || "";
    const sessionToken = cookies
      .split(";")
      .find((c) => c.trim().startsWith("next-auth.session-token="))
      ?.split("=")[1];

    if (sessionToken) {
      // Delete session
      await sql`
        DELETE FROM auth_sessions WHERE "sessionToken" = ${sessionToken}
      `;
    }

    // Clear cookie and redirect
    return new Response(null, {
      status: 302,
      headers: {
        "Set-Cookie":
          "next-auth.session-token=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0",
        Location: callbackUrl,
      },
    });
  } catch (error) {
    console.error("Signout error:", error);
    return new Response(null, {
      status: 302,
      headers: {
        "Set-Cookie":
          "next-auth.session-token=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0",
        Location: "/account/signin",
      },
    });
  }
}
