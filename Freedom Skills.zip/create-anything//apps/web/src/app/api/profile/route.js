import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user already has a profile
    const users = await sql`
      SELECT 
        u.id,
        u.name,
        u.role,
        u.family_id,
        u.avatar_emoji,
        f.family_code
      FROM users u
      LEFT JOIN families f ON u.family_id = f.id
      WHERE u.auth_user_id = ${session.user.id}
      LIMIT 1
    `;

    if (users.length === 0) {
      return Response.json({ hasProfile: false });
    }

    return Response.json({
      hasProfile: true,
      userId: users[0].id,
      name: users[0].name,
      role: users[0].role,
      familyId: users[0].family_id,
      familyCode: users[0].family_code,
      avatarEmoji: users[0].avatar_emoji,
    });
  } catch (error) {
    console.error("Error loading profile:", error);
    return Response.json({ error: "Failed to load profile" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { userId } = body;

    if (!userId) {
      return Response.json({ error: "User ID is required" }, { status: 400 });
    }

    // Link the user profile to the auth user
    await sql`
      UPDATE users
      SET auth_user_id = ${session.user.id}
      WHERE id = ${userId}
    `;

    return Response.json({ success: true });
  } catch (error) {
    console.error("Error updating profile:", error);
    return Response.json(
      { error: "Failed to update profile" },
      { status: 500 },
    );
  }
}
