import sql from "@/app/api/utils/sql.js";
import { auth } from "@/auth.js";
import { getUserIdFromRequest } from "@/app/api/utils/validate-token.js";

export async function GET(request) {
  try {
    // Try mobile token auth first
    let authUserId = await getUserIdFromRequest(request);

    // Fall back to web session auth
    if (!authUserId) {
      const session = await auth();
      if (session?.user?.id) {
        authUserId = String(session.user.id);
      }
    }

    if (!authUserId) {
      return Response.json(
        { ok: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    const families = await sql`
      SELECT id, family_code, parent_name, created_at
      FROM families
      WHERE auth_user_id = ${authUserId}
      LIMIT 1
    `;

    if (families.length === 0) {
      return Response.json(
        { ok: false, error: "No family found" },
        { status: 404 },
      );
    }

    const family = families[0];

    // Get the parent user record
    const parentUsers = await sql`
      SELECT id, name, role
      FROM users
      WHERE family_id = ${family.id} AND role = 'parent'
      LIMIT 1
    `;

    // Get children in this family (including child_join_code and is_active)
    const children = await sql`
      SELECT id, name, avatar_emoji, child_join_code, is_active, created_at
      FROM users
      WHERE family_id = ${family.id} AND role = 'child'
      ORDER BY created_at ASC
    `;

    return Response.json({
      ok: true,
      family: {
        id: family.id,
        familyCode: family.family_code,
        parentName: family.parent_name,
        createdAt: family.created_at,
        parentUserId: parentUsers.length > 0 ? parentUsers[0].id : null,
        children: children.map((child) => ({
          id: child.id,
          name: child.name,
          avatarEmoji: child.avatar_emoji,
          childJoinCode: child.child_join_code,
          isActive: child.is_active,
          createdAt: child.created_at,
        })),
      },
    });
  } catch (error) {
    console.error("Error loading family:", error);
    return Response.json(
      { ok: false, error: "Failed to load family" },
      { status: 500 },
    );
  }
}
