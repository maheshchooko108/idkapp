import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const familyId = searchParams.get("familyId");
    const childId = searchParams.get("childId");

    if (!familyId) {
      return Response.json({ error: "familyId is required" }, { status: 400 });
    }

    if (!childId) {
      return Response.json({ error: "childId is required" }, { status: 400 });
    }

    // Get parent for this family
    const parents = await sql`
      SELECT id, name, role
      FROM users
      WHERE family_id = ${familyId}
      AND role = 'parent'
      AND is_active = true
      LIMIT 1
    `;

    const resolvedParentUserId = parents.length > 0 ? parents[0].id : null;

    // Get last 20 messages involving this child
    const messages = await sql`
      SELECT 
        fm.id,
        fm.from_user_id,
        fm.to_user_id,
        fm.message_text,
        fm.created_at,
        u_from.name as from_user_name,
        u_to.name as to_user_name
      FROM family_messages fm
      LEFT JOIN users u_from ON u_from.id = fm.from_user_id
      LEFT JOIN users u_to ON u_to.id = fm.to_user_id
      WHERE fm.family_id = ${familyId}
      AND (fm.from_user_id = ${childId} OR fm.to_user_id = ${childId})
      ORDER BY fm.created_at DESC
      LIMIT 20
    `;

    return Response.json({
      ok: true,
      debug: {
        familyId: parseInt(familyId),
        childId: parseInt(childId),
        resolvedParentUserId,
        parentData: parents[0] || null,
        messagesCount: messages.length,
        messages: messages.map((m) => ({
          id: m.id,
          from_user_id: m.from_user_id,
          from_user_name: m.from_user_name,
          to_user_id: m.to_user_id,
          to_user_name: m.to_user_name,
          message_text: m.message_text,
          created_at: m.created_at,
        })),
      },
    });
  } catch (error) {
    console.error("Error in messages-sanity debug endpoint:", error);
    return Response.json(
      { error: "Failed to fetch debug data", details: error.message },
      { status: 500 },
    );
  }
}
