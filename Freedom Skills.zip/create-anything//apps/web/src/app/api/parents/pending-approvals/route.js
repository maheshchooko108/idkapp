import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const familyId = searchParams.get("familyId");

    if (!familyId) {
      return Response.json({ error: "Family ID is required" }, { status: 400 });
    }

    // Get all pending approvals for this family's children
    const pendingApprovals = await sql`
      SELECT 
        up.id,
        up.user_id,
        up.mission_id,
        up.completed_at,
        up.completion_requested_at,
        up.proof_type,
        up.proof_text,
        up.proof_media_url,
        u.name as child_name,
        u.avatar_emoji,
        m.title as mission_title,
        m.description as mission_description,
        m.xp_reward,
        m.difficulty
      FROM user_progress up
      JOIN users u ON u.id = up.user_id
      JOIN missions m ON m.id = up.mission_id
      WHERE u.family_id = ${familyId}
      AND up.status = 'pending_approval'
      ORDER BY up.completion_requested_at DESC
    `;

    return Response.json(pendingApprovals);
  } catch (error) {
    console.error("Error fetching pending approvals:", error);
    return Response.json(
      { error: "Failed to fetch pending approvals" },
      { status: 500 },
    );
  }
}
