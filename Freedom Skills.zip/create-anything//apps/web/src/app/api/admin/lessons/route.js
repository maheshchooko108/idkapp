import sql from "@/app/api/utils/sql";
import { requireAdmin } from "@/app/api/utils/admin-auth";

// GET all lessons (admin only)
export async function GET(request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const lessons = await sql`
      SELECT 
        id,
        title,
        category,
        body_text,
        youtube_url,
        is_active,
        created_at,
        updated_at
      FROM practice_lessons
      ORDER BY created_at DESC
    `;

    return Response.json({
      ok: true,
      lessons: lessons.map((lesson) => ({
        id: lesson.id,
        title: lesson.title,
        category: lesson.category,
        bodyText: lesson.body_text,
        youtubeUrl: lesson.youtube_url,
        isActive: lesson.is_active,
        createdAt: lesson.created_at,
        updatedAt: lesson.updated_at,
      })),
    });
  } catch (error) {
    console.error("Error fetching lessons:", error);
    return Response.json({ error: "Failed to fetch lessons" }, { status: 500 });
  }
}

// POST create new lesson (admin only)
export async function POST(request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const { title, category, bodyText, youtubeUrl } = body;

    if (!title || !category || !bodyText) {
      return Response.json(
        { error: "Title, category, and body text are required" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO practice_lessons (title, category, body_text, youtube_url, is_active)
      VALUES (${title}, ${category}, ${bodyText}, ${youtubeUrl || null}, true)
      RETURNING id, title, category, body_text, youtube_url, is_active, created_at, updated_at
    `;

    const lesson = result[0];

    return Response.json({
      ok: true,
      lesson: {
        id: lesson.id,
        title: lesson.title,
        category: lesson.category,
        bodyText: lesson.body_text,
        youtubeUrl: lesson.youtube_url,
        isActive: lesson.is_active,
        createdAt: lesson.created_at,
        updatedAt: lesson.updated_at,
      },
    });
  } catch (error) {
    console.error("Error creating lesson:", error);
    return Response.json({ error: "Failed to create lesson" }, { status: 500 });
  }
}

// PUT update lesson (admin only)
export async function PUT(request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const { id, title, category, bodyText, youtubeUrl, isActive } = body;

    if (!id) {
      return Response.json({ error: "Lesson ID is required" }, { status: 400 });
    }

    const result = await sql`
      UPDATE practice_lessons
      SET 
        title = ${title},
        category = ${category},
        body_text = ${bodyText},
        youtube_url = ${youtubeUrl || null},
        is_active = ${isActive},
        updated_at = NOW()
      WHERE id = ${id}
      RETURNING id, title, category, body_text, youtube_url, is_active, created_at, updated_at
    `;

    if (result.length === 0) {
      return Response.json({ error: "Lesson not found" }, { status: 404 });
    }

    const lesson = result[0];

    return Response.json({
      ok: true,
      lesson: {
        id: lesson.id,
        title: lesson.title,
        category: lesson.category,
        bodyText: lesson.body_text,
        youtubeUrl: lesson.youtube_url,
        isActive: lesson.is_active,
        createdAt: lesson.created_at,
        updatedAt: lesson.updated_at,
      },
    });
  } catch (error) {
    console.error("Error updating lesson:", error);
    return Response.json({ error: "Failed to update lesson" }, { status: 500 });
  }
}

// DELETE lesson (admin only)
export async function DELETE(request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return Response.json({ error: "Lesson ID is required" }, { status: 400 });
    }

    await sql`
      DELETE FROM practice_lessons WHERE id = ${id}
    `;

    return Response.json({ ok: true });
  } catch (error) {
    console.error("Error deleting lesson:", error);
    return Response.json({ error: "Failed to delete lesson" }, { status: 500 });
  }
}
