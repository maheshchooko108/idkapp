import sql from "@/app/api/utils/sql";
import { sendEmail } from "@/app/api/utils/send-email";
import crypto from "crypto";

export async function POST(request) {
  try {
    const { email } = await request.json();

    if (!email || !email.trim()) {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    // Find user by email
    const users = await sql`
      SELECT id, email, name FROM auth_users WHERE email = ${email.trim().toLowerCase()}
    `;

    // Always return success to prevent email enumeration
    if (users.length === 0) {
      return Response.json({
        message:
          "If an account with that email exists, a password reset link has been sent.",
      });
    }

    const user = users[0];

    // Generate cryptographically secure token
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 1); // Expires in 1 hour

    // Store token in database
    await sql`
      INSERT INTO password_reset_tokens (token, user_id, expires_at)
      VALUES (${token}, ${user.id}, ${expiresAt.toISOString()})
    `;

    // Create reset link
    const resetLink = `${process.env.APP_URL}/account/reset-password?token=${token}`;

    // Send email
    try {
      await sendEmail({
        to: user.email,
        subject: "Reset Your Freedom Skills Password",
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #4F46E5;">Reset Your Password</h1>
            <p>Hi ${user.name || "there"},</p>
            <p>We received a request to reset your password for your Freedom Skills account.</p>
            <p>Click the link below to create a new password:</p>
            <p style="margin: 24px 0;">
              <a href="${resetLink}" style="background: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;">
                Reset Password
              </a>
            </p>
            <p style="color: #666; font-size: 14px;">
              This link will expire in 1 hour. If you didn't request this, you can safely ignore this email.
            </p>
            <p style="color: #666; font-size: 14px;">
              Or copy and paste this link:<br/>
              <a href="${resetLink}">${resetLink}</a>
            </p>
          </div>
        `,
        text: `Hi ${user.name || "there"},\n\nWe received a request to reset your password.\n\nClick this link to reset your password: ${resetLink}\n\nThis link expires in 1 hour.\n\nIf you didn't request this, you can safely ignore this email.`,
      });
    } catch (emailError) {
      console.error("Error sending password reset email:", emailError);
      return Response.json(
        {
          error:
            "Could not send password reset email. Please make sure your Resend API key is configured.",
        },
        { status: 500 },
      );
    }

    return Response.json({
      message:
        "If an account with that email exists, a password reset link has been sent.",
    });
  } catch (error) {
    console.error("Password reset request error:", error);
    return Response.json(
      { error: "Could not process password reset request" },
      { status: 500 },
    );
  }
}
