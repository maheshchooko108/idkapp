import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { progressId, parentUserId } = body;

    if (!progressId) {
      return Response.json(
        { error: "Progress ID is required" },
        { status: 400 },
      );
    }

    if (!parentUserId) {
      return Response.json(
        { error: "Parent user ID is required" },
        { status: 400 },
      );
    }

    // Get the progress record and mission details
    const progressData = await sql`
      SELECT up.id, up.user_id, up.mission_id, up.status, m.xp_reward
      FROM user_progress up
      JOIN missions m ON m.id = up.mission_id
      WHERE up.id = ${progressId}
      AND up.status = 'pending_approval'
    `;

    if (progressData.length === 0) {
      return Response.json(
        {
          error: "Progress record not found or not pending approval",
        },
        { status: 404 },
      );
    }

    const progress = progressData[0];
    const xpReward = progress.xp_reward;
    const userId = progress.user_id;

    // Update progress to approved
    await sql`
      UPDATE user_progress
      SET 
        status = 'approved',
        approved_at = NOW(),
        approved_by_parent_user_id = ${parentUserId},
        xp_earned = ${xpReward}
      WHERE id = ${progressId}
    `;

    // Update streak and XP
    const streakData = await sql`
      SELECT id, current_streak, longest_streak, total_xp, last_activity_date
      FROM streaks
      WHERE user_id = ${userId}
    `;

    if (streakData.length === 0) {
      // Create streak record if it doesn't exist
      await sql`
        INSERT INTO streaks (user_id, current_streak, longest_streak, total_xp, last_activity_date)
        VALUES (${userId}, 1, 1, ${xpReward}, CURRENT_DATE)
      `;
    } else {
      const streak = streakData[0];
      const lastActivityDate = streak.last_activity_date;
      const today = new Date().toISOString().split("T")[0];

      let newCurrentStreak = streak.current_streak;
      let newLongestStreak = streak.longest_streak;

      // Check if this is a new day
      if (lastActivityDate) {
        const lastDate = new Date(lastActivityDate);
        const todayDate = new Date(today);
        const daysDiff = Math.floor(
          (todayDate - lastDate) / (1000 * 60 * 60 * 24),
        );

        if (daysDiff === 1) {
          // Consecutive day - increment streak
          newCurrentStreak = streak.current_streak + 1;
          newLongestStreak = Math.max(newCurrentStreak, streak.longest_streak);
        } else if (daysDiff > 1) {
          // Streak broken - reset to 1
          newCurrentStreak = 1;
          newLongestStreak = streak.longest_streak;
        }
        // If daysDiff === 0, it's the same day, keep current streak
      }

      await sql`
        UPDATE streaks
        SET 
          current_streak = ${newCurrentStreak},
          longest_streak = ${newLongestStreak},
          total_xp = ${streak.total_xp + xpReward},
          last_activity_date = CURRENT_DATE
        WHERE user_id = ${userId}
      `;
    }

    return Response.json({
      ok: true,
      message: "Mission approved!",
      xpAwarded: xpReward,
    });
  } catch (error) {
    console.error("Error approving mission:", error);
    return Response.json(
      { error: "Failed to approve mission" },
      { status: 500 },
    );
  }
}
