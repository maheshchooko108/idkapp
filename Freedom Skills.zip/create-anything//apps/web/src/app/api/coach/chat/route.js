import sql from "@/app/api/utils/sql";

const SUPPORTIVE_RESPONSES = [
  "That's a great question! Taking small steps is what builds real confidence. What feels like a good first step for you?",
  "I hear you. It's totally normal to feel that way. What matters is that you're trying. What's one small thing you could do today?",
  "You're doing awesome just by being here and thinking about this. Growth happens in small moments. How can I help?",
  "That takes courage to share. Remember, every expert was once a beginner. What would make this easier for you?",
  "I'm proud of you for working on this. Real-world skills get easier with practice. What's something you'd like to try?",
  "Good question! The best way to build these skills is by practicing in low-pressure situations. Want some ideas?",
  "You're already ahead just by thinking about this. Small wins add up to big changes. What feels doable right now?",
  "I get it. It can feel uncomfortable at first, but that's how we grow. What would help you feel more confident?",
];

export async function POST(request) {
  try {
    const body = await request.json();
    const { message, userId, childId } = body;

    const actualUserId = userId || childId;

    if (!message || !message.trim()) {
      return Response.json({ error: "Message is required" }, { status: 400 });
    }

    if (!actualUserId) {
      return Response.json({ error: "User ID is required" }, { status: 400 });
    }

    await sql`
      INSERT INTO coach_conversations (user_id, message, is_user)
      VALUES (${actualUserId}, ${message.trim()}, true)
    `;

    const reply =
      SUPPORTIVE_RESPONSES[
        Math.floor(Math.random() * SUPPORTIVE_RESPONSES.length)
      ];

    await sql`
      INSERT INTO coach_conversations (user_id, message, is_user)
      VALUES (${actualUserId}, ${reply}, false)
    `;

    return Response.json({ reply });
  } catch (error) {
    console.error("Error in coach chat:", error);
    return Response.json({ error: "Failed to send message" }, { status: 500 });
  }
}
