import { isAdmin } from "@/app/api/utils/admin-auth";

// Check if current user is admin
export async function GET(request) {
  try {
    const adminStatus = await isAdmin();
    return Response.json({ ok: true, isAdmin: adminStatus });
  } catch (error) {
    console.error("Error checking admin status:", error);
    return Response.json({ ok: false, isAdmin: false }, { status: 500 });
  }
}
