import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { getUserIdFromRequest } from "@/app/api/utils/validate-token";

export async function GET(request) {
  try {
    // Try mobile token auth first
    let authUserId = await getUserIdFromRequest(request);

    // Fall back to web session auth
    if (!authUserId) {
      const session = await auth();
      if (session?.user?.id) {
        authUserId = String(session.user.id);
      }
    }

    if (!authUserId) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const rows = await sql`
      SELECT 
        marketing_opt_in, 
        marketing_opt_in_at, 
        data_use_agreed, 
        data_use_agreed_at
      FROM auth_users 
      WHERE id = ${authUserId} 
      LIMIT 1
    `;

    const consent = rows?.[0] || {
      marketing_opt_in: false,
      marketing_opt_in_at: null,
      data_use_agreed: false,
      data_use_agreed_at: null,
    };

    return Response.json({ consent });
  } catch (err) {
    console.error("GET /api/profile/consent error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    // Try mobile token auth first
    let authUserId = await getUserIdFromRequest(request);

    // Fall back to web session auth
    if (!authUserId) {
      const session = await auth();
      if (session?.user?.id) {
        authUserId = String(session.user.id);
      }
    }

    if (!authUserId) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { marketingOptIn, dataUseAgreed } = body || {};

    const updates = [];
    const values = [];
    let paramCount = 0;

    if (typeof marketingOptIn === "boolean") {
      paramCount++;
      updates.push(`marketing_opt_in = $${paramCount}`);
      values.push(marketingOptIn);

      paramCount++;
      updates.push(`marketing_opt_in_at = $${paramCount}`);
      values.push(marketingOptIn ? new Date() : null);
    }

    if (typeof dataUseAgreed === "boolean") {
      paramCount++;
      updates.push(`data_use_agreed = $${paramCount}`);
      values.push(dataUseAgreed);

      paramCount++;
      updates.push(`data_use_agreed_at = $${paramCount}`);
      values.push(dataUseAgreed ? new Date() : null);
    }

    if (updates.length === 0) {
      return Response.json(
        { error: "No valid fields to update" },
        { status: 400 },
      );
    }

    paramCount++;
    const query = `
      UPDATE auth_users 
      SET ${updates.join(", ")} 
      WHERE id = $${paramCount}
      RETURNING 
        marketing_opt_in, 
        marketing_opt_in_at, 
        data_use_agreed, 
        data_use_agreed_at
    `;

    const result = await sql(query, [...values, authUserId]);
    const consent = result?.[0] || null;

    return Response.json({ consent });
  } catch (err) {
    console.error("PUT /api/profile/consent error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
