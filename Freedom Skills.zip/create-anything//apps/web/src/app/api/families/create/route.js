import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { getUserIdFromRequest } from "@/app/api/utils/validate-token";

function generateFamilyCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function POST(request) {
  try {
    // Try mobile token auth first
    let authUserId = await getUserIdFromRequest(request);

    // Fall back to web session auth
    if (!authUserId) {
      const session = await auth();
      if (session?.user?.id) {
        authUserId = String(session.user.id);
      }
    }

    console.log("Create family - auth check:", {
      authUserId,
      hasToken: !!request.headers.get("Authorization"),
    });

    if (!authUserId) {
      console.error("Create family: No session or user id");
      return Response.json(
        { ok: false, error: "Not authenticated" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { parentName } = body;

    if (!parentName || !parentName.trim()) {
      console.error("Create family: No parent name provided");
      return Response.json(
        { ok: false, error: "Parent name is required" },
        { status: 400 },
      );
    }

    console.log(
      "Creating family for user:",
      authUserId,
      "with name:",
      parentName,
    );

    // Check if family already exists for this user
    const existingFamily = await sql`
      SELECT id, family_code FROM families WHERE auth_user_id = ${authUserId} LIMIT 1
    `;

    if (existingFamily.length > 0) {
      console.log("Family already exists for user:", authUserId);
      return Response.json({
        ok: true,
        familyCode: existingFamily[0].family_code,
        familyId: existingFamily[0].id,
      });
    }

    let familyCode = generateFamilyCode();
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      try {
        const family = await sql`
          INSERT INTO families (family_code, parent_name, auth_user_id)
          VALUES (${familyCode}, ${parentName.trim()}, ${authUserId})
          RETURNING id, family_code
        `;

        await sql`
          INSERT INTO users (family_id, name, role, auth_user_id)
          VALUES (${family[0].id}, ${parentName.trim()}, 'parent', ${authUserId})
        `;

        console.log(
          "Successfully created family:",
          family[0].id,
          "for user:",
          authUserId,
        );
        return Response.json({
          ok: true,
          familyCode: family[0].family_code,
          familyId: family[0].id,
        });
      } catch (error) {
        console.error("Error in family creation loop:", error);
        if (error.code === "23505") {
          // Duplicate family code, try again
          familyCode = generateFamilyCode();
          attempts++;
          console.log("Duplicate family code, retrying... attempt", attempts);
        } else {
          // Some other error, throw it
          throw error;
        }
      }
    }

    console.error(
      "Could not generate unique family code after",
      maxAttempts,
      "attempts",
    );
    return Response.json(
      { ok: false, error: "Could not generate unique family code" },
      { status: 500 },
    );
  } catch (error) {
    console.error("Error creating family:", error);
    console.error("Error details:", {
      message: error.message,
      code: error.code,
      detail: error.detail,
      stack: error.stack,
    });
    return Response.json(
      { ok: false, error: error.message || "Failed to create family" },
      { status: 500 },
    );
  }
}
