import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { userId, missionId } = body;

    if (!userId) {
      return Response.json({ error: "User ID is required" }, { status: 400 });
    }

    if (!missionId) {
      return Response.json(
        { error: "Mission ID is required" },
        { status: 400 },
      );
    }

    // Check if mission is already in progress or completed today
    const existing = await sql`
      SELECT id, status FROM user_progress
      WHERE user_id = ${userId}
      AND mission_id = ${missionId}
      AND DATE(completed_at) = CURRENT_DATE
    `;

    if (existing.length > 0) {
      return Response.json({
        ok: true,
        message: "Mission already started",
        progressId: existing[0].id,
        status: existing[0].status,
      });
    }

    // Create new in_progress record
    const result = await sql`
      INSERT INTO user_progress (user_id, mission_id, status, xp_earned, completed_at)
      VALUES (${userId}, ${missionId}, 'in_progress', 0, NOW())
      RETURNING id
    `;

    return Response.json({
      ok: true,
      progressId: result[0].id,
      message: "Mission started!",
      status: "in_progress",
    });
  } catch (error) {
    console.error("Error starting mission:", error);
    return Response.json({ error: "Failed to start mission" }, { status: 500 });
  }
}
