import sql from "@/app/api/utils/sql";
import { verify } from "argon2";

export async function POST(request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return Response.json(
        { ok: false, error: "Please fill in all fields" },
        { status: 400 },
      );
    }

    // Find user
    const users = await sql`
      SELECT au.id, au.email, au.name, aa.password
      FROM auth_users au
      JOIN auth_accounts aa ON aa."userId" = au.id
      WHERE au.email = ${email.toLowerCase()} AND aa.type = 'credentials'
    `;

    if (users.length === 0) {
      return Response.json(
        { ok: false, error: "Incorrect email or password. Try again." },
        { status: 401 },
      );
    }

    const user = users[0];

    // Verify password
    const isValid = await verify(user.password, password);
    if (!isValid) {
      return Response.json(
        { ok: false, error: "Incorrect email or password. Try again." },
        { status: 401 },
      );
    }

    // Create session
    const sessionToken = crypto.randomUUID();
    const expires = new Date();
    expires.setDate(expires.getDate() + 30);

    await sql`
      INSERT INTO auth_sessions ("userId", expires, "sessionToken")
      VALUES (${user.id}, ${expires.toISOString()}, ${sessionToken})
    `;

    // Return session token for mobile
    return Response.json({
      ok: true,
      token: sessionToken,
      user: {
        id: String(user.id),
        email: user.email,
        name: user.name,
      },
    });
  } catch (error) {
    console.error("Mobile signin error:", error);
    return Response.json(
      { ok: false, error: "Sign in failed. Please try again." },
      { status: 500 },
    );
  }
}
