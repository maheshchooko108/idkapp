import sql from "./sql";

/**
 * Validates a mobile session token and returns the user ID
 * @param {string} token - The session token to validate
 * @returns {Promise<string|null>} The user ID if valid, null otherwise
 */
export async function validateToken(token) {
  if (!token) {
    return null;
  }

  try {
    const sessions = await sql`
      SELECT "userId", expires
      FROM auth_sessions
      WHERE "sessionToken" = ${token}
        AND expires > NOW()
      LIMIT 1
    `;

    if (sessions.length === 0) {
      return null;
    }

    return String(sessions[0].userId);
  } catch (error) {
    console.error("Token validation error:", error);
    return null;
  }
}

/**
 * Extracts and validates the Bearer token from a request
 * @param {Request} request - The incoming request
 * @returns {Promise<string|null>} The user ID if valid, null otherwise
 */
export async function getUserIdFromRequest(request) {
  const authHeader = request.headers.get("Authorization");

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null;
  }

  const token = authHeader.substring(7); // Remove "Bearer " prefix
  return await validateToken(token);
}
