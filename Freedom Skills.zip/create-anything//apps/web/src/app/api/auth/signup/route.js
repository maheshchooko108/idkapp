import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

function generateFamilyCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function POST(request) {
  try {
    const formData = await request.formData();
    const email = formData.get("email");
    const password = formData.get("password");
    const name = formData.get("name");

    if (!email || !password || !name) {
      return new Response("Missing required fields", {
        status: 400,
        headers: { Location: "/account/signup?error=missing_fields" },
      });
    }

    // Check if user already exists
    const existingUser = await sql`
      SELECT id FROM auth_users WHERE email = ${email}
    `;

    if (existingUser.length > 0) {
      return new Response("User already exists", {
        status: 400,
        headers: { Location: "/account/signup?error=user_exists" },
      });
    }

    // Hash password
    const hashedPassword = await hash(password);

    // Create auth user
    const [authUser] = await sql`
      INSERT INTO auth_users (email, name)
      VALUES (${email}, ${name})
      RETURNING id
    `;

    // Create auth account with password
    await sql`
      INSERT INTO auth_accounts ("userId", type, provider, "providerAccountId", password)
      VALUES (${authUser.id}, 'credentials', 'credentials', ${email}, ${hashedPassword})
    `;

    // Generate unique family code
    let familyCode = generateFamilyCode();
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      try {
        // Create family record
        await sql`
          INSERT INTO families (family_code, parent_name, auth_user_id)
          VALUES (${familyCode}, ${name}, ${authUser.id})
        `;
        break;
      } catch (error) {
        if (error.code === "23505") {
          familyCode = generateFamilyCode();
          attempts++;
        } else {
          throw error;
        }
      }
    }

    // Create session
    const sessionToken = crypto.randomUUID();
    const expires = new Date();
    expires.setDate(expires.getDate() + 30);

    await sql`
      INSERT INTO auth_sessions ("userId", expires, "sessionToken")
      VALUES (${authUser.id}, ${expires.toISOString()}, ${sessionToken})
    `;

    // Set cookie and redirect
    return new Response(null, {
      status: 302,
      headers: {
        "Set-Cookie": `next-auth.session-token=${sessionToken}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires.toUTCString()}`,
        Location: "/parent/(tabs)",
      },
    });
  } catch (error) {
    console.error("Signup error:", error);
    return new Response("Signup failed", {
      status: 500,
      headers: { Location: "/account/signup?error=server_error" },
    });
  }
}
