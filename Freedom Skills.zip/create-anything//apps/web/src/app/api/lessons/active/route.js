import sql from "@/app/api/utils/sql";

// GET active lessons (public - for child practice tab)
export async function GET(request) {
  try {
    const lessons = await sql`
      SELECT 
        id,
        title,
        category,
        body_text,
        youtube_url
      FROM practice_lessons
      WHERE is_active = true
      ORDER BY created_at DESC
    `;

    return Response.json({
      ok: true,
      lessons: lessons.map((lesson) => ({
        id: lesson.id,
        title: lesson.title,
        category: lesson.category,
        bodyText: lesson.body_text,
        youtubeUrl: lesson.youtube_url,
      })),
    });
  } catch (error) {
    console.error("Error fetching active lessons:", error);
    return Response.json({ error: "Failed to fetch lessons" }, { status: 500 });
  }
}
