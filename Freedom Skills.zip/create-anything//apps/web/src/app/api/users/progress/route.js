import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return Response.json({ error: "User ID is required" }, { status: 400 });
    }

    const weekAgo = new Date(
      Date.now() - 7 * 24 * 60 * 60 * 1000,
    ).toISOString();

    const [streakData] = await sql`
      SELECT
        current_streak,
        longest_streak,
        total_xp
      FROM streaks
      WHERE user_id = ${userId}
    `;

    const progressData = await sql`
      SELECT
        COUNT(CASE WHEN status = 'approved' THEN 1 END) as total_missions,
        COUNT(CASE WHEN status = 'approved' AND completed_at >= ${weekAgo} THEN 1 END) as missions_this_week,
        COUNT(CASE WHEN status = 'pending_approval' THEN 1 END) as pending_approvals
      FROM user_progress
      WHERE user_id = ${userId}
    `;

    return Response.json({
      currentStreak: parseInt(streakData?.current_streak) || 0,
      longestStreak: parseInt(streakData?.longest_streak) || 0,
      totalXP: parseInt(streakData?.total_xp) || 0,
      totalMissions: parseInt(progressData[0]?.total_missions) || 0,
      missionsThisWeek: parseInt(progressData[0]?.missions_this_week) || 0,
      pendingApprovals: parseInt(progressData[0]?.pending_approvals) || 0,
    });
  } catch (error) {
    console.error("Error loading user progress:", error);
    return Response.json({ error: "Failed to load progress" }, { status: 500 });
  }
}
