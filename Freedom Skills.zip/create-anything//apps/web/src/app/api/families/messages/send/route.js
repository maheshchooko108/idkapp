import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { familyId, fromUserId, toUserId, messageText } = body;

    if (!familyId) {
      return Response.json({ error: "Family ID is required" }, { status: 400 });
    }

    if (!fromUserId) {
      return Response.json(
        { error: "From user ID is required" },
        { status: 400 },
      );
    }

    if (!toUserId) {
      return Response.json(
        { error: "To user ID is required" },
        { status: 400 },
      );
    }

    if (!messageText || messageText.trim().length === 0) {
      return Response.json(
        { error: "Message text is required" },
        { status: 400 },
      );
    }

    // Verify both users are in the same family
    const users = await sql`
      SELECT id FROM users
      WHERE id IN (${fromUserId}, ${toUserId})
      AND family_id = ${familyId}
    `;

    if (users.length !== 2) {
      return Response.json(
        { error: "Users must be in the same family" },
        { status: 403 },
      );
    }

    // Insert message
    const result = await sql`
      INSERT INTO family_messages (family_id, from_user_id, to_user_id, message_text, created_at)
      VALUES (${familyId}, ${fromUserId}, ${toUserId}, ${messageText.trim()}, NOW())
      RETURNING id, created_at
    `;

    return Response.json({
      ok: true,
      messageId: result[0].id,
      createdAt: result[0].created_at,
    });
  } catch (error) {
    console.error("Error sending message:", error);
    return Response.json({ error: "Failed to send message" }, { status: 500 });
  }
}
