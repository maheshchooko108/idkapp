import sql from "@/app/api/utils/sql";
import { requireAdmin } from "@/app/api/utils/admin-auth";

// GET theme config (admin only)
export async function GET(request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const result = await sql`
      SELECT * FROM app_theme WHERE id = 1 LIMIT 1
    `;

    const theme = result[0] || {
      id: 1,
      primary_color: "#8B5CF6",
      secondary_color: "#6366F1",
      background_top: "#FFFFFF",
      background_bottom: "#F3F4F6",
    };

    return Response.json({
      ok: true,
      theme: {
        primaryColor: theme.primary_color,
        secondaryColor: theme.secondary_color,
        backgroundTop: theme.background_top,
        backgroundBottom: theme.background_bottom,
        updatedAt: theme.updated_at,
      },
    });
  } catch (error) {
    console.error("Error fetching theme:", error);
    return Response.json({ error: "Failed to fetch theme" }, { status: 500 });
  }
}

// PUT update theme (admin only)
export async function PUT(request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const body = await request.json();
    const { primaryColor, secondaryColor, backgroundTop, backgroundBottom } =
      body;

    if (
      !primaryColor ||
      !secondaryColor ||
      !backgroundTop ||
      !backgroundBottom
    ) {
      return Response.json(
        { error: "All color fields are required" },
        { status: 400 },
      );
    }

    const result = await sql`
      UPDATE app_theme
      SET 
        primary_color = ${primaryColor},
        secondary_color = ${secondaryColor},
        background_top = ${backgroundTop},
        background_bottom = ${backgroundBottom},
        updated_at = NOW()
      WHERE id = 1
      RETURNING *
    `;

    const theme = result[0];

    return Response.json({
      ok: true,
      theme: {
        primaryColor: theme.primary_color,
        secondaryColor: theme.secondary_color,
        backgroundTop: theme.background_top,
        backgroundBottom: theme.background_bottom,
        updatedAt: theme.updated_at,
      },
    });
  } catch (error) {
    console.error("Error updating theme:", error);
    return Response.json({ error: "Failed to update theme" }, { status: 500 });
  }
}
