import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const missions = await sql`
      SELECT
        id,
        title,
        description,
        category,
        difficulty,
        xp_reward,
        duration_minutes,
        icon_name
      FROM missions
      ORDER BY RANDOM()
      LIMIT 5
    `;

    return Response.json(
      missions.map((mission) => ({
        id: mission.id,
        title: mission.title,
        description: mission.description,
        category: mission.category,
        difficulty: mission.difficulty,
        xpReward: mission.xp_reward,
        durationMinutes: mission.duration_minutes,
        iconName: mission.icon_name,
      })),
    );
  } catch (error) {
    console.error("Error loading missions:", error);
    return Response.json({ error: "Failed to load missions" }, { status: 500 });
  }
}
