import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { progressId, parentUserId, parentNote } = body;

    if (!progressId) {
      return Response.json(
        { error: "Progress ID is required" },
        { status: 400 },
      );
    }

    if (!parentUserId) {
      return Response.json(
        { error: "Parent user ID is required" },
        { status: 400 },
      );
    }

    if (!parentNote || parentNote.trim().length < 5) {
      return Response.json(
        { error: "Please provide a reason for rejection" },
        { status: 400 },
      );
    }

    // Get the progress record
    const progressData = await sql`
      SELECT id, status FROM user_progress
      WHERE id = ${progressId}
      AND status = 'pending_approval'
    `;

    if (progressData.length === 0) {
      return Response.json(
        {
          error: "Progress record not found or not pending approval",
        },
        { status: 404 },
      );
    }

    // Update to rejected
    await sql`
      UPDATE user_progress
      SET 
        status = 'rejected',
        approved_at = NOW(),
        approved_by_parent_user_id = ${parentUserId},
        parent_note = ${parentNote},
        xp_earned = 0
      WHERE id = ${progressId}
    `;

    return Response.json({
      ok: true,
      message: "Mission rejected",
    });
  } catch (error) {
    console.error("Error rejecting mission:", error);
    return Response.json(
      { error: "Failed to reject mission" },
      { status: 500 },
    );
  }
}
