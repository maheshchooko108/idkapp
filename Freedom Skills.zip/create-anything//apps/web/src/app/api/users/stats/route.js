import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return Response.json({ error: "User ID is required" }, { status: 400 });
    }

    const stats = await sql`
      SELECT
        current_streak,
        total_xp
      FROM streaks
      WHERE user_id = ${userId}
    `;

    if (stats.length === 0) {
      return Response.json({
        currentStreak: 0,
        totalXP: 0,
      });
    }

    return Response.json({
      currentStreak: parseInt(stats[0].current_streak) || 0,
      totalXP: parseInt(stats[0].total_xp) || 0,
    });
  } catch (error) {
    console.error("Error loading user stats:", error);
    return Response.json({ error: "Failed to load stats" }, { status: 500 });
  }
}
