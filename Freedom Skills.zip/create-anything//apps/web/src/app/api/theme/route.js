import sql from "@/app/api/utils/sql";

// GET current theme (public)
export async function GET(request) {
  try {
    const result = await sql`
      SELECT * FROM app_theme WHERE id = 1 LIMIT 1
    `;

    const theme = result[0] || {
      primary_color: "#8B5CF6",
      secondary_color: "#6366F1",
      background_top: "#FFFFFF",
      background_bottom: "#F3F4F6",
    };

    return Response.json({
      ok: true,
      theme: {
        primaryColor: theme.primary_color,
        secondaryColor: theme.secondary_color,
        backgroundTop: theme.background_top,
        backgroundBottom: theme.background_bottom,
      },
    });
  } catch (error) {
    console.error("Error fetching theme:", error);
    // Return fallback theme on error
    return Response.json({
      ok: false,
      theme: {
        primaryColor: "#8B5CF6",
        secondaryColor: "#6366F1",
        backgroundTop: "#FFFFFF",
        backgroundBottom: "#F3F4F6",
      },
    });
  }
}
