import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { childUserId } = body;

    if (!childUserId) {
      return Response.json(
        { error: "Child user ID is required" },
        { status: 400 },
      );
    }

    // Mark child as inactive instead of deleting (preserves history)
    await sql`
      UPDATE users
      SET is_active = false
      WHERE id = ${childUserId}
      AND role = 'child'
    `;

    return Response.json({
      ok: true,
      message: "Child removed successfully",
    });
  } catch (error) {
    console.error("Error removing child:", error);
    return Response.json({ error: "Failed to remove child" }, { status: 500 });
  }
}
