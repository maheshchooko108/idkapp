import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { getUserIdFromRequest } from "@/app/api/utils/validate-token";

export async function GET(request) {
  try {
    // Try mobile token auth first
    let authUserId = await getUserIdFromRequest(request);

    // Fall back to web session auth
    if (!authUserId) {
      const session = await auth();
      if (session?.user?.id) {
        authUserId = String(session.user.id);
      }
    }

    if (!authUserId) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const families = await sql`
      SELECT family_code FROM families WHERE auth_user_id = ${authUserId} LIMIT 1
    `;

    if (families.length === 0) {
      return Response.json({ error: "No family found" }, { status: 404 });
    }

    return Response.json({
      familyCode: families[0].family_code,
    });
  } catch (error) {
    console.error("Error loading family code:", error);
    return Response.json(
      { error: "Failed to load family code" },
      { status: 500 },
    );
  }
}
