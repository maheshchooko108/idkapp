import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { familyCode, name, avatarEmoji } = body;

    if (!familyCode || !familyCode.trim()) {
      return Response.json(
        { error: "Family code is required" },
        { status: 400 },
      );
    }

    if (!name || !name.trim()) {
      return Response.json({ error: "Name is required" }, { status: 400 });
    }

    const families = await sql`
      SELECT id FROM families WHERE family_code = ${familyCode.trim().toUpperCase()}
    `;

    if (families.length === 0) {
      return Response.json({ error: "Invalid family code" }, { status: 404 });
    }

    const familyId = families[0].id;

    const user = await sql`
      INSERT INTO users (family_id, name, role, avatar_emoji)
      VALUES (${familyId}, ${name.trim()}, 'child', ${avatarEmoji || "✨"})
      RETURNING id
    `;

    await sql`
      INSERT INTO streaks (user_id, current_streak, longest_streak, total_xp)
      VALUES (${user[0].id}, 0, 0, 0)
    `;

    return Response.json({
      userId: user[0].id,
      familyId,
      name: name.trim(),
      avatarEmoji: avatarEmoji || "✨",
    });
  } catch (error) {
    console.error("Error joining family:", error);
    return Response.json({ error: "Failed to join family" }, { status: 500 });
  }
}
