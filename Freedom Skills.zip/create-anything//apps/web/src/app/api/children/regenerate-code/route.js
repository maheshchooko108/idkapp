import sql from "@/app/api/utils/sql";

function generateChildCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 10; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { childUserId } = body;

    if (!childUserId) {
      return Response.json(
        { error: "Child user ID is required" },
        { status: 400 },
      );
    }

    let newCode = generateChildCode();
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      try {
        await sql`
          UPDATE users
          SET child_join_code = ${newCode}
          WHERE id = ${childUserId}
          AND role = 'child'
        `;

        return Response.json({
          ok: true,
          childJoinCode: newCode,
        });
      } catch (error) {
        if (error.code === "23505") {
          // Duplicate code, try again
          newCode = generateChildCode();
          attempts++;
        } else {
          throw error;
        }
      }
    }

    return Response.json(
      { error: "Could not generate unique code" },
      { status: 500 },
    );
  } catch (error) {
    console.error("Error regenerating child code:", error);
    return Response.json(
      { error: "Failed to regenerate code" },
      { status: 500 },
    );
  }
}
