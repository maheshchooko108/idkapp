// Server-side admin email allowlist
const ADMIN_EMAILS = [
  "jim@example.com", // Replace with actual admin email
  "mahesh@example.com", // Replace with actual admin email
  // Add more admin emails as needed
];

// For admin routes: Import auth separately and pass session here
export function isAdminSession(session) {
  if (!session?.user?.email) {
    return false;
  }
  return ADMIN_EMAILS.includes(session.user.email.toLowerCase());
}

export function requireAdminSession(session) {
  if (!isAdminSession(session)) {
    return Response.json(
      { error: "Unauthorized. Admin access required." },
      { status: 403 },
    );
  }
  return null;
}
