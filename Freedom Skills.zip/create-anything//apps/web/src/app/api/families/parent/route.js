import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const familyId = searchParams.get("familyId");

    if (!familyId) {
      return Response.json({ error: "Family ID is required" }, { status: 400 });
    }

    // Get the parent user for this family
    const parents = await sql`
      SELECT id, name, avatar_emoji
      FROM users
      WHERE family_id = ${familyId}
      AND role = 'parent'
      AND is_active = true
      LIMIT 1
    `;

    if (parents.length === 0) {
      return Response.json({ error: "No parent found" }, { status: 404 });
    }

    return Response.json({
      ok: true,
      parent: {
        id: parents[0].id,
        name: parents[0].name,
        avatarEmoji: parents[0].avatar_emoji,
      },
    });
  } catch (error) {
    console.error("Error fetching parent:", error);
    return Response.json({ error: "Failed to fetch parent" }, { status: 500 });
  }
}
