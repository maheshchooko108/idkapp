import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const familyId = searchParams.get("familyId");

    if (!familyId) {
      return Response.json({ error: "familyId is required" }, { status: 400 });
    }

    // Get counts by status
    const statusCounts = await sql`
      SELECT 
        up.status, 
        COUNT(*) as count
      FROM user_progress up
      JOIN users u ON u.id = up.user_id
      WHERE u.family_id = ${familyId}
      GROUP BY up.status
    `;

    // Get sample pending approvals
    const pendingApprovals = await sql`
      SELECT 
        up.id,
        up.user_id,
        up.mission_id,
        up.status,
        up.completion_requested_at,
        up.proof_text,
        u.name as child_name,
        u.family_id,
        m.title as mission_title
      FROM user_progress up
      JOIN users u ON u.id = up.user_id
      JOIN missions m ON m.id = up.mission_id
      WHERE u.family_id = ${familyId}
      AND up.status = 'pending_approval'
      ORDER BY up.completion_requested_at DESC
      LIMIT 5
    `;

    // Get all children in this family
    const children = await sql`
      SELECT id, name, role, family_id, is_active
      FROM users
      WHERE family_id = ${familyId}
      AND role = 'child'
    `;

    return Response.json({
      familyId: parseInt(familyId),
      statusCounts,
      pendingApprovals,
      children,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error in debug endpoint:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
