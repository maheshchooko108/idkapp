import sql from "@/app/api/utils/sql";

// Get child profile by ID (stored in local storage)
export async function GET(request) {
  try {
    const url = new URL(request.url);
    const childId = url.searchParams.get("childId");

    if (!childId) {
      return Response.json({ error: "Child ID required" }, { status: 400 });
    }

    const children = await sql`
      SELECT 
        u.id,
        u.name,
        u.avatar_emoji,
        u.family_id,
        f.family_code
      FROM users u
      JOIN families f ON f.id = u.family_id
      WHERE u.id = ${parseInt(childId)} AND u.role = 'child'
    `;

    if (children.length === 0) {
      return Response.json({ error: "Child not found" }, { status: 404 });
    }

    const child = children[0];

    return Response.json({
      id: child.id,
      name: child.name,
      avatarEmoji: child.avatar_emoji,
      familyId: child.family_id,
      familyCode: child.family_code,
    });
  } catch (error) {
    console.error("Error loading child profile:", error);
    return Response.json({ error: "Failed to load profile" }, { status: 500 });
  }
}

// Create or update child profile
export async function POST(request) {
  try {
    const body = await request.json();
    const { childId, familyCode, name, avatarEmoji } = body;

    // If childId is provided, update existing profile
    if (childId) {
      await sql`
        UPDATE users
        SET name = ${name}, avatar_emoji = ${avatarEmoji}
        WHERE id = ${parseInt(childId)} AND role = 'child'
      `;

      return Response.json({ childId: parseInt(childId) });
    }

    // Otherwise create new profile
    if (!familyCode || !name) {
      return Response.json(
        { error: "Family code and name required" },
        { status: 400 },
      );
    }

    const families = await sql`
      SELECT id FROM families WHERE family_code = ${familyCode.trim().toUpperCase()}
    `;

    if (families.length === 0) {
      return Response.json({ error: "Invalid family code" }, { status: 404 });
    }

    const familyId = families[0].id;

    const [user] = await sql`
      INSERT INTO users (family_id, name, role, avatar_emoji)
      VALUES (${familyId}, ${name.trim()}, 'child', ${avatarEmoji || "✨"})
      RETURNING id
    `;

    await sql`
      INSERT INTO streaks (user_id, current_streak, longest_streak, total_xp)
      VALUES (${user.id}, 0, 0, 0)
    `;

    return Response.json({ childId: user.id });
  } catch (error) {
    console.error("Error saving child profile:", error);
    return Response.json({ error: "Failed to save profile" }, { status: 500 });
  }
}
