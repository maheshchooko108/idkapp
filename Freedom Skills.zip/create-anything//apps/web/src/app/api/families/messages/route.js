import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const familyId = searchParams.get("familyId");
    const withUserId = searchParams.get("withUserId");

    if (!familyId) {
      return Response.json({ error: "Family ID is required" }, { status: 400 });
    }

    let messages;

    if (withUserId) {
      // Get conversation between two specific users
      messages = await sql`
        SELECT 
          fm.id,
          fm.from_user_id,
          fm.to_user_id,
          fm.message_text,
          fm.created_at,
          u.name as from_user_name,
          u.avatar_emoji
        FROM family_messages fm
        JOIN users u ON u.id = fm.from_user_id
        WHERE fm.family_id = ${familyId}
        AND (
          (fm.from_user_id = ${withUserId}) OR
          (fm.to_user_id = ${withUserId})
        )
        ORDER BY fm.created_at ASC
      `;
    } else {
      // Get all messages for this family
      messages = await sql`
        SELECT 
          fm.id,
          fm.from_user_id,
          fm.to_user_id,
          fm.message_text,
          fm.created_at,
          u.name as from_user_name,
          u.avatar_emoji
        FROM family_messages fm
        JOIN users u ON u.id = fm.from_user_id
        WHERE fm.family_id = ${familyId}
        ORDER BY fm.created_at ASC
      `;
    }

    return Response.json(messages);
  } catch (error) {
    console.error("Error fetching messages:", error);
    return Response.json(
      { error: "Failed to fetch messages" },
      { status: 500 },
    );
  }
}
