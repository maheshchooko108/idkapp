import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

export async function POST(request) {
  try {
    const { email, password, name, marketingOptIn, dataUseAgreed } =
      await request.json();

    if (!email || !password || !name) {
      return Response.json(
        { ok: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Check if user already exists
    const existingUser = await sql`
      SELECT id FROM auth_users WHERE email = ${email.toLowerCase()}
    `;

    if (existingUser.length > 0) {
      return Response.json(
        {
          ok: false,
          error: "This email is already registered. Try signing in instead.",
        },
        { status: 400 },
      );
    }

    // Hash password
    const hashedPassword = await hash(password);

    // Create auth user with consent preferences
    const [authUser] = await sql`
      INSERT INTO auth_users (email, name, marketing_opt_in, marketing_opt_in_at, data_use_agreed, data_use_agreed_at)
      VALUES (
        ${email.toLowerCase()}, 
        ${name},
        ${marketingOptIn || false},
        ${marketingOptIn ? new Date().toISOString() : null},
        ${dataUseAgreed || false},
        ${dataUseAgreed ? new Date().toISOString() : null}
      )
      RETURNING id, email, name
    `;

    // Create auth account with password
    await sql`
      INSERT INTO auth_accounts ("userId", type, provider, "providerAccountId", password)
      VALUES (${authUser.id}, 'credentials', 'credentials', ${email.toLowerCase()}, ${hashedPassword})
    `;

    // Create session
    const sessionToken = crypto.randomUUID();
    const expires = new Date();
    expires.setDate(expires.getDate() + 30);

    await sql`
      INSERT INTO auth_sessions ("userId", expires, "sessionToken")
      VALUES (${authUser.id}, ${expires.toISOString()}, ${sessionToken})
    `;

    // Return session token for mobile
    return Response.json({
      ok: true,
      token: sessionToken,
      user: {
        id: String(authUser.id),
        email: authUser.email,
        name: authUser.name,
      },
    });
  } catch (error) {
    console.error("Mobile signup error:", error);
    return Response.json(
      { ok: false, error: "Signup failed. Please try again." },
      { status: 500 },
    );
  }
}
