import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const families = await sql`
      SELECT id FROM families WHERE auth_user_id = ${session.user.id} LIMIT 1
    `;

    if (families.length === 0) {
      return Response.json([]);
    }

    const familyId = families[0].id;
    const weekAgo = new Date(
      Date.now() - 7 * 24 * 60 * 60 * 1000,
    ).toISOString();

    const children = await sql`
      SELECT
        u.id,
        u.name,
        u.avatar_emoji,
        COALESCE(s.current_streak, 0) as current_streak,
        COALESCE(s.total_xp, 0) as total_xp,
        COUNT(CASE WHEN up.completed_at >= ${weekAgo} THEN 1 END) as missions_this_week,
        COUNT(up.id) as total_missions
      FROM users u
      LEFT JOIN streaks s ON s.user_id = u.id
      LEFT JOIN user_progress up ON up.user_id = u.id
      WHERE u.family_id = ${familyId} AND u.role = 'child'
      GROUP BY u.id, u.name, u.avatar_emoji, s.current_streak, s.total_xp
      ORDER BY u.created_at DESC
    `;

    return Response.json(
      children.map((child) => ({
        id: child.id,
        name: child.name,
        avatarEmoji: child.avatar_emoji,
        currentStreak: parseInt(child.current_streak) || 0,
        totalXP: parseInt(child.total_xp) || 0,
        missionsThisWeek: parseInt(child.missions_this_week) || 0,
        totalMissions: parseInt(child.total_missions) || 0,
      })),
    );
  } catch (error) {
    console.error("Error loading children:", error);
    return Response.json({ error: "Failed to load children" }, { status: 500 });
  }
}
