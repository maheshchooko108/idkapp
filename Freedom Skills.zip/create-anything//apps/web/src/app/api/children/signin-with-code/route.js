import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { code } = body;

    if (!code || code.trim().length === 0) {
      return Response.json({ error: "Join code is required" }, { status: 400 });
    }

    // Find child by their unique join code
    const children = await sql`
      SELECT id, family_id, name, avatar_emoji, child_join_code
      FROM users
      WHERE child_join_code = ${code.trim().toUpperCase()}
      AND role = 'child'
      AND is_active = true
      LIMIT 1
    `;

    if (children.length === 0) {
      return Response.json({ error: "Invalid join code" }, { status: 404 });
    }

    const child = children[0];

    return Response.json({
      ok: true,
      child: {
        id: child.id,
        familyId: child.family_id,
        name: child.name,
        avatarEmoji: child.avatar_emoji,
        childJoinCode: child.child_join_code,
      },
    });
  } catch (error) {
    console.error("Error signing in with child code:", error);
    return Response.json(
      { error: "Failed to sign in with code" },
      { status: 500 },
    );
  }
}
