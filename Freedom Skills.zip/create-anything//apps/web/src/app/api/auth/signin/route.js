import sql from "@/app/api/utils/sql";
import { verify } from "argon2";

export async function POST(request) {
  try {
    const formData = await request.formData();
    const email = formData.get("email");
    const password = formData.get("password");
    const callbackUrl = formData.get("callbackUrl") || "/parent/(tabs)";

    if (!email || !password) {
      return new Response("Missing credentials", {
        status: 400,
        headers: { Location: "/account/signin?error=missing_credentials" },
      });
    }

    // Find user
    const users = await sql`
      SELECT au.id, aa.password
      FROM auth_users au
      JOIN auth_accounts aa ON aa."userId" = au.id
      WHERE au.email = ${email} AND aa.type = 'credentials'
    `;

    if (users.length === 0) {
      return new Response("Invalid credentials", {
        status: 401,
        headers: { Location: "/account/signin?error=invalid_credentials" },
      });
    }

    const user = users[0];

    // Verify password
    const isValid = await verify(user.password, password);
    if (!isValid) {
      return new Response("Invalid credentials", {
        status: 401,
        headers: { Location: "/account/signin?error=invalid_credentials" },
      });
    }

    // Create session
    const sessionToken = crypto.randomUUID();
    const expires = new Date();
    expires.setDate(expires.getDate() + 30);

    await sql`
      INSERT INTO auth_sessions ("userId", expires, "sessionToken")
      VALUES (${user.id}, ${expires.toISOString()}, ${sessionToken})
    `;

    // Set cookie and redirect
    return new Response(null, {
      status: 302,
      headers: {
        "Set-Cookie": `next-auth.session-token=${sessionToken}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires.toUTCString()}`,
        Location: callbackUrl,
      },
    });
  } catch (error) {
    console.error("Signin error:", error);
    return new Response("Signin failed", {
      status: 500,
      headers: { Location: "/account/signin?error=server_error" },
    });
  }
}
