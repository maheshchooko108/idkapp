import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { getUserIdFromRequest } from "@/app/api/utils/validate-token";

export async function GET(request) {
  try {
    // Try mobile token auth first
    let authUserId = await getUserIdFromRequest(request);

    // Fall back to web session auth
    if (!authUserId) {
      const session = await auth();
      if (session?.user?.id) {
        authUserId = String(session.user.id);
      }
    }

    if (!authUserId) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const families = await sql`
      SELECT id FROM families WHERE auth_user_id = ${authUserId} LIMIT 1
    `;

    if (families.length === 0) {
      return Response.json({
        activeKids: 0,
        completedToday: 0,
        missionsThisWeek: 0,
        totalStreaks: 0,
        totalXP: 0,
        realWorldMissions: 0,
      });
    }

    const familyId = families[0].id;
    const today = new Date().toISOString().split("T")[0];
    const weekAgo = new Date(
      Date.now() - 7 * 24 * 60 * 60 * 1000,
    ).toISOString();

    const stats = await sql`
      SELECT
        COUNT(DISTINCT CASE WHEN DATE(up.completed_at) = ${today} THEN up.user_id END) as active_kids,
        COUNT(CASE WHEN DATE(up.completed_at) = ${today} THEN 1 END) as completed_today,
        COUNT(CASE WHEN up.completed_at >= ${weekAgo} THEN 1 END) as missions_this_week,
        COALESCE(SUM(s.current_streak), 0) as total_streaks,
        COALESCE(SUM(s.total_xp), 0) as total_xp,
        COUNT(CASE WHEN up.completed_at >= ${weekAgo} AND m.category = 'real-world' THEN 1 END) as real_world_missions
      FROM users u
      LEFT JOIN streaks s ON s.user_id = u.id
      LEFT JOIN user_progress up ON up.user_id = u.id
      LEFT JOIN missions m ON m.id = up.mission_id
      WHERE u.family_id = ${familyId} AND u.role = 'child'
    `;

    return Response.json({
      activeKids: parseInt(stats[0]?.active_kids) || 0,
      completedToday: parseInt(stats[0]?.completed_today) || 0,
      missionsThisWeek: parseInt(stats[0]?.missions_this_week) || 0,
      totalStreaks: parseInt(stats[0]?.total_streaks) || 0,
      totalXP: parseInt(stats[0]?.total_xp) || 0,
      realWorldMissions: parseInt(stats[0]?.real_world_missions) || 0,
    });
  } catch (error) {
    console.error("Error loading family stats:", error);
    return Response.json({ error: "Failed to load stats" }, { status: 500 });
  }
}
