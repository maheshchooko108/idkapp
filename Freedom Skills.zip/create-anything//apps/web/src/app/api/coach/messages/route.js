import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId") || searchParams.get("childId");

    if (!userId) {
      return Response.json([]);
    }

    const messages = await sql`
      SELECT
        id,
        message,
        is_user,
        created_at
      FROM coach_conversations
      WHERE user_id = ${userId}
      ORDER BY created_at ASC
    `;

    return Response.json(
      messages.map((msg) => ({
        id: msg.id,
        message: msg.message,
        isUser: msg.is_user,
        createdAt: msg.created_at,
      })),
    );
  } catch (error) {
    console.error("Error loading messages:", error);
    return Response.json({ error: "Failed to load messages" }, { status: 500 });
  }
}
