import React from "react";

export default function LogoutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 text-center">
        <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center">
          <span className="text-3xl">👋</span>
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Sign Out</h1>
        <p className="text-gray-600 mb-6">Are you sure you want to sign out?</p>

        <form action="/api/auth/signout" method="POST" className="space-y-4">
          <input type="hidden" name="callbackUrl" value="/account/signin" />
          <button
            type="submit"
            className="w-full bg-red-500 text-white font-semibold py-3 px-6 rounded-xl hover:bg-red-600 transition-all"
          >
            Yes, Sign Out
          </button>
          <a
            href="/parent/(tabs)"
            className="block w-full bg-gray-100 text-gray-700 font-semibold py-3 px-6 rounded-xl hover:bg-gray-200 transition-all"
          >
            Cancel
          </a>
        </form>
      </div>
    </div>
  );
}
