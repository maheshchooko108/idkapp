import { useState } from "react";
import useAuth from "@/utils/useAuth";

export default function SignUpPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [termsAgreed, setTermsAgreed] = useState(false);
  const [marketingOptIn, setMarketingOptIn] = useState(false);
  const [dataUseAgreed, setDataUseAgreed] = useState(false);

  const { signUpWithCredentials, signInWithGoogle } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!email || !password || !name) {
      setError("Please fill in all fields");
      setLoading(false);
      return;
    }

    if (!termsAgreed) {
      setError("Please agree to the Terms of Use and Privacy Policy");
      setLoading(false);
      return;
    }

    try {
      // Store consent preferences in localStorage to be saved during onboarding
      localStorage.setItem("marketingOptIn", marketingOptIn.toString());
      localStorage.setItem("dataUseAgreed", dataUseAgreed.toString());

      await signUpWithCredentials({
        email,
        password,
        name,
        callbackUrl: "/parent/onboarding",
        redirect: true,
      });
    } catch (err) {
      console.error("Sign up error:", err);
      const errorMessages = {
        CredentialsSignin:
          "This email is already registered. Try signing in instead.",
        EmailCreateAccount:
          "This email can't be used. It may already be registered.",
      };

      setError(
        errorMessages[err.message] || "Something went wrong. Please try again.",
      );
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    if (!termsAgreed) {
      setError("Please agree to the Terms of Use and Privacy Policy");
      return;
    }

    try {
      // Store consent preferences in localStorage to be saved during onboarding
      localStorage.setItem("marketingOptIn", marketingOptIn.toString());
      localStorage.setItem("dataUseAgreed", dataUseAgreed.toString());

      await signInWithGoogle({
        callbackUrl: "/parent/onboarding",
        redirect: true,
      });
    } catch (err) {
      console.error("Google sign-in error:", err);
      setError("Could not sign in with Google. Please try again.");
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <form
        noValidate
        onSubmit={onSubmit}
        className="w-full max-w-md rounded-2xl bg-white p-8 shadow-xl"
      >
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-purple-100">
            <span className="text-3xl">✨</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Freedom Skills</h1>
          <p className="mt-2 text-sm text-gray-600">
            Create your parent account
          </p>
        </div>

        <div className="space-y-5">
          {/* Google Sign-In Button */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={!termsAgreed}
            className="w-full rounded-xl border-2 border-gray-200 bg-white px-4 py-3 text-base font-semibold text-gray-700 transition-all hover:border-gray-300 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <div className="flex items-center justify-center gap-3">
              <svg
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M19.8 10.2273C19.8 9.51822 19.7364 8.83642 19.6182 8.18188H10.2V12.0501H15.5891C15.3518 13.3001 14.6182 14.3592 13.5182 15.0683V17.5774H16.8091C18.7091 15.8365 19.8 13.2728 19.8 10.2273Z"
                  fill="#4285F4"
                />
                <path
                  d="M10.2 20C12.9 20 15.1636 19.1046 16.8091 17.5774L13.5182 15.0683C12.5909 15.6683 11.4182 16.0228 10.2 16.0228C7.59545 16.0228 5.38182 14.2637 4.56364 11.9H1.16364V14.4909C2.79545 17.7591 6.24545 20 10.2 20Z"
                  fill="#34A853"
                />
                <path
                  d="M4.56364 11.9C4.36364 11.3 4.25 10.6591 4.25 10C4.25 9.34091 4.36364 8.7 4.56364 8.1V5.50909H1.16364C0.495455 6.85909 0.1 8.38636 0.1 10C0.1 11.6136 0.495455 13.1409 1.16364 14.4909L4.56364 11.9Z"
                  fill="#FBBC05"
                />
                <path
                  d="M10.2 3.97727C11.5273 3.97727 12.7091 4.43182 13.6273 5.29091L16.5545 2.36364C15.1591 1.08636 12.9 0.2 10.2 0.2C6.24545 0.2 2.79545 2.44091 1.16364 5.50909L4.56364 8.1C5.38182 5.73636 7.59545 3.97727 10.2 3.97727Z"
                  fill="#EA4335"
                />
              </svg>
              Continue with Google
            </div>
          </button>

          <div className="flex items-center gap-3">
            <div className="h-px flex-1 bg-gray-200"></div>
            <span className="text-sm text-gray-500">or</span>
            <div className="h-px flex-1 bg-gray-200"></div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-semibold text-gray-700">
              Your Name
            </label>
            <input
              required
              name="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              className="w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-base outline-none transition-all focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-semibold text-gray-700">
              Email
            </label>
            <input
              required
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-base outline-none transition-all focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-semibold text-gray-700">
              Password
            </label>
            <input
              required
              name="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-base outline-none transition-all focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
              placeholder="Create a password"
            />
          </div>

          {/* Consent Checkboxes */}
          <div className="space-y-3 border-t border-gray-200 pt-4">
            {/* Required: Terms of Use */}
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={termsAgreed}
                onChange={(e) => setTermsAgreed(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-500 focus:ring-2 focus:ring-blue-400"
              />
              <span className="text-sm text-gray-700">
                I agree to the{" "}
                <a
                  href="/terms"
                  className="text-blue-500 hover:text-blue-600 underline"
                >
                  Terms of Use
                </a>{" "}
                and{" "}
                <a
                  href="/privacy"
                  className="text-blue-500 hover:text-blue-600 underline"
                >
                  Privacy Policy
                </a>
                . <span className="text-red-500">*</span>
              </span>
            </label>

            {/* Optional: Marketing Emails */}
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={marketingOptIn}
                onChange={(e) => setMarketingOptIn(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-500 focus:ring-2 focus:ring-blue-400"
              />
              <span className="text-sm text-gray-600">
                Send me occasional emails with tips, new features, and ways to
                support Freedom Skills.
              </span>
            </label>

            {/* Optional: Data Use */}
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={dataUseAgreed}
                onChange={(e) => setDataUseAgreed(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-500 focus:ring-2 focus:ring-blue-400"
              />
              <span className="text-sm text-gray-600">
                Allow my anonymized usage data to be used to improve the app
                (never shared or sold).
              </span>
            </label>
          </div>

          {error && (
            <div className="rounded-xl bg-red-50 p-3 text-sm text-red-600">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !termsAgreed}
            className="w-full rounded-xl bg-blue-500 px-4 py-3 text-base font-semibold text-white transition-colors hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Creating Account..." : "Sign Up"}
          </button>

          <p className="text-center text-xs text-gray-500">
            For parents only – kids join with the Family Code
          </p>

          <p className="text-center text-sm text-gray-600">
            Already have an account?{" "}
            <a
              href="/account/signin"
              className="font-semibold text-blue-500 hover:text-blue-600"
            >
              Sign in
            </a>
          </p>
        </div>
      </form>
    </div>
  );
}
