import React from "react";
import { View, Text } from "react-native";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { useAppTheme } from "../utils/theme";

export default function StatCard({
  icon: Icon,
  title,
  value,
  unit,
  color,
  backgroundColor,
}) {
  const { colors } = useAppTheme();

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View
      style={{
        backgroundColor,
        borderRadius: 20,
        padding: 16,
        marginBottom: 12,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          marginBottom: 8,
        }}
      >
        {Icon && <Icon size={20} color={color} />}
        <Text
          style={{
            fontFamily: "Montserrat_500Medium",
            fontSize: 14,
            color: colors.primary,
            marginLeft: Icon ? 8 : 0,
          }}
        >
          {title}
        </Text>
      </View>
      <Text
        style={{
          fontFamily: "Montserrat_600SemiBold",
          fontSize: 28,
          color: colors.primary,
        }}
      >
        {value}
        <Text
          style={{
            fontSize: 16,
            color: colors.secondary,
          }}
        >
          {unit}
        </Text>
      </Text>
    </View>
  );
}
