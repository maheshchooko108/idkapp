import { useState, useEffect } from "react";

export default function useUser() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchUser = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/auth/token");

      if (!response.ok) {
        setData(null);
        return;
      }

      const result = await response.json();
      setData(result.user || null);
    } catch (err) {
      console.error("Error fetching user:", err);
      setError(err);
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const refetch = () => {
    fetchUser();
  };

  return { data, loading, error, refetch };
}
