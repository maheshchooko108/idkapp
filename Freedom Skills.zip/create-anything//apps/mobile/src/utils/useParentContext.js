import { useState, useEffect, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

/**
 * Self-healing parent session hook.
 * Automatically resolves familyId, parentUserId, and familyCode from backend if missing.
 * Used by all parent tabs to ensure they always have the required context.
 */
export function useParentContext() {
  const [familyId, setFamilyId] = useState(null);
  const [parentUserId, setParentUserId] = useState(null);
  const [familyCode, setFamilyCode] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadFromStorage = async () => {
    try {
      const storedFamilyId = await AsyncStorage.getItem("familyId");
      const storedParentUserId = await AsyncStorage.getItem("parentUserId");
      const storedFamilyCode = await AsyncStorage.getItem("familyCode");

      return {
        familyId: storedFamilyId ? parseInt(storedFamilyId) : null,
        parentUserId: storedParentUserId ? parseInt(storedParentUserId) : null,
        familyCode: storedFamilyCode,
      };
    } catch (err) {
      console.error("Error loading from AsyncStorage:", err);
      return { familyId: null, parentUserId: null, familyCode: null };
    }
  };

  const saveToStorage = async (data) => {
    try {
      if (data.familyId) {
        await AsyncStorage.setItem("familyId", String(data.familyId));
      }
      if (data.parentUserId) {
        await AsyncStorage.setItem("parentUserId", String(data.parentUserId));
      }
      if (data.familyCode) {
        await AsyncStorage.setItem("familyCode", data.familyCode);
      }
      console.log("✅ Parent context saved to AsyncStorage:", data);
    } catch (err) {
      console.error("Error saving to AsyncStorage:", err);
    }
  };

  const fetchFromBackend = async () => {
    try {
      console.log("🔄 Fetching parent context from backend...");
      const response = await fetch("/api/families/me");

      if (!response.ok) {
        throw new Error(`Backend returned ${response.status}`);
      }

      const data = await response.json();

      if (!data.ok) {
        throw new Error(data.error || "Failed to load family");
      }

      const resolvedData = {
        familyId: data.family.id,
        parentUserId: data.family.parentUserId,
        familyCode: data.family.familyCode,
      };

      console.log("✅ Parent context resolved from backend:", resolvedData);

      // Save to storage
      await saveToStorage(resolvedData);

      return resolvedData;
    } catch (err) {
      console.error("❌ Error fetching from backend:", err);
      throw err;
    }
  };

  const resolve = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      // Try loading from storage first
      const stored = await loadFromStorage();

      // If all values are present, use them
      if (stored.familyId && stored.parentUserId && stored.familyCode) {
        console.log("✅ Using parent context from AsyncStorage:", stored);
        setFamilyId(stored.familyId);
        setParentUserId(stored.parentUserId);
        setFamilyCode(stored.familyCode);
        setLoading(false);
        return;
      }

      // Otherwise, fetch from backend
      console.log(
        "⚠️ Parent context incomplete in storage, fetching from backend...",
      );
      const resolved = await fetchFromBackend();

      setFamilyId(resolved.familyId);
      setParentUserId(resolved.parentUserId);
      setFamilyCode(resolved.familyCode);
    } catch (err) {
      setError(err.message || "Failed to resolve parent context");
    } finally {
      setLoading(false);
    }
  }, []);

  // Manual repair function (for "Repair/Sync" button)
  const repair = useCallback(async () => {
    console.log("🔧 Manual repair triggered");
    setLoading(true);
    setError(null);

    try {
      const resolved = await fetchFromBackend();
      setFamilyId(resolved.familyId);
      setParentUserId(resolved.parentUserId);
      setFamilyCode(resolved.familyCode);
    } catch (err) {
      setError(err.message || "Failed to repair parent context");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    resolve();
  }, [resolve]);

  return {
    familyId,
    parentUserId,
    familyCode,
    loading,
    error,
    repair,
  };
}
