import AsyncStorage from "@react-native-async-storage/async-storage";

// Stable key names for auth storage
const KEYS = {
  AUTH_TOKEN: "freedom_auth_token",
  AUTH_USER_ID: "freedom_auth_user_id",
};

/**
 * Get the stored auth token
 * @returns {Promise<string|null>} The auth token or null
 */
export async function getAuthToken() {
  try {
    return await AsyncStorage.getItem(KEYS.AUTH_TOKEN);
  } catch (error) {
    console.error("Error getting auth token:", error);
    return null;
  }
}

/**
 * Store the auth token
 * @param {string} token - The auth token to store
 */
export async function setAuthToken(token) {
  try {
    await AsyncStorage.setItem(KEYS.AUTH_TOKEN, token);
  } catch (error) {
    console.error("Error setting auth token:", error);
  }
}

/**
 * Clear the auth token
 */
export async function clearAuthToken() {
  try {
    await AsyncStorage.removeItem(KEYS.AUTH_TOKEN);
  } catch (error) {
    console.error("Error clearing auth token:", error);
  }
}

/**
 * Get the stored auth user ID
 * @returns {Promise<string|null>} The user ID or null
 */
export async function getAuthUserId() {
  try {
    return await AsyncStorage.getItem(KEYS.AUTH_USER_ID);
  } catch (error) {
    console.error("Error getting auth user ID:", error);
    return null;
  }
}

/**
 * Store the auth user ID
 * @param {string} id - The user ID to store
 */
export async function setAuthUserId(id) {
  try {
    await AsyncStorage.setItem(KEYS.AUTH_USER_ID, id);
  } catch (error) {
    console.error("Error setting auth user ID:", error);
  }
}

/**
 * Clear the auth user ID
 */
export async function clearAuthUserId() {
  try {
    await AsyncStorage.removeItem(KEYS.AUTH_USER_ID);
  } catch (error) {
    console.error("Error clearing auth user ID:", error);
  }
}

/**
 * Clear all auth data (token + user ID)
 */
export async function clearAllAuth() {
  await clearAuthToken();
  await clearAuthUserId();
}
