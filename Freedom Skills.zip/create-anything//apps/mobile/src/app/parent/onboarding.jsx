import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { ArrowLeft, Users, Copy, Check } from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../../utils/theme";
import useUser from "../../utils/useUser";
import {
  getAuthToken,
  getAuthUserId,
  clearAllAuth,
} from "../../utils/authStorage";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function ParentOnboardingScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const { data: user, loading: userLoading } = useUser();
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [familyCode, setFamilyCode] = useState("");
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [checkingFamily, setCheckingFamily] = useState(true);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  // Check if family already exists when user is loaded
  useEffect(() => {
    const checkExistingFamily = async () => {
      if (!user || userLoading) {
        setCheckingFamily(false);
        return;
      }

      try {
        // Get auth token for mobile requests
        const token = await getAuthToken();

        if (!token) {
          console.error("No auth token found");
          Alert.alert("Session Expired", "Please sign in again to continue.", [
            { text: "OK", onPress: () => router.replace("/account/signin") },
          ]);
          setCheckingFamily(false);
          return;
        }

        const response = await fetch("/api/families/code", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.status === 401) {
          // Token is invalid or expired
          await clearAllAuth();
          Alert.alert("Session Expired", "Please sign in again to continue.", [
            { text: "OK", onPress: () => router.replace("/account/signin") },
          ]);
          setCheckingFamily(false);
          return;
        }

        if (response.ok) {
          const data = await response.json();
          if (data.familyCode) {
            // Family already exists, redirect to dashboard
            router.replace("/parent/(tabs)");
            return;
          }
        }
      } catch (error) {
        console.error("Error checking family:", error);
      } finally {
        setCheckingFamily(false);
      }
    };

    checkExistingFamily();
  }, [user, userLoading]);

  // Set name from user if available
  useEffect(() => {
    if (user && user.name && !name) {
      setName(user.name);
    }
  }, [user, name]);

  if (!fontsLoaded || (userLoading && checkingFamily)) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: colors.background,
        }}
      >
        <ActivityIndicator size="large" color={colors.blue} />
      </View>
    );
  }

  const handleCreateFamily = async () => {
    if (!name.trim()) {
      Alert.alert("Oops!", "Please enter your name");
      return;
    }

    setLoading(true);
    try {
      // Get auth token using authStorage helpers
      const token = await getAuthToken();
      const authUserId = await getAuthUserId();

      if (!token || !authUserId) {
        await clearAllAuth();
        Alert.alert("Session Expired", "Please sign in again to continue.", [
          { text: "OK", onPress: () => router.replace("/account/signin") },
        ]);
        setLoading(false);
        return;
      }

      console.log("Creating family with token for user:", authUserId);

      // Create the family
      const response = await fetch("/api/families/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ parentName: name }),
      });

      console.log("Create family response status:", response.status);

      if (!response.ok) {
        let errorMessage = "Could not create your family. Please try again.";
        try {
          const errorData = await response.json();
          if (errorData.error) {
            errorMessage = errorData.error;
          }
        } catch (jsonError) {
          console.error("Could not parse error response:", jsonError);
        }

        console.error(
          "Create family failed with status:",
          response.status,
          errorMessage,
        );

        if (response.status === 401) {
          await clearAllAuth();
          Alert.alert("Session Expired", "Please sign in again to continue.", [
            { text: "OK", onPress: () => router.replace("/account/signin") },
          ]);
        } else {
          Alert.alert("Error", errorMessage);
        }
        setLoading(false);
        return;
      }

      const data = await response.json();

      if (!data.ok || !data.familyCode || !data.familyId) {
        console.error("Invalid response from family creation:", data);
        Alert.alert(
          "Error",
          "Family created but no code was returned. Please try signing in again.",
        );
        setLoading(false);
        return;
      }

      console.log(
        "Family created successfully:",
        data.familyCode,
        "familyId:",
        data.familyId,
      );

      // Store familyId and family code in AsyncStorage
      await AsyncStorage.setItem("familyId", String(data.familyId));
      await AsyncStorage.setItem("familyCode", data.familyCode);
      console.log("Stored familyId to AsyncStorage:", data.familyId);

      // Get the parent user record to store parentUserId
      const parentUserResponse = await fetch(`/api/families/me`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (parentUserResponse.ok) {
        const familyData = await parentUserResponse.json();
        if (
          familyData.ok &&
          familyData.family &&
          familyData.family.parentUserId
        ) {
          await AsyncStorage.setItem(
            "parentUserId",
            String(familyData.family.parentUserId),
          );
          console.log(
            "Stored parentUserId to AsyncStorage:",
            familyData.family.parentUserId,
          );
        }
      }

      setFamilyCode(data.familyCode);
      setLoading(false);
      setStep(2);
    } catch (error) {
      console.error("Error creating family:", error);
      Alert.alert("Error", "Could not create your family. Please try again.");
      setLoading(false);
    }
  };

  const handleCopyCode = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleContinue = () => {
    router.replace("/parent/(tabs)");
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 20,
        }}
      >
        {/* Back Button */}
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            width: 40,
            height: 40,
            justifyContent: "center",
            marginBottom: 20,
          }}
        >
          <ArrowLeft size={24} color={colors.primary} />
        </TouchableOpacity>

        {step === 1 ? (
          <>
            {/* Step 1: Name Input */}
            <View style={{ marginBottom: 40 }}>
              <View
                style={{
                  width: 64,
                  height: 64,
                  borderRadius: 32,
                  backgroundColor: colors.blueLight,
                  justifyContent: "center",
                  alignItems: "center",
                  marginBottom: 20,
                }}
              >
                <Users size={32} color={colors.blue} />
              </View>

              <Text
                style={{
                  fontSize: 28,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 8,
                }}
              >
                Welcome, Parent!
              </Text>

              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                  lineHeight: 24,
                }}
              >
                Let's set up your family and get started on this journey
                together.
              </Text>
            </View>

            <View style={{ marginBottom: 40 }}>
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 8,
                }}
              >
                What should we call you?
              </Text>

              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 16,
                  borderWidth: 1,
                  borderColor: colors.borderLight,
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  fontSize: 16,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                }}
                placeholder="Your first name"
                placeholderTextColor={colors.placeholder}
                value={name}
                onChangeText={setName}
                autoFocus
              />
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: colors.blue,
                borderRadius: 16,
                paddingVertical: 16,
                alignItems: "center",
                opacity: loading ? 0.6 : 1,
              }}
              onPress={handleCreateFamily}
              disabled={loading}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_600SemiBold",
                  color: "#FFFFFF",
                }}
              >
                {loading ? "Creating Family..." : "Create Family"}
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            {/* Step 2: Family Code Display */}
            <View style={{ marginBottom: 40 }}>
              <View
                style={{
                  width: 64,
                  height: 64,
                  borderRadius: 32,
                  backgroundColor: colors.greenLight,
                  justifyContent: "center",
                  alignItems: "center",
                  marginBottom: 20,
                }}
              >
                <Check size={32} color={colors.green} />
              </View>

              <Text
                style={{
                  fontSize: 28,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 8,
                }}
              >
                You're all set!
              </Text>

              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                  lineHeight: 24,
                }}
              >
                Share this code with your kids so they can join your family.
              </Text>
            </View>

            <View
              style={{
                backgroundColor: colors.blueLight,
                borderRadius: 20,
                padding: 24,
                marginBottom: 24,
                borderWidth: 2,
                borderColor: colors.blue,
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                  marginBottom: 12,
                  textAlign: "center",
                }}
              >
                Your Family Code
              </Text>

              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 16,
                }}
              >
                <Text
                  style={{
                    fontSize: 36,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.primary,
                    letterSpacing: 4,
                  }}
                >
                  {familyCode}
                </Text>
              </View>

              <TouchableOpacity
                style={{
                  backgroundColor: colors.blue,
                  borderRadius: 12,
                  paddingVertical: 12,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onPress={handleCopyCode}
              >
                {copied ? (
                  <>
                    <Check
                      size={16}
                      color="#FFFFFF"
                      style={{ marginRight: 8 }}
                    />
                    <Text
                      style={{
                        fontSize: 14,
                        fontFamily: "Montserrat_600SemiBold",
                        color: "#FFFFFF",
                      }}
                    >
                      Copied!
                    </Text>
                  </>
                ) : (
                  <>
                    <Copy
                      size={16}
                      color="#FFFFFF"
                      style={{ marginRight: 8 }}
                    />
                    <Text
                      style={{
                        fontSize: 14,
                        fontFamily: "Montserrat_600SemiBold",
                        color: "#FFFFFF",
                      }}
                    >
                      Copy Code
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: colors.blue,
                borderRadius: 16,
                paddingVertical: 16,
                alignItems: "center",
              }}
              onPress={handleContinue}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_600SemiBold",
                  color: "#FFFFFF",
                }}
              >
                Go to Dashboard
              </Text>
            </TouchableOpacity>

            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_500Medium",
                color: colors.placeholder,
                textAlign: "center",
                marginTop: 20,
                lineHeight: 18,
              }}
            >
              You can always find this code in your settings
            </Text>
          </>
        )}
      </ScrollView>
    </View>
  );
}
