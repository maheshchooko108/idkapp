import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch,
  ActivityIndicator,
  Linking,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { Copy, Check, LogOut, Heart, Shield } from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../../../utils/theme";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getAuthToken, clearAllAuth } from "../../../utils/authStorage";
import { DONATION_URL } from "../../../config/constants";

export default function ParentSettingsScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const [familyCode, setFamilyCode] = useState("");
  const [copied, setCopied] = useState(false);
  const [marketingOptIn, setMarketingOptIn] = useState(false);
  const [dataUseAgreed, setDataUseAgreed] = useState(false);
  const [consentLoading, setConsentLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminLoading, setAdminLoading] = useState(true);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadFamilyCode();
    loadConsentSettings();
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    try {
      const token = await getAuthToken();
      if (!token) {
        setAdminLoading(false);
        return;
      }

      const response = await fetch("/api/admin/check", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setIsAdmin(data.isAdmin || false);
      }
    } catch (error) {
      console.error("Error checking admin status:", error);
    } finally {
      setAdminLoading(false);
    }
  };

  const loadFamilyCode = async () => {
    try {
      const token = await getAuthToken();
      if (!token) {
        console.error("No auth token found");
        return;
      }

      const response = await fetch("/api/families/me", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.family) {
          setFamilyCode(data.family.familyCode || "");
        }
      }
    } catch (error) {
      console.error("Error loading family code:", error);
    }
  };

  const loadConsentSettings = async () => {
    try {
      const token = await getAuthToken();
      if (!token) {
        console.error("No auth token found for consent settings");
        setConsentLoading(false);
        return;
      }

      const response = await fetch("/api/profile/consent", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setMarketingOptIn(data.consent?.marketing_opt_in || false);
        setDataUseAgreed(data.consent?.data_use_agreed || false);
      }
    } catch (error) {
      console.error("Error loading consent settings:", error);
    } finally {
      setConsentLoading(false);
    }
  };

  const updateConsent = async (field, value) => {
    try {
      const token = await getAuthToken();
      if (!token) {
        throw new Error("No auth token found");
      }

      const body =
        field === "marketing"
          ? { marketingOptIn: value }
          : { dataUseAgreed: value };

      const response = await fetch("/api/profile/consent", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        throw new Error("Failed to update consent");
      }
    } catch (error) {
      console.error("Error updating consent:", error);
      Alert.alert(
        "Error",
        "Could not update your preferences. Please try again.",
      );
      // Revert the change
      if (field === "marketing") {
        setMarketingOptIn(!value);
      } else {
        setDataUseAgreed(!value);
      }
    }
  };

  const handleMarketingToggle = (value) => {
    setMarketingOptIn(value);
    updateConsent("marketing", value);
  };

  const handleDataUseToggle = (value) => {
    setDataUseAgreed(value);
    updateConsent("dataUse", value);
  };

  const handleCopyCode = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLogout = () => {
    Alert.alert("Log Out", "Are you sure you want to log out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Log Out",
        style: "destructive",
        onPress: async () => {
          try {
            // Clear all auth data using authStorage helper
            await clearAllAuth();

            // Clear any child profile data that might be stored
            await AsyncStorage.removeItem("childProfile");
            await AsyncStorage.removeItem("childUserId");

            // Navigate to role selection
            router.replace("/role-selection");
          } catch (error) {
            console.error("Error during logout:", error);
            // Navigate anyway
            router.replace("/role-selection");
          }
        },
      },
    ]);
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
          }}
        >
          Settings
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Family Code Card */}
        <View
          style={{
            backgroundColor: colors.blueLight,
            borderRadius: 20,
            padding: 20,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: colors.blue,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 12,
            }}
          >
            Your Family Code
          </Text>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 12,
            }}
          >
            <Text
              style={{
                fontSize: 28,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                letterSpacing: 4,
              }}
            >
              {familyCode || "----"}
            </Text>

            <TouchableOpacity
              style={{
                backgroundColor: colors.blue,
                borderRadius: 12,
                width: 40,
                height: 40,
                justifyContent: "center",
                alignItems: "center",
              }}
              onPress={handleCopyCode}
            >
              {copied ? (
                <Check size={18} color="#FFFFFF" />
              ) : (
                <Copy size={18} color="#FFFFFF" />
              )}
            </TouchableOpacity>
          </View>

          <Text
            style={{
              fontSize: 12,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 18,
            }}
          >
            Share this code with your kids so they can join your family
          </Text>
        </View>

        {/* Admin Tools Section */}
        {!adminLoading && isAdmin && (
          <>
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 16,
              }}
            >
              Admin Tools
            </Text>

            <TouchableOpacity
              style={{
                backgroundColor: colors.purpleLight,
                borderRadius: 20,
                padding: 20,
                marginBottom: 24,
                borderWidth: 1,
                borderColor: colors.purple,
                flexDirection: "row",
                alignItems: "center",
              }}
              onPress={() => router.push("/admin/dashboard")}
            >
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: colors.purple,
                  justifyContent: "center",
                  alignItems: "center",
                  marginRight: 16,
                }}
              >
                <Shield size={24} color="#FFFFFF" />
              </View>

              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.primary,
                    marginBottom: 4,
                  }}
                >
                  Admin Dashboard
                </Text>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_500Medium",
                    color: colors.secondary,
                  }}
                >
                  Manage lessons and app theme
                </Text>
              </View>
            </TouchableOpacity>
          </>
        )}

        {/* Privacy & Communication Section */}
        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Privacy & Communication
        </Text>

        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 20,
            padding: 20,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
        >
          {consentLoading ? (
            <ActivityIndicator size="small" color={colors.blue} />
          ) : (
            <>
              {/* Marketing Emails Toggle */}
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "flex-start",
                  justifyContent: "space-between",
                  marginBottom: 20,
                }}
              >
                <View style={{ flex: 1, marginRight: 12 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: "Montserrat_600SemiBold",
                      color: colors.primary,
                      marginBottom: 4,
                    }}
                  >
                    Marketing Emails
                  </Text>
                  <Text
                    style={{
                      fontSize: 12,
                      fontFamily: "Montserrat_500Medium",
                      color: colors.secondary,
                      lineHeight: 18,
                    }}
                  >
                    Receive occasional emails with tips, new features, and ways
                    to support Freedom Skills
                  </Text>
                </View>
                <Switch
                  value={marketingOptIn}
                  onValueChange={handleMarketingToggle}
                  trackColor={{ false: colors.borderLight, true: colors.blue }}
                  thumbColor="#FFFFFF"
                />
              </View>

              {/* Data Use Toggle */}
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "flex-start",
                  justifyContent: "space-between",
                }}
              >
                <View style={{ flex: 1, marginRight: 12 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: "Montserrat_600SemiBold",
                      color: colors.primary,
                      marginBottom: 4,
                    }}
                  >
                    Anonymous Usage Data
                  </Text>
                  <Text
                    style={{
                      fontSize: 12,
                      fontFamily: "Montserrat_500Medium",
                      color: colors.secondary,
                      lineHeight: 18,
                    }}
                  >
                    Allow your anonymized usage data to be used to improve the
                    app (never shared or sold)
                  </Text>
                </View>
                <Switch
                  value={dataUseAgreed}
                  onValueChange={handleDataUseToggle}
                  trackColor={{ false: colors.borderLight, true: colors.blue }}
                  thumbColor="#FFFFFF"
                />
              </View>
            </>
          )}
        </View>

        {/* Support Freedom Skills Section */}
        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Support Freedom Skills
        </Text>

        <View
          style={{
            backgroundColor: colors.greenLight,
            borderRadius: 20,
            padding: 20,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: colors.green,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: colors.green,
                justifyContent: "center",
                alignItems: "center",
                marginRight: 12,
              }}
            >
              <Heart size={20} color="#FFFFFF" />
            </View>
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              Love what we're building?
            </Text>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
              marginBottom: 16,
            }}
          >
            If this app is helping your family, you can support ongoing
            development with a donation. Every contribution helps us make
            Freedom Skills better for everyone.
          </Text>

          <TouchableOpacity
            style={{
              backgroundColor: colors.green,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
            }}
            onPress={() => {
              Linking.openURL(DONATION_URL).catch((err) => {
                console.error("Failed to open donation URL:", err);
                Alert.alert(
                  "Error",
                  "Could not open donation page. Please try again later.",
                );
              });
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: "#FFFFFF",
              }}
            >
              Donate
            </Text>
          </TouchableOpacity>
        </View>

        {/* About Section */}
        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          About
        </Text>

        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 20,
            padding: 20,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
        >
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
              marginBottom: 12,
            }}
          >
            Freedom Skills helps families build healthier relationships with
            technology and develop real-world social skills together.
          </Text>

          <Text
            style={{
              fontSize: 12,
              fontFamily: "Montserrat_500Medium",
              color: colors.placeholder,
            }}
          >
            Version 1.0.0
          </Text>
        </View>

        {/* Logout */}
        <TouchableOpacity
          style={{
            backgroundColor: isDark ? "#3A2020" : "#FFE8E8",
            borderRadius: 16,
            paddingVertical: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            borderWidth: 1,
            borderColor: isDark ? "#5A2020" : "#FFCCCC",
          }}
          onPress={handleLogout}
        >
          <LogOut
            size={18}
            color={isDark ? "#FF8888" : "#CC0000"}
            style={{ marginRight: 8 }}
          />
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: isDark ? "#FF8888" : "#CC0000",
            }}
          >
            Log Out
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
