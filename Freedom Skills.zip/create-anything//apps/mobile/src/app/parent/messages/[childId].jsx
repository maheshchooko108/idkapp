import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { ArrowLeft, Send } from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";
import { useParentContext } from "../../../utils/useParentContext";

export default function ParentMessageScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const params = useLocalSearchParams();
  const childId = parseInt(params.childId);
  const childName = params.childName || "Child";
  const childEmoji = params.childEmoji || "👤";

  const { colors, isDark } = useAppTheme();
  const {
    familyId,
    parentUserId,
    loading: contextLoading,
  } = useParentContext();

  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const scrollViewRef = useRef(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    if (familyId && parentUserId && childId) {
      loadMessages();
      const interval = setInterval(loadMessages, 5000); // Poll every 5 seconds
      return () => clearInterval(interval);
    }
  }, [familyId, parentUserId, childId]);

  const loadMessages = async () => {
    if (!familyId || !childId) return;

    try {
      const response = await fetch(
        `/api/families/messages?familyId=${familyId}&withUserId=${childId}`,
      );
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (err) {
      console.error("Error loading messages:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!newMessage.trim() || !familyId || !parentUserId || !childId) return;

    setSending(true);
    try {
      const response = await fetch("/api/families/messages/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          familyId,
          fromUserId: parentUserId,
          toUserId: childId,
          messageText: newMessage.trim(),
        }),
      });

      if (response.ok) {
        setNewMessage("");
        await loadMessages();
        setTimeout(() => {
          scrollViewRef.current?.scrollToEnd({ animated: true });
        }, 100);
      }
    } catch (err) {
      console.error("Error sending message:", err);
    } finally {
      setSending(false);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  if (contextLoading || loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={colors.blue} />
      </View>
    );
  }

  const MessageBubble = ({ message, isFromMe }) => {
    return (
      <View
        style={{
          alignSelf: isFromMe ? "flex-end" : "flex-start",
          maxWidth: "75%",
          marginBottom: 12,
        }}
      >
        {!isFromMe && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 6,
            }}
          >
            <Text style={{ fontSize: 16, marginRight: 6 }}>{childEmoji}</Text>
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.secondary,
              }}
            >
              {childName}
            </Text>
          </View>
        )}

        <View
          style={{
            backgroundColor: isFromMe ? colors.blue : colors.surface,
            borderRadius: 16,
            padding: 12,
            borderWidth: isFromMe ? 0 : 1,
            borderColor: colors.borderLight,
          }}
        >
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: isFromMe ? "#FFFFFF" : colors.primary,
              lineHeight: 20,
            }}
          >
            {message.message_text}
          </Text>
        </View>

        <Text
          style={{
            fontSize: 11,
            fontFamily: "Montserrat_500Medium",
            color: colors.placeholder,
            marginTop: 4,
            textAlign: isFromMe ? "right" : "left",
          }}
        >
          {new Date(message.created_at).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 12,
          paddingHorizontal: 20,
          paddingBottom: 12,
          borderBottomWidth: 1,
          borderBottomColor: colors.borderLight,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              marginRight: 12,
              padding: 8,
            }}
          >
            <ArrowLeft size={24} color={colors.primary} />
          </TouchableOpacity>

          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: colors.purpleLight,
              justifyContent: "center",
              alignItems: "center",
              marginRight: 12,
            }}
          >
            <Text style={{ fontSize: 20 }}>{childEmoji}</Text>
          </View>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              {childName}
            </Text>
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
              }}
            >
              {messages.length} messages
            </Text>
          </View>
        </View>
      </View>

      {/* Messages */}
      <ScrollView
        ref={scrollViewRef}
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() =>
          scrollViewRef.current?.scrollToEnd({ animated: false })
        }
      >
        {messages.length === 0 ? (
          <View
            style={{
              flex: 1,
              justifyContent: "center",
              alignItems: "center",
              paddingVertical: 60,
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 8,
              }}
            >
              No messages yet
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                textAlign: "center",
              }}
            >
              Start the conversation with {childName}!
            </Text>
          </View>
        ) : (
          messages.map((message) => (
            <MessageBubble
              key={message.id}
              message={message}
              isFromMe={message.from_user_id === parentUserId}
            />
          ))
        )}
      </ScrollView>

      {/* Input */}
      <View
        style={{
          backgroundColor: colors.background,
          borderTopWidth: 1,
          borderTopColor: colors.borderLight,
          paddingHorizontal: 20,
          paddingTop: 12,
          paddingBottom: Math.max(insets.bottom, 12),
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
          }}
        >
          <TextInput
            style={{
              flex: 1,
              backgroundColor: colors.surface,
              borderRadius: 20,
              borderWidth: 1,
              borderColor: colors.borderLight,
              paddingHorizontal: 16,
              paddingVertical: 12,
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
              maxHeight: 100,
            }}
            placeholder={`Message ${childName}...`}
            placeholderTextColor={colors.placeholder}
            value={newMessage}
            onChangeText={setNewMessage}
            multiline
            maxLength={500}
            editable={!sending}
          />

          <TouchableOpacity
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: newMessage.trim() ? colors.blue : colors.surface,
              justifyContent: "center",
              alignItems: "center",
            }}
            onPress={handleSend}
            disabled={!newMessage.trim() || sending}
          >
            {sending ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Send
                size={20}
                color={newMessage.trim() ? "#FFFFFF" : colors.placeholder}
              />
            )}
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}
