import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
  ActivityIndicator,
} from "react-native";
import * as Clipboard from "expo-clipboard";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import {
  Users,
  Copy,
  Trash2,
  RefreshCw,
  AlertCircle,
  Code,
  MessageCircle,
} from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";
import { useParentContext } from "../../../utils/useParentContext";
import { router } from "expo-router";

export default function ParentFamilyScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const { familyId, parentUserId, familyCode, loading, error, repair } =
    useParentContext();

  const [refreshing, setRefreshing] = useState(false);
  const [children, setChildren] = useState([]);
  const [processingChildId, setProcessingChildId] = useState(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    if (familyId) {
      loadChildren();
    }
  }, [familyId]);

  const loadChildren = async () => {
    if (!familyId) return;

    try {
      const response = await fetch("/api/families/me");
      if (response.ok) {
        const data = await response.json();
        if (data.ok) {
          const activeChildren = data.family.children.filter((c) => c.isActive);
          setChildren(activeChildren);
        }
      }
    } catch (err) {
      console.error("Error loading children:", err);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadChildren();
    setRefreshing(false);
  };

  const copyToClipboard = async (text, label) => {
    await Clipboard.setStringAsync(text);
    Alert.alert("Copied!", `${label} copied to clipboard`);
  };

  const handleRegenerateCode = async (childId, childName) => {
    Alert.alert(
      "Regenerate Code?",
      `This will create a new join code for ${childName}. The old code will stop working.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Regenerate",
          style: "destructive",
          onPress: async () => {
            setProcessingChildId(childId);
            try {
              const response = await fetch("/api/children/regenerate-code", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ childUserId: childId }),
              });

              if (response.ok) {
                const data = await response.json();
                Alert.alert(
                  "Code Regenerated! ✅",
                  `New code: ${data.childJoinCode}\n\nWould you like to copy it now?`,
                  [
                    { text: "Later", style: "cancel" },
                    {
                      text: "Copy",
                      onPress: () =>
                        copyToClipboard(
                          data.childJoinCode,
                          `${childName}'s code`,
                        ),
                    },
                  ],
                );
                await loadChildren();
              } else {
                throw new Error("Failed to regenerate code");
              }
            } catch (err) {
              console.error(err);
              Alert.alert(
                "Error",
                "Could not regenerate code. Please try again.",
              );
            } finally {
              setProcessingChildId(null);
            }
          },
        },
      ],
    );
  };

  const handleRemoveChild = async (childId, childName) => {
    Alert.alert(
      "Remove Child?",
      `Are you sure you want to remove ${childName} from the family? Their progress will be preserved but they won't be able to access it.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: async () => {
            setProcessingChildId(childId);
            try {
              const response = await fetch("/api/families/remove-child", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ childUserId: childId }),
              });

              if (response.ok) {
                Alert.alert(
                  "Removed",
                  `${childName} has been removed from the family.`,
                );
                await loadChildren();
              } else {
                throw new Error("Failed to remove child");
              }
            } catch (err) {
              console.error(err);
              Alert.alert("Error", "Could not remove child. Please try again.");
            } finally {
              setProcessingChildId(null);
            }
          },
        },
      ],
    );
  };

  if (!fontsLoaded) {
    return null;
  }

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={colors.blue} />
        <Text
          style={{
            fontSize: 16,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
            marginTop: 16,
          }}
        >
          Loading family...
        </Text>
      </View>
    );
  }

  if (error) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
        }}
      >
        <View
          style={{
            backgroundColor: colors.orangeLight,
            borderRadius: 20,
            padding: 20,
            borderWidth: 2,
            borderColor: colors.orange,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <AlertCircle size={24} color={colors.orange} />
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 8,
              }}
            >
              Error Loading Family
            </Text>
          </View>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              marginBottom: 16,
              lineHeight: 20,
            }}
          >
            {error}
          </Text>
          <TouchableOpacity
            style={{
              backgroundColor: colors.blue,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
            }}
            onPress={repair}
          >
            <RefreshCw size={18} color="#FFFFFF" />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: "#FFFFFF",
                marginLeft: 8,
              }}
            >
              Repair/Sync Session
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 4,
          }}
        >
          Family
        </Text>
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
          }}
        >
          Manage your children and settings
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Family Code Card */}
        <View
          style={{
            backgroundColor: colors.blueLight,
            borderRadius: 20,
            padding: 20,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: colors.blue,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: colors.blue,
                justifyContent: "center",
                alignItems: "center",
                marginRight: 12,
              }}
            >
              <Code size={20} color="#FFFFFF" />
            </View>
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              Family Code
            </Text>
          </View>

          <View
            style={{
              backgroundColor: colors.background,
              borderRadius: 12,
              padding: 16,
              marginBottom: 12,
            }}
          >
            <Text
              style={{
                fontSize: 24,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                textAlign: "center",
                letterSpacing: 2,
              }}
            >
              {familyCode || "Loading..."}
            </Text>
          </View>

          <TouchableOpacity
            style={{
              backgroundColor: colors.blue,
              borderRadius: 12,
              paddingVertical: 12,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
            }}
            onPress={() => copyToClipboard(familyCode, "Family code")}
          >
            <Copy size={16} color="#FFFFFF" />
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_600SemiBold",
                color: "#FFFFFF",
                marginLeft: 6,
              }}
            >
              Copy Family Code
            </Text>
          </TouchableOpacity>
        </View>

        {/* Children List */}
        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Children ({children.length})
        </Text>

        {children.length === 0 ? (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 20,
              padding: 24,
              alignItems: "center",
              borderWidth: 1,
              borderColor: colors.borderLight,
            }}
          >
            <Users size={48} color={colors.secondary} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginTop: 12,
                textAlign: "center",
              }}
            >
              No Children Yet
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                marginTop: 4,
                textAlign: "center",
              }}
            >
              Share your family code with your children so they can join
            </Text>
          </View>
        ) : (
          children.map((child) => {
            const isProcessing = processingChildId === child.id;

            return (
              <View
                key={child.id}
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 20,
                  padding: 20,
                  marginBottom: 16,
                  borderWidth: 1,
                  borderColor: colors.borderLight,
                  opacity: isProcessing ? 0.6 : 1,
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginBottom: 16,
                  }}
                >
                  <View
                    style={{
                      width: 50,
                      height: 50,
                      borderRadius: 25,
                      backgroundColor: colors.purpleLight,
                      justifyContent: "center",
                      alignItems: "center",
                      marginRight: 12,
                    }}
                  >
                    <Text style={{ fontSize: 24 }}>
                      {child.avatarEmoji || "👤"}
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 18,
                        fontFamily: "Montserrat_600SemiBold",
                        color: colors.primary,
                      }}
                    >
                      {child.name}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontFamily: "Montserrat_500Medium",
                        color: colors.secondary,
                      }}
                    >
                      Joined {new Date(child.createdAt).toLocaleDateString()}
                    </Text>
                  </View>
                </View>

                {/* Child Join Code */}
                {child.childJoinCode && (
                  <View
                    style={{
                      backgroundColor: isDark ? "#1A1A1A" : "#F5F5F5",
                      borderRadius: 12,
                      padding: 12,
                      marginBottom: 12,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 11,
                        fontFamily: "Montserrat_600SemiBold",
                        color: colors.secondary,
                        marginBottom: 6,
                      }}
                    >
                      Child's Personal Code:
                    </Text>
                    <Text
                      style={{
                        fontSize: 16,
                        fontFamily: "Montserrat_600SemiBold",
                        color: colors.primary,
                        letterSpacing: 1,
                      }}
                    >
                      {child.childJoinCode}
                    </Text>
                  </View>
                )}

                {/* Action Buttons */}
                <View style={{ gap: 10 }}>
                  <View style={{ flexDirection: "row", gap: 10 }}>
                    <TouchableOpacity
                      style={{
                        flex: 1,
                        backgroundColor: colors.blueLight,
                        borderRadius: 12,
                        paddingVertical: 12,
                        alignItems: "center",
                        flexDirection: "row",
                        justifyContent: "center",
                        borderWidth: 1,
                        borderColor: colors.blue,
                      }}
                      onPress={() =>
                        copyToClipboard(
                          child.childJoinCode,
                          `${child.name}'s code`,
                        )
                      }
                      disabled={isProcessing}
                    >
                      <Copy size={16} color={colors.blue} />
                      <Text
                        style={{
                          fontSize: 14,
                          fontFamily: "Montserrat_600SemiBold",
                          color: colors.primary,
                          marginLeft: 6,
                        }}
                      >
                        Copy Code
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={{
                        flex: 1,
                        backgroundColor: colors.greenLight,
                        borderRadius: 12,
                        paddingVertical: 12,
                        alignItems: "center",
                        flexDirection: "row",
                        justifyContent: "center",
                        borderWidth: 1,
                        borderColor: colors.green,
                      }}
                      onPress={() =>
                        router.push({
                          pathname: "/parent/messages/[childId]",
                          params: {
                            childId: child.id,
                            childName: child.name,
                            childEmoji: child.avatarEmoji || "👤",
                          },
                        })
                      }
                      disabled={isProcessing}
                    >
                      <MessageCircle size={16} color={colors.green} />
                      <Text
                        style={{
                          fontSize: 14,
                          fontFamily: "Montserrat_600SemiBold",
                          color: colors.primary,
                          marginLeft: 6,
                        }}
                      >
                        Message
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <View style={{ flexDirection: "row", gap: 10 }}>
                    <TouchableOpacity
                      style={{
                        flex: 1,
                        backgroundColor: colors.surface,
                        borderRadius: 12,
                        paddingVertical: 12,
                        alignItems: "center",
                        flexDirection: "row",
                        justifyContent: "center",
                        borderWidth: 1,
                        borderColor: colors.borderLight,
                      }}
                      onPress={() => handleRegenerateCode(child.id, child.name)}
                      disabled={isProcessing}
                    >
                      <RefreshCw size={16} color={colors.secondary} />
                      <Text
                        style={{
                          fontSize: 13,
                          fontFamily: "Montserrat_600SemiBold",
                          color: colors.secondary,
                          marginLeft: 6,
                        }}
                      >
                        Regenerate
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={{
                        flex: 1,
                        backgroundColor: colors.surface,
                        borderRadius: 12,
                        paddingVertical: 12,
                        alignItems: "center",
                        flexDirection: "row",
                        justifyContent: "center",
                        borderWidth: 1,
                        borderColor: colors.orange,
                      }}
                      onPress={() => handleRemoveChild(child.id, child.name)}
                      disabled={isProcessing}
                    >
                      <Trash2 size={16} color={colors.orange} />
                      <Text
                        style={{
                          fontSize: 13,
                          fontFamily: "Montserrat_600SemiBold",
                          color: colors.orange,
                          marginLeft: 6,
                        }}
                      >
                        Remove
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            );
          })
        )}

        {/* Repair Button */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.surface,
            borderRadius: 12,
            paddingVertical: 14,
            alignItems: "center",
            flexDirection: "row",
            justifyContent: "center",
            marginTop: 16,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
          onPress={repair}
        >
          <RefreshCw size={18} color={colors.blue} />
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.blue,
              marginLeft: 8,
            }}
          >
            Repair/Sync Parent Session
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
