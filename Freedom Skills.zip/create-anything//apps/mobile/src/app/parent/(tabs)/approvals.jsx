import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
  TextInput,
  ActivityIndicator,
  Clipboard,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import {
  CheckCircle,
  XCircle,
  Star,
  AlertCircle,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";
import { useParentContext } from "../../../utils/useParentContext";

export default function ParentApprovalsScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const { familyId, parentUserId, familyCode, loading, error, repair } =
    useParentContext();

  const [refreshing, setRefreshing] = useState(false);
  const [pendingApprovals, setPendingApprovals] = useState([]);
  const [rejectNote, setRejectNote] = useState("");
  const [rejectingId, setRejectingId] = useState(null);
  const [showDebug, setShowDebug] = useState(false);
  const [processingId, setProcessingId] = useState(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    if (familyId) {
      loadPendingApprovals();
    }
  }, [familyId]);

  const loadPendingApprovals = async () => {
    if (!familyId) return;

    try {
      const response = await fetch(
        `/api/parents/pending-approvals?familyId=${familyId}`,
      );
      if (response.ok) {
        const data = await response.json();
        setPendingApprovals(data);
      }
    } catch (err) {
      console.error("Error loading pending approvals:", err);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadPendingApprovals();
    setRefreshing(false);
  };

  const handleApprove = async (progressId, childName, xpReward) => {
    if (!parentUserId) {
      Alert.alert("Error", "Parent user ID not found");
      return;
    }

    setProcessingId(progressId);

    try {
      const response = await fetch("/api/missions/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          progressId,
          parentUserId,
        }),
      });

      if (response.ok) {
        Alert.alert("Approved! ✅", `${childName} earned ${xpReward} XP!`);
        await loadPendingApprovals();
      } else {
        throw new Error("Failed to approve mission");
      }
    } catch (err) {
      console.error(err);
      Alert.alert("Error", "Could not approve mission. Please try again.");
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (progressId, childName) => {
    if (!parentUserId) {
      Alert.alert("Error", "Parent user ID not found");
      return;
    }

    if (!rejectNote || rejectNote.trim().length < 5) {
      Alert.alert(
        "Note Required",
        "Please provide a reason for rejection (at least 5 characters)",
      );
      return;
    }

    setProcessingId(progressId);

    try {
      const response = await fetch("/api/missions/reject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          progressId,
          parentUserId,
          parentNote: rejectNote.trim(),
        }),
      });

      if (response.ok) {
        Alert.alert("Mission Rejected", `${childName} has been notified.`);
        setRejectingId(null);
        setRejectNote("");
        await loadPendingApprovals();
      } else {
        throw new Error("Failed to reject mission");
      }
    } catch (err) {
      console.error(err);
      Alert.alert("Error", "Could not reject mission. Please try again.");
    } finally {
      setProcessingId(null);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={colors.blue} />
        <Text
          style={{
            fontSize: 16,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
            marginTop: 16,
          }}
        >
          Loading parent context...
        </Text>
      </View>
    );
  }

  if (error) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
        }}
      >
        <View
          style={{
            backgroundColor: colors.orangeLight,
            borderRadius: 20,
            padding: 20,
            borderWidth: 2,
            borderColor: colors.orange,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <AlertCircle size={24} color={colors.orange} />
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 8,
              }}
            >
              Error Loading Context
            </Text>
          </View>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              marginBottom: 16,
              lineHeight: 20,
            }}
          >
            {error}
          </Text>
          <TouchableOpacity
            style={{
              backgroundColor: colors.blue,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
            }}
            onPress={repair}
          >
            <RefreshCw size={18} color="#FFFFFF" />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: "#FFFFFF",
                marginLeft: 8,
              }}
            >
              Repair/Sync Session
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const getDifficultyColor = (difficulty) => {
    if (difficulty === "easy")
      return { bg: colors.greenLight, color: colors.green };
    if (difficulty === "medium")
      return { bg: colors.yellowLight, color: colors.yellow };
    return { bg: colors.orangeLight, color: colors.orange };
  };

  const ApprovalCard = ({ item }) => {
    const difficultyColors = getDifficultyColor(item.difficulty);
    const isRejecting = rejectingId === item.id;
    const isProcessing = processingId === item.id;

    return (
      <View
        style={{
          backgroundColor: colors.surface,
          borderRadius: 20,
          padding: 20,
          marginBottom: 16,
          borderWidth: 1,
          borderColor: colors.borderLight,
          opacity: isProcessing ? 0.6 : 1,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 12,
          }}
        >
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: colors.blueLight,
              justifyContent: "center",
              alignItems: "center",
              marginRight: 12,
            }}
          >
            <Text style={{ fontSize: 20 }}>{item.avatar_emoji || "👤"}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              {item.child_name}
            </Text>
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
              }}
            >
              {new Date(item.completion_requested_at).toLocaleString()}
            </Text>
          </View>
        </View>

        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 8,
          }}
        >
          {item.mission_title}
        </Text>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 8,
            marginBottom: 12,
          }}
        >
          <View
            style={{
              backgroundColor: difficultyColors.bg,
              paddingHorizontal: 10,
              paddingVertical: 4,
              borderRadius: 10,
            }}
          >
            <Text
              style={{
                fontSize: 11,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                textTransform: "capitalize",
              }}
            >
              {item.difficulty}
            </Text>
          </View>

          <View
            style={{
              backgroundColor: colors.yellowLight,
              paddingHorizontal: 10,
              paddingVertical: 4,
              borderRadius: 10,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Star size={12} color={colors.yellow} />
            <Text
              style={{
                fontSize: 11,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 4,
              }}
            >
              +{item.xp_reward} XP
            </Text>
          </View>
        </View>

        <View
          style={{
            backgroundColor: isDark ? "#1A1A1A" : "#F5F5F5",
            borderRadius: 12,
            padding: 12,
            marginBottom: 16,
          }}
        >
          <Text
            style={{
              fontSize: 12,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.secondary,
              marginBottom: 6,
            }}
          >
            What they did:
          </Text>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
              lineHeight: 20,
            }}
          >
            {item.proof_text}
          </Text>
        </View>

        {isRejecting && (
          <View style={{ marginBottom: 12 }}>
            <Text
              style={{
                fontSize: 13,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 8,
              }}
            >
              Why are you rejecting this?
            </Text>
            <TextInput
              style={{
                backgroundColor: colors.background,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.borderLight,
                padding: 12,
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
                minHeight: 60,
                textAlignVertical: "top",
              }}
              placeholder="Example: Please spend more time on this activity..."
              placeholderTextColor={colors.placeholder}
              value={rejectNote}
              onChangeText={setRejectNote}
              multiline
              maxLength={200}
              editable={!isProcessing}
            />
          </View>
        )}

        {!isRejecting ? (
          <View style={{ flexDirection: "row", gap: 12 }}>
            <TouchableOpacity
              style={{
                flex: 1,
                backgroundColor: colors.green,
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                flexDirection: "row",
                justifyContent: "center",
              }}
              onPress={() =>
                handleApprove(item.id, item.child_name, item.xp_reward)
              }
              disabled={isProcessing}
            >
              {isProcessing ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <>
                  <CheckCircle
                    size={18}
                    color={isDark ? colors.primary : "#FFFFFF"}
                  />
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: "Montserrat_600SemiBold",
                      color: isDark ? colors.primary : "#FFFFFF",
                      marginLeft: 6,
                    }}
                  >
                    Approve
                  </Text>
                </>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                flex: 1,
                backgroundColor: colors.surface,
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                flexDirection: "row",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: colors.borderLight,
              }}
              onPress={() => setRejectingId(item.id)}
              disabled={isProcessing}
            >
              <XCircle size={18} color={colors.secondary} />
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.secondary,
                  marginLeft: 6,
                }}
              >
                Reject
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ flexDirection: "row", gap: 12 }}>
            <TouchableOpacity
              style={{
                flex: 1,
                backgroundColor: colors.orangeLight,
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                borderWidth: 1,
                borderColor: colors.orange,
              }}
              onPress={() => handleReject(item.id, item.child_name)}
              disabled={isProcessing}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                }}
              >
                {isProcessing ? "Processing..." : "Confirm Reject"}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                flex: 1,
                backgroundColor: colors.surface,
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                borderWidth: 1,
                borderColor: colors.borderLight,
              }}
              onPress={() => {
                setRejectingId(null);
                setRejectNote("");
              }}
              disabled={isProcessing}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.secondary,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 28,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 4,
              }}
            >
              Pending Approvals
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
              }}
            >
              Review and approve your children's missions
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => setShowDebug(!showDebug)}
            style={{
              padding: 8,
              backgroundColor: showDebug ? colors.blueLight : colors.surface,
              borderRadius: 8,
            }}
          >
            {showDebug ? (
              <ChevronUp size={20} color={colors.blue} />
            ) : (
              <ChevronDown size={20} color={colors.blue} />
            )}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {showDebug && (
          <View
            style={{
              backgroundColor: isDark ? "#1A1A2A" : "#F0F4FF",
              borderRadius: 16,
              padding: 16,
              marginBottom: 20,
              borderWidth: 2,
              borderColor: colors.blue,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <AlertCircle size={20} color={colors.blue} />
              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginLeft: 8,
                }}
              >
                Debug Information
              </Text>
            </View>

            <View style={{ gap: 8 }}>
              <View style={{ flexDirection: "row" }}>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.secondary,
                    width: 120,
                  }}
                >
                  Parent User ID:
                </Text>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_500Medium",
                    color: parentUserId ? colors.green : colors.orange,
                    flex: 1,
                  }}
                >
                  {parentUserId || "❌ NULL"}
                </Text>
              </View>

              <View style={{ flexDirection: "row" }}>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.secondary,
                    width: 120,
                  }}
                >
                  Family ID:
                </Text>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_500Medium",
                    color: familyId ? colors.green : colors.orange,
                    flex: 1,
                  }}
                >
                  {familyId || "❌ NULL"}
                </Text>
              </View>

              <View style={{ flexDirection: "row" }}>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.secondary,
                    width: 120,
                  }}
                >
                  Family Code:
                </Text>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_500Medium",
                    color: familyCode ? colors.green : colors.orange,
                    flex: 1,
                  }}
                >
                  {familyCode || "❌ NULL"}
                </Text>
              </View>

              <View style={{ flexDirection: "row" }}>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.secondary,
                    width: 120,
                  }}
                >
                  Pending Count:
                </Text>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_500Medium",
                    color:
                      pendingApprovals.length > 0
                        ? colors.green
                        : colors.secondary,
                    flex: 1,
                  }}
                >
                  {pendingApprovals.length} items
                </Text>
              </View>
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: colors.blue,
                borderRadius: 12,
                paddingVertical: 12,
                alignItems: "center",
                flexDirection: "row",
                justifyContent: "center",
                marginTop: 12,
              }}
              onPress={repair}
            >
              <RefreshCw size={16} color="#FFFFFF" />
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: "#FFFFFF",
                  marginLeft: 6,
                }}
              >
                Repair/Sync Session
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {pendingApprovals.length === 0 ? (
          <View
            style={{
              backgroundColor: colors.greenLight,
              borderRadius: 20,
              padding: 24,
              alignItems: "center",
              borderWidth: 1,
              borderColor: colors.green,
            }}
          >
            <CheckCircle size={48} color={colors.green} />
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginTop: 12,
                textAlign: "center",
              }}
            >
              All Caught Up!
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                marginTop: 4,
                textAlign: "center",
              }}
            >
              No missions waiting for approval
            </Text>
          </View>
        ) : (
          pendingApprovals.map((item) => (
            <ApprovalCard key={item.id} item={item} />
          ))
        )}
      </ScrollView>
    </View>
  );
}
