import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { TrendingUp, Flame, Target, Heart, Users } from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";
import StatCard from "../../../components/StatCard";

export default function ParentHomeScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const response = await fetch("/api/families/stats");
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error("Error loading stats:", error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStats();
    setRefreshing(false);
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 4,
          }}
        >
          Family Dashboard
        </Text>
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
          }}
        >
          See how everyone's doing today
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Today's Overview Card */}
        <View
          style={{
            backgroundColor: colors.blueLight,
            borderRadius: 20,
            padding: 20,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: colors.blue,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: colors.blue,
                justifyContent: "center",
                alignItems: "center",
                marginRight: 12,
              }}
            >
              <TrendingUp size={20} color="#FFFFFF" />
            </View>
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              Great Progress Today!
            </Text>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            {stats?.completedToday || 0} missions completed •{" "}
            {stats?.activeKids || 0} kids active
          </Text>
        </View>

        {/* Family Stats */}
        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          This Week
        </Text>

        <View style={{ flexDirection: "row", gap: 12, marginBottom: 12 }}>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Flame}
              title="Streaks"
              value={stats?.totalStreaks || 0}
              unit=" days"
              color={colors.orange}
              backgroundColor={colors.orangeLight}
            />
          </View>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Target}
              title="Missions"
              value={stats?.missionsThisWeek || 0}
              unit=" done"
              color={colors.green}
              backgroundColor={colors.greenLight}
            />
          </View>
        </View>

        <View style={{ flexDirection: "row", gap: 12, marginBottom: 24 }}>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Heart}
              title="Real-World"
              value={stats?.realWorldMissions || 0}
              unit=" times"
              color={colors.pink}
              backgroundColor={isDark ? "#2A1A2A" : "#FFE8F0"}
            />
          </View>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Users}
              title="Family XP"
              value={stats?.totalXP || 0}
              unit=""
              color={colors.purple}
              backgroundColor={isDark ? "#2A2044" : "#F0E6FF"}
            />
          </View>
        </View>

        {/* Quick Insights */}
        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Insights
        </Text>

        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 20,
            padding: 20,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            💪 Building Consistency
          </Text>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            Your family is doing great! Completing small challenges consistently
            builds lasting habits.
          </Text>
        </View>

        <View
          style={{
            backgroundColor: colors.greenLight,
            borderRadius: 20,
            padding: 20,
            borderWidth: 1,
            borderColor: colors.green,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            ✨ Keep Encouraging
          </Text>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            A quick "proud of you!" goes a long way. Kids thrive on positive
            reinforcement.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
