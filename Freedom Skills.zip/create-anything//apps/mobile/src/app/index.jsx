import { useEffect, useState } from "react";
import { View, ActivityIndicator } from "react-native";
import { Redirect } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  getAuthToken,
  clearAuthToken,
  clearAuthUserId,
} from "../utils/authStorage";

export default function Index() {
  const [route, setRoute] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const determineRoute = async () => {
      try {
        // Check for parent auth token using authStorage helper
        const authToken = await getAuthToken();

        if (authToken) {
          // Validate token via /api/auth/mobile-me
          try {
            const meResponse = await fetch("/api/auth/mobile-me", {
              headers: {
                Authorization: `Bearer ${authToken}`,
              },
            });

            if (!meResponse.ok) {
              // Token is invalid, clear auth and go to role selection
              await clearAuthToken();
              await clearAuthUserId();
              setRoute("/role-selection");
              setLoading(false);
              return;
            }

            // Token is valid, check for family
            const familyResponse = await fetch("/api/families/me", {
              headers: {
                Authorization: `Bearer ${authToken}`,
              },
            });

            if (familyResponse.ok) {
              const data = await familyResponse.json();
              if (data.ok && data.family) {
                // Family exists, go to dashboard
                setRoute("/parent/(tabs)");
                setLoading(false);
                return;
              }
            }

            // No family or error, go to onboarding
            setRoute("/parent/onboarding");
            setLoading(false);
            return;
          } catch (error) {
            console.error("Error validating token:", error);
            // On error, clear token and go to role selection
            await clearAuthToken();
            await clearAuthUserId();
            setRoute("/role-selection");
            setLoading(false);
            return;
          }
        }

        // Check for child profile
        const storedChild = await AsyncStorage.getItem("childProfile");
        if (storedChild) {
          const childProfile = JSON.parse(storedChild);
          if (childProfile && childProfile.childId) {
            setRoute("/child/(tabs)");
            setLoading(false);
            return;
          }
        }

        // No auth, show role selection
        setRoute("/role-selection");
        setLoading(false);
      } catch (error) {
        console.error("Error determining route:", error);
        setRoute("/role-selection");
        setLoading(false);
      }
    };

    determineRoute();
  }, []);

  if (loading || !route) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return <Redirect href={route} />;
}
