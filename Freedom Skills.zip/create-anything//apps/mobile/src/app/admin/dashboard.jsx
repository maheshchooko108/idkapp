import React from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { BookOpen, Palette, ArrowLeft } from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../../utils/theme";

export default function AdminDashboard() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 12,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <ArrowLeft size={20} color={colors.primary} />
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
              marginLeft: 8,
            }}
          >
            Back to Settings
          </Text>
        </TouchableOpacity>

        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 4,
          }}
        >
          Admin Dashboard
        </Text>
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
          }}
        >
          Manage app content and appearance
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Lesson Manager Card */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.blueLight,
            borderRadius: 20,
            padding: 20,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: colors.blue,
          }}
          onPress={() => router.push("/admin/lessons")}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                width: 48,
                height: 48,
                borderRadius: 24,
                backgroundColor: colors.blue,
                justifyContent: "center",
                alignItems: "center",
                marginRight: 16,
              }}
            >
              <BookOpen size={24} color="#FFFFFF" />
            </View>

            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontSize: 18,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                Practice Lessons
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                }}
              >
                Add, edit, and manage lessons
              </Text>
            </View>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            Manage the library of practice lessons that children can access. Add
            new lessons, edit existing ones, or toggle their visibility.
          </Text>
        </TouchableOpacity>

        {/* Theme Manager Card */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.purpleLight,
            borderRadius: 20,
            padding: 20,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: colors.purple,
          }}
          onPress={() => router.push("/admin/theme")}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                width: 48,
                height: 48,
                borderRadius: 24,
                backgroundColor: colors.purple,
                justifyContent: "center",
                alignItems: "center",
                marginRight: 16,
              }}
            >
              <Palette size={24} color="#FFFFFF" />
            </View>

            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontSize: 18,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                App Theme
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                }}
              >
                Customize colors and appearance
              </Text>
            </View>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            Customize the app's color scheme and visual appearance. Changes will
            apply after users restart the app.
          </Text>
        </TouchableOpacity>

        {/* Info Card */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 20,
            padding: 20,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
        >
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            Admin Access
          </Text>
          <Text
            style={{
              fontSize: 12,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 18,
            }}
          >
            You have admin access because your email is in the admin allowlist.
            Changes you make here will affect all users of the app.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
