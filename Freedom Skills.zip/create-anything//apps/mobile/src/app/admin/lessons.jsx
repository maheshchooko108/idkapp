import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Switch,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import {
  ArrowLeft,
  Plus,
  Edit,
  Trash2,
  Save,
  X,
  Eye,
  EyeOff,
} from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../../utils/theme";
import { getAuthToken } from "../../utils/authStorage";

export default function AdminLessons() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();

  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    category: "",
    body_text: "",
    youtube_url: "",
    is_active: true,
  });

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadLessons();
  }, []);

  const loadLessons = async () => {
    try {
      const token = await getAuthToken();
      const response = await fetch("/api/admin/lessons", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setLessons(data.lessons || []);
      } else {
        Alert.alert("Error", "Failed to load lessons");
      }
    } catch (error) {
      console.error("Error loading lessons:", error);
      Alert.alert("Error", "Failed to load lessons");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.title || !formData.category || !formData.body_text) {
      Alert.alert("Error", "Please fill in all required fields");
      return;
    }

    try {
      const token = await getAuthToken();
      const method = editingId ? "PUT" : "POST";
      const body = editingId ? { ...formData, id: editingId } : formData;

      const response = await fetch("/api/admin/lessons", {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      if (response.ok) {
        Alert.alert("Success", `Lesson ${editingId ? "updated" : "created"}`);
        resetForm();
        loadLessons();
      } else {
        Alert.alert("Error", "Failed to save lesson");
      }
    } catch (error) {
      console.error("Error saving lesson:", error);
      Alert.alert("Error", "Failed to save lesson");
    }
  };

  const handleDelete = (id, title) => {
    Alert.alert(
      "Delete Lesson",
      `Are you sure you want to delete "${title}"?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              const token = await getAuthToken();
              const response = await fetch("/api/admin/lessons", {
                method: "DELETE",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ id }),
              });

              if (response.ok) {
                Alert.alert("Success", "Lesson deleted");
                loadLessons();
              } else {
                Alert.alert("Error", "Failed to delete lesson");
              }
            } catch (error) {
              console.error("Error deleting lesson:", error);
              Alert.alert("Error", "Failed to delete lesson");
            }
          },
        },
      ],
    );
  };

  const handleEdit = (lesson) => {
    setEditingId(lesson.id);
    setFormData({
      title: lesson.title,
      category: lesson.category,
      body_text: lesson.body_text,
      youtube_url: lesson.youtube_url || "",
      is_active: lesson.is_active,
    });
    setIsCreating(true);
  };

  const resetForm = () => {
    setFormData({
      title: "",
      category: "",
      body_text: "",
      youtube_url: "",
      is_active: true,
    });
    setEditingId(null);
    setIsCreating(false);
  };

  if (!fontsLoaded) {
    return null;
  }

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={colors.purple} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 12,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <ArrowLeft size={20} color={colors.primary} />
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
              marginLeft: 8,
            }}
          >
            Back
          </Text>
        </TouchableOpacity>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Text
            style={{
              fontSize: 24,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
            }}
          >
            Practice Lessons
          </Text>

          {!isCreating && (
            <TouchableOpacity
              style={{
                backgroundColor: colors.blue,
                borderRadius: 12,
                width: 40,
                height: 40,
                justifyContent: "center",
                alignItems: "center",
              }}
              onPress={() => setIsCreating(true)}
            >
              <Plus size={20} color="#FFFFFF" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Create/Edit Form */}
        {isCreating && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 20,
              padding: 20,
              marginBottom: 20,
              borderWidth: 2,
              borderColor: colors.blue,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                }}
              >
                {editingId ? "Edit Lesson" : "New Lesson"}
              </Text>

              <TouchableOpacity onPress={resetForm}>
                <X size={24} color={colors.secondary} />
              </TouchableOpacity>
            </View>

            <TextInput
              style={{
                backgroundColor: colors.background,
                borderRadius: 12,
                padding: 12,
                marginBottom: 12,
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
                borderWidth: 1,
                borderColor: colors.borderLight,
              }}
              placeholder="Lesson Title *"
              placeholderTextColor={colors.placeholder}
              value={formData.title}
              onChangeText={(text) => setFormData({ ...formData, title: text })}
            />

            <TextInput
              style={{
                backgroundColor: colors.background,
                borderRadius: 12,
                padding: 12,
                marginBottom: 12,
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
                borderWidth: 1,
                borderColor: colors.borderLight,
              }}
              placeholder="Category (e.g. social-skills) *"
              placeholderTextColor={colors.placeholder}
              value={formData.category}
              onChangeText={(text) =>
                setFormData({ ...formData, category: text })
              }
            />

            <TextInput
              style={{
                backgroundColor: colors.background,
                borderRadius: 12,
                padding: 12,
                marginBottom: 12,
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
                borderWidth: 1,
                borderColor: colors.borderLight,
                minHeight: 100,
              }}
              placeholder="Lesson Body Text *"
              placeholderTextColor={colors.placeholder}
              value={formData.body_text}
              onChangeText={(text) =>
                setFormData({ ...formData, body_text: text })
              }
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />

            <TextInput
              style={{
                backgroundColor: colors.background,
                borderRadius: 12,
                padding: 12,
                marginBottom: 12,
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
                borderWidth: 1,
                borderColor: colors.borderLight,
              }}
              placeholder="YouTube URL (optional)"
              placeholderTextColor={colors.placeholder}
              value={formData.youtube_url}
              onChangeText={(text) =>
                setFormData({ ...formData, youtube_url: text })
              }
              autoCapitalize="none"
            />

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 16,
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                }}
              >
                Active (visible to users)
              </Text>
              <Switch
                value={formData.is_active}
                onValueChange={(value) =>
                  setFormData({ ...formData, is_active: value })
                }
                trackColor={{ false: colors.borderLight, true: colors.blue }}
                thumbColor="#FFFFFF"
              />
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: colors.blue,
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
              }}
              onPress={handleSave}
            >
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Save size={18} color="#FFFFFF" style={{ marginRight: 8 }} />
                <Text
                  style={{
                    fontSize: 16,
                    fontFamily: "Montserrat_600SemiBold",
                    color: "#FFFFFF",
                  }}
                >
                  {editingId ? "Update" : "Create"} Lesson
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        )}

        {/* Lessons List */}
        {lessons.map((lesson) => (
          <View
            key={lesson.id}
            style={{
              backgroundColor: lesson.is_active
                ? colors.surface
                : colors.borderLight,
              borderRadius: 16,
              padding: 16,
              marginBottom: 12,
              borderWidth: 1,
              borderColor: colors.borderLight,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "flex-start",
                marginBottom: 8,
              }}
            >
              <View style={{ flex: 1, marginRight: 12 }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.primary,
                    marginBottom: 4,
                  }}
                >
                  {lesson.title}
                </Text>
                <Text
                  style={{
                    fontSize: 12,
                    fontFamily: "Montserrat_500Medium",
                    color: colors.secondary,
                    marginBottom: 4,
                  }}
                >
                  {lesson.category}
                </Text>
              </View>

              {lesson.is_active ? (
                <View
                  style={{
                    backgroundColor: colors.greenLight,
                    borderRadius: 8,
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                >
                  <Eye size={12} color={colors.green} />
                  <Text
                    style={{
                      fontSize: 10,
                      fontFamily: "Montserrat_600SemiBold",
                      color: colors.green,
                      marginLeft: 4,
                    }}
                  >
                    Active
                  </Text>
                </View>
              ) : (
                <View
                  style={{
                    backgroundColor: colors.surface,
                    borderRadius: 8,
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                >
                  <EyeOff size={12} color={colors.secondary} />
                  <Text
                    style={{
                      fontSize: 10,
                      fontFamily: "Montserrat_600SemiBold",
                      color: colors.secondary,
                      marginLeft: 4,
                    }}
                  >
                    Hidden
                  </Text>
                </View>
              )}
            </View>

            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                lineHeight: 18,
                marginBottom: 12,
              }}
              numberOfLines={2}
            >
              {lesson.body_text}
            </Text>

            <View
              style={{
                flexDirection: "row",
                gap: 8,
              }}
            >
              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor: colors.blue,
                  borderRadius: 10,
                  paddingVertical: 10,
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "center",
                }}
                onPress={() => handleEdit(lesson)}
              >
                <Edit size={16} color="#FFFFFF" style={{ marginRight: 6 }} />
                <Text
                  style={{
                    fontSize: 14,
                    fontFamily: "Montserrat_600SemiBold",
                    color: "#FFFFFF",
                  }}
                >
                  Edit
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor: isDark ? "#3A2020" : "#FFE8E8",
                  borderRadius: 10,
                  paddingVertical: 10,
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "center",
                }}
                onPress={() => handleDelete(lesson.id, lesson.title)}
              >
                <Trash2
                  size={16}
                  color={isDark ? "#FF8888" : "#CC0000"}
                  style={{ marginRight: 6 }}
                />
                <Text
                  style={{
                    fontSize: 14,
                    fontFamily: "Montserrat_600SemiBold",
                    color: isDark ? "#FF8888" : "#CC0000",
                  }}
                >
                  Delete
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        {lessons.length === 0 && (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 32,
              alignItems: "center",
              borderWidth: 1,
              borderColor: colors.borderLight,
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 8,
              }}
            >
              No lessons yet
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                textAlign: "center",
              }}
            >
              Tap the + button to create your first practice lesson
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
