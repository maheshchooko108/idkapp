import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { ArrowLeft, Save, RotateCcw } from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../../utils/theme";
import { getAuthToken } from "../../utils/authStorage";

export default function AdminTheme() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [themeData, setThemeData] = useState({
    primary_color: "#8B5CF6",
    secondary_color: "#6366F1",
    background_top: "#FFFFFF",
    background_bottom: "#F3F4F6",
  });

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadTheme();
  }, []);

  const loadTheme = async () => {
    try {
      const response = await fetch("/api/theme");

      if (response.ok) {
        const data = await response.json();
        if (data.theme) {
          setThemeData({
            primary_color: data.theme.primary_color,
            secondary_color: data.theme.secondary_color,
            background_top: data.theme.background_top,
            background_bottom: data.theme.background_bottom,
          });
        }
      }
    } catch (error) {
      console.error("Error loading theme:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    // Validate hex colors
    const hexRegex = /^#[0-9A-F]{6}$/i;
    if (
      !hexRegex.test(themeData.primary_color) ||
      !hexRegex.test(themeData.secondary_color) ||
      !hexRegex.test(themeData.background_top) ||
      !hexRegex.test(themeData.background_bottom)
    ) {
      Alert.alert(
        "Invalid Color",
        "Please enter valid hex colors (e.g. #8B5CF6)",
      );
      return;
    }

    setSaving(true);
    try {
      const token = await getAuthToken();
      const response = await fetch("/api/admin/theme", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(themeData),
      });

      if (response.ok) {
        Alert.alert(
          "Theme Updated",
          "Theme colors have been updated. Users will see the changes when they restart the app.",
          [{ text: "OK" }],
        );
      } else {
        Alert.alert("Error", "Failed to update theme");
      }
    } catch (error) {
      console.error("Error saving theme:", error);
      Alert.alert("Error", "Failed to update theme");
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    Alert.alert(
      "Reset to Defaults",
      "Are you sure you want to reset to default colors?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Reset",
          style: "destructive",
          onPress: () => {
            setThemeData({
              primary_color: "#8B5CF6",
              secondary_color: "#6366F1",
              background_top: "#FFFFFF",
              background_bottom: "#F3F4F6",
            });
          },
        },
      ],
    );
  };

  if (!fontsLoaded) {
    return null;
  }

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={colors.purple} />
      </View>
    );
  }

  const ColorInput = ({ label, value, onChange, description }) => (
    <View style={{ marginBottom: 20 }}>
      <Text
        style={{
          fontSize: 14,
          fontFamily: "Montserrat_600SemiBold",
          color: colors.primary,
          marginBottom: 8,
        }}
      >
        {label}
      </Text>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          marginBottom: 6,
        }}
      >
        <View
          style={{
            width: 48,
            height: 48,
            borderRadius: 12,
            backgroundColor: value,
            marginRight: 12,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
        />
        <TextInput
          style={{
            flex: 1,
            backgroundColor: colors.background,
            borderRadius: 12,
            padding: 12,
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.primary,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
          placeholder="#000000"
          placeholderTextColor={colors.placeholder}
          value={value}
          onChangeText={onChange}
          autoCapitalize="none"
          maxLength={7}
        />
      </View>
      <Text
        style={{
          fontSize: 11,
          fontFamily: "Montserrat_500Medium",
          color: colors.secondary,
        }}
      >
        {description}
      </Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 12,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <ArrowLeft size={20} color={colors.primary} />
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
              marginLeft: 8,
            }}
          >
            Back
          </Text>
        </TouchableOpacity>

        <Text
          style={{
            fontSize: 24,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
          }}
        >
          App Theme
        </Text>
        <Text
          style={{
            fontSize: 12,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
            marginTop: 4,
          }}
        >
          Customize the app's color scheme
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Info Card */}
        <View
          style={{
            backgroundColor: colors.blueLight,
            borderRadius: 16,
            padding: 16,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: colors.blue,
          }}
        >
          <Text
            style={{
              fontSize: 12,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
              lineHeight: 18,
            }}
          >
            Changes will apply to all users when they restart the app. Use hex
            color codes (e.g. #8B5CF6).
          </Text>
        </View>

        {/* Color Inputs */}
        <ColorInput
          label="Primary Color"
          value={themeData.primary_color}
          onChange={(text) =>
            setThemeData({ ...themeData, primary_color: text })
          }
          description="Main accent color for child UI (purple shade recommended)"
        />

        <ColorInput
          label="Secondary Color"
          value={themeData.secondary_color}
          onChange={(text) =>
            setThemeData({ ...themeData, secondary_color: text })
          }
          description="Accent color for parent UI (blue shade recommended)"
        />

        <ColorInput
          label="Background Top"
          value={themeData.background_top}
          onChange={(text) =>
            setThemeData({ ...themeData, background_top: text })
          }
          description="Top gradient color for backgrounds"
        />

        <ColorInput
          label="Background Bottom"
          value={themeData.background_bottom}
          onChange={(text) =>
            setThemeData({ ...themeData, background_bottom: text })
          }
          description="Bottom gradient color for backgrounds"
        />

        {/* Action Buttons */}
        <View style={{ gap: 12, marginTop: 8 }}>
          <TouchableOpacity
            style={{
              backgroundColor: colors.purple,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
            }}
            onPress={handleSave}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <>
                <Save size={18} color="#FFFFFF" style={{ marginRight: 8 }} />
                <Text
                  style={{
                    fontSize: 16,
                    fontFamily: "Montserrat_600SemiBold",
                    color: "#FFFFFF",
                  }}
                >
                  Save Theme
                </Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              backgroundColor: colors.surface,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: colors.borderLight,
            }}
            onPress={handleReset}
          >
            <RotateCcw
              size={18}
              color={colors.secondary}
              style={{ marginRight: 8 }}
            />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.secondary,
              }}
            >
              Reset to Defaults
            </Text>
          </TouchableOpacity>
        </View>

        {/* Preview Section */}
        <View style={{ marginTop: 32 }}>
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 12,
            }}
          >
            Preview
          </Text>

          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.borderLight,
            }}
          >
            <View
              style={{
                backgroundColor: themeData.primary_color,
                borderRadius: 12,
                padding: 16,
                marginBottom: 12,
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: "#FFFFFF",
                }}
              >
                Primary Color Sample
              </Text>
            </View>

            <View
              style={{
                backgroundColor: themeData.secondary_color,
                borderRadius: 12,
                padding: 16,
                marginBottom: 12,
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: "#FFFFFF",
                }}
              >
                Secondary Color Sample
              </Text>
            </View>

            <View
              style={{
                height: 80,
                borderRadius: 12,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  flex: 1,
                  backgroundColor: themeData.background_top,
                }}
              />
              <View
                style={{
                  flex: 1,
                  backgroundColor: themeData.background_bottom,
                }}
              />
            </View>
            <Text
              style={{
                fontSize: 11,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                marginTop: 8,
                textAlign: "center",
              }}
            >
              Background Gradient Preview
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
