import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { ArrowLeft, Mail, Lock } from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../../utils/theme";
import { useAuthStore } from "../../utils/auth/store";
import { useAuth } from "../../utils/auth/useAuth";
import { setAuthToken, setAuthUserId } from "../../utils/authStorage";

export default function SignInScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const { setAuth } = useAuthStore();
  const { signIn: signInWithGoogle } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleSignIn = async () => {
    setError(null);

    if (!email.trim() || !password.trim()) {
      setError("Please fill in all fields");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/auth/mobile-signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!data.ok) {
        setError(data.error || "Could not sign in. Please try again.");
        setLoading(false);
        return;
      }

      // Store auth token and user ID using authStorage helpers
      await setAuthToken(data.token);
      await setAuthUserId(data.user.id);

      // Check if parent has a family
      try {
        const familyResponse = await fetch("/api/families/me", {
          headers: {
            Authorization: `Bearer ${data.token}`,
          },
        });

        if (familyResponse.ok) {
          const familyData = await familyResponse.json();
          if (familyData.ok && familyData.family) {
            // Family exists, go to dashboard
            router.replace("/parent/(tabs)");
          } else {
            // No family, go to onboarding
            router.replace("/parent/onboarding");
          }
        } else {
          // Default to onboarding if check fails
          router.replace("/parent/onboarding");
        }
      } catch (err) {
        console.error("Error checking family:", err);
        router.replace("/parent/onboarding");
      }
    } catch (err) {
      console.error("Sign in error:", err);
      setError("Could not sign in. Please try again.");
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      // Use the existing Google auth flow
      signInWithGoogle();
    } catch (err) {
      console.error("Google sign-in error:", err);
      setError("Could not sign in with Google. Please try again.");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 40,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Back Button */}
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            width: 40,
            height: 40,
            justifyContent: "center",
            marginBottom: 20,
          }}
        >
          <ArrowLeft size={24} color={colors.primary} />
        </TouchableOpacity>

        {/* Header */}
        <View style={{ alignItems: "center", marginBottom: 32 }}>
          <View
            style={{
              width: 64,
              height: 64,
              borderRadius: 32,
              backgroundColor: colors.purple,
              justifyContent: "center",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Text style={{ fontSize: 32 }}>✨</Text>
          </View>

          <Text
            style={{
              fontSize: 28,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 4,
            }}
          >
            Welcome Back
          </Text>

          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
            }}
          >
            Sign in to your parent account
          </Text>
        </View>

        {/* Google Sign-In Button */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.surface,
            borderRadius: 16,
            borderWidth: 2,
            borderColor: colors.borderLight,
            paddingVertical: 14,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 20,
          }}
          onPress={handleGoogleSignIn}
        >
          <Text
            style={{
              fontSize: 15,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
            }}
          >
            Continue with Google
          </Text>
        </TouchableOpacity>

        {/* Divider */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 24,
          }}
        >
          <View
            style={{ flex: 1, height: 1, backgroundColor: colors.borderLight }}
          />
          <Text
            style={{
              marginHorizontal: 12,
              fontSize: 13,
              fontFamily: "Montserrat_500Medium",
              color: colors.placeholder,
            }}
          >
            or
          </Text>
          <View
            style={{ flex: 1, height: 1, backgroundColor: colors.borderLight }}
          />
        </View>

        {/* Email Input */}
        <View style={{ marginBottom: 16 }}>
          <Text
            style={{
              fontSize: 13,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            Email
          </Text>

          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: colors.borderLight,
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
            }}
          >
            <Mail size={18} color={colors.placeholder} />
            <TextInput
              style={{
                flex: 1,
                paddingVertical: 14,
                paddingLeft: 12,
                fontSize: 15,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
              }}
              placeholder="Enter your email"
              placeholderTextColor={colors.placeholder}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              autoComplete="email"
            />
          </View>
        </View>

        {/* Password Input */}
        <View style={{ marginBottom: 8 }}>
          <Text
            style={{
              fontSize: 13,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            Password
          </Text>

          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: colors.borderLight,
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
            }}
          >
            <Lock size={18} color={colors.placeholder} />
            <TextInput
              style={{
                flex: 1,
                paddingVertical: 14,
                paddingLeft: 12,
                fontSize: 15,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
              }}
              placeholder="Enter your password"
              placeholderTextColor={colors.placeholder}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              autoComplete="password"
            />
          </View>
        </View>

        {/* Forgot Password Link */}
        <TouchableOpacity
          style={{ alignSelf: "flex-end", marginBottom: 24 }}
          onPress={() => router.push("/account/forgot-password")}
        >
          <Text
            style={{
              fontSize: 13,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.blue,
            }}
          >
            Forgot password?
          </Text>
        </TouchableOpacity>

        {/* Error Message */}
        {error && (
          <View
            style={{
              backgroundColor: isDark ? "#3D1F1F" : "#FEE2E2",
              borderRadius: 12,
              padding: 12,
              marginBottom: 16,
            }}
          >
            <Text
              style={{
                fontSize: 13,
                fontFamily: "Montserrat_500Medium",
                color: isDark ? "#FCA5A5" : "#DC2626",
              }}
            >
              {error}
            </Text>
          </View>
        )}

        {/* Sign In Button */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.blue,
            borderRadius: 16,
            paddingVertical: 16,
            alignItems: "center",
            marginBottom: 16,
            opacity: loading ? 0.5 : 1,
          }}
          onPress={handleSignIn}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: "#FFFFFF",
              }}
            >
              Sign In
            </Text>
          )}
        </TouchableOpacity>

        {/* Footer Note */}
        <Text
          style={{
            fontSize: 11,
            fontFamily: "Montserrat_500Medium",
            color: colors.placeholder,
            textAlign: "center",
            marginBottom: 16,
          }}
        >
          For parents only – kids join with the Family Code
        </Text>

        {/* Sign Up Link */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
            }}
          >
            Don't have an account?{" "}
          </Text>
          <TouchableOpacity onPress={() => router.replace("/account/signup")}>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.blue,
              }}
            >
              Sign up
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}
