import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { Users, Sparkles } from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../utils/theme";
import {
  getAuthToken,
  clearAuthToken,
  clearAuthUserId,
} from "../utils/authStorage";

export default function RoleSelectionScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleParentPress = async () => {
    // Check for existing auth token
    const authToken = await getAuthToken();

    if (!authToken) {
      // No token, go to signup
      router.push("/account/signup");
      return;
    }

    // Validate token via /api/auth/mobile-me
    try {
      const meResponse = await fetch("/api/auth/mobile-me", {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });

      if (!meResponse.ok) {
        // Token invalid, clear auth and go to signup
        await clearAuthToken();
        await clearAuthUserId();
        router.push("/account/signup");
        return;
      }

      // Token is valid, check for family
      const familyResponse = await fetch("/api/families/me", {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });

      if (familyResponse.ok) {
        const data = await familyResponse.json();
        if (data.ok && data.family) {
          // Family exists, go to dashboard
          router.push("/parent/(tabs)");
          return;
        }
      }

      // No family, go to onboarding
      router.push("/parent/onboarding");
    } catch (error) {
      console.error("Error checking auth:", error);
      // On error, clear token and go to signup
      await clearAuthToken();
      await clearAuthUserId();
      router.push("/account/signup");
    }
  };

  const handleChildPress = () => {
    // Children NEVER see auth screens, always go to onboarding
    router.push("/child/onboarding");
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      <View
        style={{
          flex: 1,
          paddingTop: insets.top + 40,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 20,
        }}
      >
        {/* Header */}
        <View style={{ alignItems: "center", marginBottom: 60 }}>
          <View
            style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: colors.purple,
              justifyContent: "center",
              alignItems: "center",
              marginBottom: 20,
            }}
          >
            <Sparkles size={40} color={colors.primary} />
          </View>

          <Text
            style={{
              fontSize: 32,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              textAlign: "center",
              marginBottom: 12,
            }}
          >
            Freedom Skills
          </Text>

          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              textAlign: "center",
              lineHeight: 24,
            }}
          >
            Build real-world confidence{"\n"}one mission at a time
          </Text>
        </View>

        {/* Role Cards */}
        <View style={{ flex: 1, justifyContent: "center" }}>
          {/* Parent Card */}
          <TouchableOpacity
            style={{
              backgroundColor: colors.blueLight,
              borderRadius: 24,
              padding: 24,
              marginBottom: 16,
              borderWidth: 2,
              borderColor: colors.blue,
            }}
            onPress={handleParentPress}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: colors.blue,
                  justifyContent: "center",
                  alignItems: "center",
                  marginRight: 16,
                }}
              >
                <Users size={24} color="#FFFFFF" />
              </View>

              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 20,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.primary,
                  }}
                >
                  I'm a Parent
                </Text>
              </View>
            </View>

            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                lineHeight: 20,
              }}
            >
              Guide your family's journey and track progress together
            </Text>
          </TouchableOpacity>

          {/* Child Card */}
          <TouchableOpacity
            style={{
              backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
              borderRadius: 24,
              padding: 24,
              borderWidth: 2,
              borderColor: colors.purple,
            }}
            onPress={handleChildPress}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: colors.purple,
                  justifyContent: "center",
                  alignItems: "center",
                  marginRight: 16,
                }}
              >
                <Sparkles size={24} color={colors.primary} />
              </View>

              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 20,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.primary,
                  }}
                >
                  I'm Ready to Level Up
                </Text>
              </View>
            </View>

            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                lineHeight: 20,
              }}
            >
              Take on missions, earn XP, and build awesome real-world skills
            </Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <Text
          style={{
            fontSize: 12,
            fontFamily: "Montserrat_500Medium",
            color: colors.placeholder,
            textAlign: "center",
            marginTop: 20,
          }}
        >
          Safe, supportive, and designed for families
        </Text>
      </View>
    </View>
  );
}
