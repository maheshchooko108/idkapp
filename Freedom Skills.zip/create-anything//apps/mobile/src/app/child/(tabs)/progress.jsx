import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, RefreshControl } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { Trophy, Flame, Target, Star } from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";
import StatCard from "../../../components/StatCard";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function ChildProgressScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState(null);
  const [childId, setChildId] = useState(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadChildId();
  }, []);

  useEffect(() => {
    if (childId) {
      loadStats();
    }
  }, [childId]);

  const loadChildId = async () => {
    try {
      const storedProfile = await AsyncStorage.getItem("childProfile");
      if (storedProfile) {
        const profile = JSON.parse(storedProfile);
        setChildId(profile.childId);
      }
    } catch (error) {
      console.error("Error loading child ID:", error);
    }
  };

  const loadStats = async () => {
    if (!childId) return;

    try {
      const response = await fetch(`/api/users/progress?userId=${childId}`);
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error("Error loading stats:", error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStats();
    setRefreshing(false);
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 4,
          }}
        >
          Your Progress
        </Text>
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
          }}
        >
          See how far you've come!
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* XP Progress Card */}
        <View
          style={{
            backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
            borderRadius: 20,
            padding: 24,
            marginBottom: 24,
            borderWidth: 2,
            borderColor: colors.purple,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            Total XP Earned
          </Text>

          <Text
            style={{
              fontSize: 48,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 12,
            }}
          >
            {stats?.totalXP || 0}
          </Text>

          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
            }}
          >
            Keep going! Every mission makes you stronger.
          </Text>
        </View>

        {/* Stats Grid */}
        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Your Stats
        </Text>

        <View style={{ flexDirection: "row", gap: 12, marginBottom: 12 }}>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Flame}
              title="Current Streak"
              value={stats?.currentStreak || 0}
              unit=" days"
              color={colors.orange}
              backgroundColor={colors.orangeLight}
            />
          </View>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Trophy}
              title="Longest Streak"
              value={stats?.longestStreak || 0}
              unit=" days"
              color={colors.yellow}
              backgroundColor={colors.yellowLight}
            />
          </View>
        </View>

        <View style={{ flexDirection: "row", gap: 12, marginBottom: 24 }}>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Target}
              title="Missions"
              value={stats?.totalMissions || 0}
              unit=" done"
              color={colors.green}
              backgroundColor={colors.greenLight}
            />
          </View>
          <View style={{ flex: 1 }}>
            <StatCard
              icon={Star}
              title="This Week"
              value={stats?.missionsThisWeek || 0}
              unit=" done"
              color={colors.blue}
              backgroundColor={colors.blueLight}
            />
          </View>
        </View>

        {/* Pending Approvals Card */}
        {stats?.pendingApprovals > 0 && (
          <View
            style={{
              backgroundColor: colors.yellowLight,
              borderRadius: 20,
              padding: 20,
              marginBottom: 24,
              borderWidth: 2,
              borderColor: colors.yellow,
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 4,
              }}
            >
              ⏳ Waiting for Approval
            </Text>
            <Text
              style={{
                fontSize: 32,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 8,
              }}
            >
              {stats.pendingApprovals}
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
              }}
            >
              {stats.pendingApprovals === 1 ? "mission is" : "missions are"}{" "}
              waiting for your parent to approve
            </Text>
          </View>
        )}

        {/* Encouragement Card */}
        <View
          style={{
            backgroundColor: colors.greenLight,
            borderRadius: 20,
            padding: 20,
            borderWidth: 1,
            borderColor: colors.green,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            ✨ Amazing Work!
          </Text>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            You're building real skills that will help you your whole life. Keep
            it up!
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
