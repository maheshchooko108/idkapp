import React from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import {
  ArrowLeft,
  MessageCircle,
  Eye,
  Users,
  Heart,
  Smile,
  Lightbulb,
  Target,
  Sparkles,
} from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";

const SKILL_DATA = {
  conversation: {
    title: "Starting Conversations",
    icon: MessageCircle,
    color: "#3B82F6",
    description:
      "The art of breaking the ice and connecting with others. Small talk isn't small—it's how friendships start!",
    tips: [
      "Start with simple greetings: 'Hi! How's it going?'",
      "Ask open-ended questions: 'What are you working on?'",
      "Share something about yourself to keep it balanced",
      "Listen actively and show genuine interest",
      "Don't worry about awkward pauses—they're normal!",
    ],
    practice: [
      "Greet 3 people today with a smile",
      "Ask someone about their weekend",
      "Share one interesting thing that happened to you",
      "Practice in low-pressure situations like at home",
    ],
  },
  eyeContact: {
    title: "Eye Contact",
    icon: Eye,
    color: "#10B981",
    description:
      "Looking at people when they talk shows you care and helps you connect. It gets easier with practice.",
    tips: [
      "Look at the bridge of someone's nose if direct eye contact feels hard",
      "The 50/70 rule: 50% when speaking, 70% when listening",
      "It's okay to look away sometimes—natural breaks are normal",
      "Practice with people you trust first",
      "Remember: most people appreciate good eye contact",
    ],
    practice: [
      "Practice with family during dinner",
      "Look at the person when they're talking to you",
      "Count to 3 before looking away",
      "Notice how it makes conversations feel different",
    ],
  },
  socialCues: {
    title: "Reading Social Cues",
    icon: Users,
    color: "#8B5CF6",
    description:
      "Learning to notice body language, tone, and energy helps you understand how others feel.",
    tips: [
      "Watch for crossed arms (might mean closed off or uncomfortable)",
      "Notice tone of voice—it says more than words",
      "Pay attention to facial expressions",
      "If someone leans in, they're interested",
      "If they check their phone a lot, they might want to wrap up",
    ],
    practice: [
      "Watch a TV show with sound off—try to guess emotions",
      "Notice when someone seems happy, tired, or distracted",
      "Ask 'How are you?' and really listen to the answer",
      "Practice matching your energy to the room",
    ],
  },
  showingInterest: {
    title: "Showing Interest",
    icon: Heart,
    color: "#EC4899",
    description:
      "Asking questions and really listening makes people feel valued. It's a superpower!",
    tips: [
      "Ask follow-up questions based on what they said",
      "Remember details from past conversations",
      "Put your phone away when talking to someone",
      "Nod and give verbal cues like 'That's cool!' or 'Tell me more'",
      "Show you're listening with your body language",
    ],
    practice: [
      "Have a 5-minute phone-free conversation",
      "Ask someone 3 questions about their interests",
      "Remember one detail and bring it up later",
      "Practice active listening: summarize what they said",
    ],
  },
  stayingPresent: {
    title: "Staying Present",
    icon: Smile,
    color: "#F97316",
    description:
      "Being here, now—not on your phone—helps you enjoy moments and build real memories.",
    tips: [
      "Put your phone in another room during meals",
      "Notice three things you can see, hear, or feel",
      "Take deep breaths to ground yourself in the moment",
      "When your mind wanders, gently bring it back",
      "Quality time beats quantity every time",
    ],
    practice: [
      "Phone-free dinner with family",
      "Go for a walk without headphones",
      "Have one full conversation without checking your phone",
      "Notice how you feel when you're fully present",
    ],
  },
};

export default function SkillDetailScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const params = useLocalSearchParams();
  const skillId = params.id;

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const skill = SKILL_DATA[skillId];

  if (!skill) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Text
          style={{
            fontSize: 16,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
          }}
        >
          Skill not found
        </Text>
      </View>
    );
  }

  const IconComponent = skill.icon;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            width: 40,
            height: 40,
            justifyContent: "center",
            marginBottom: 16,
          }}
        >
          <ArrowLeft size={24} color={colors.primary} />
        </TouchableOpacity>

        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <View
            style={{
              width: 56,
              height: 56,
              borderRadius: 28,
              backgroundColor: skill.color,
              justifyContent: "center",
              alignItems: "center",
              marginRight: 16,
            }}
          >
            <IconComponent size={28} color="#FFFFFF" />
          </View>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 24,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              {skill.title}
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Description */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 20,
            padding: 20,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
        >
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 22,
            }}
          >
            {skill.description}
          </Text>
        </View>

        {/* Tips Section */}
        <View style={{ marginBottom: 20 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Lightbulb size={20} color={colors.yellow} />
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 8,
              }}
            >
              Tips to Remember
            </Text>
          </View>

          {skill.tips.map((tip, index) => (
            <View
              key={index}
              style={{
                backgroundColor: colors.surface,
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                borderWidth: 1,
                borderColor: colors.borderLight,
                flexDirection: "row",
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: skill.color,
                  marginRight: 12,
                }}
              >
                {index + 1}.
              </Text>
              <Text
                style={{
                  flex: 1,
                  fontSize: 14,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  lineHeight: 20,
                }}
              >
                {tip}
              </Text>
            </View>
          ))}
        </View>

        {/* Practice Section */}
        <View style={{ marginBottom: 20 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Target size={20} color={colors.green} />
            <Text
              style={{
                fontSize: 18,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 8,
              }}
            >
              Ways to Practice
            </Text>
          </View>

          {skill.practice.map((item, index) => (
            <View
              key={index}
              style={{
                backgroundColor: colors.greenLight,
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                borderWidth: 1,
                borderColor: colors.green,
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <View
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: colors.green,
                  marginRight: 12,
                }}
              />
              <Text
                style={{
                  flex: 1,
                  fontSize: 14,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  lineHeight: 20,
                }}
              >
                {item}
              </Text>
            </View>
          ))}
        </View>

        {/* Encouragement */}
        <View
          style={{
            backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
            borderRadius: 20,
            padding: 20,
            borderWidth: 2,
            borderColor: colors.purple,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <Sparkles size={20} color={colors.purple} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 8,
              }}
            >
              Remember
            </Text>
          </View>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            Nobody is perfect at this! Everyone feels awkward sometimes. The
            more you practice, the more natural it becomes. You're doing great
            just by learning!
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
