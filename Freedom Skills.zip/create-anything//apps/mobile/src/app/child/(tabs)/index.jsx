import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import {
  Flame,
  Clock,
  MessageCircle,
  Eye,
  Heart,
  Moon,
  Sunrise,
  UtensilsCrossed,
} from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";

const iconMap = {
  MessageCircle,
  UtensilsCrossed,
  Eye,
  Moon,
  Heart,
  Sunrise,
};

export default function ChildMissionsScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const [refreshing, setRefreshing] = useState(false);
  const [missions, setMissions] = useState([]);
  const [streak, setStreak] = useState(0);
  const [totalXP, setTotalXP] = useState(0);
  const [childId, setChildId] = useState(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadChildId();
  }, []);

  useEffect(() => {
    if (childId) {
      loadMissions();
      loadStats();
    }
  }, [childId]);

  const loadChildId = async () => {
    try {
      const storedProfile = await AsyncStorage.getItem("childProfile");
      if (storedProfile) {
        const profile = JSON.parse(storedProfile);
        setChildId(profile.childId);
      }
    } catch (error) {
      console.error("Error loading child ID:", error);
    }
  };

  const loadMissions = async () => {
    try {
      const response = await fetch("/api/missions/daily");
      if (response.ok) {
        const data = await response.json();
        setMissions(data);
      }
    } catch (error) {
      console.error("Error loading missions:", error);
    }
  };

  const loadStats = async () => {
    if (!childId) return;

    try {
      const response = await fetch(`/api/users/stats?userId=${childId}`);
      if (response.ok) {
        const data = await response.json();
        setStreak(data.currentStreak || 0);
        setTotalXP(data.totalXP || 0);
      }
    } catch (error) {
      console.error("Error loading stats:", error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([loadMissions(), loadStats()]);
    setRefreshing(false);
  };

  if (!fontsLoaded) {
    return null;
  }

  const getDifficultyColor = (difficulty) => {
    if (difficulty === "easy")
      return { bg: colors.greenLight, color: colors.green };
    if (difficulty === "medium")
      return { bg: colors.yellowLight, color: colors.yellow };
    return { bg: colors.orangeLight, color: colors.orange };
  };

  const MissionCard = ({ mission }) => {
    const difficultyColors = getDifficultyColor(mission.difficulty);
    const IconComponent = iconMap[mission.iconName] || MessageCircle;

    return (
      <TouchableOpacity
        style={{
          backgroundColor: colors.surface,
          borderRadius: 20,
          padding: 20,
          marginBottom: 16,
          borderWidth: 1,
          borderColor: colors.borderLight,
        }}
        onPress={() => {
          router.push({
            pathname: "/child/mission/[id]",
            params: {
              id: mission.id,
              missionData: JSON.stringify(mission),
            },
          });
        }}
      >
        <View style={{ flexDirection: "row", marginBottom: 12 }}>
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: 24,
              backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
              justifyContent: "center",
              alignItems: "center",
              marginRight: 12,
            }}
          >
            <IconComponent size={24} color={colors.purple} />
          </View>

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 4,
              }}
            >
              {mission.title}
            </Text>

            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 8 }}
            >
              <View
                style={{
                  backgroundColor: difficultyColors.bg,
                  paddingHorizontal: 8,
                  paddingVertical: 3,
                  borderRadius: 12,
                }}
              >
                <Text
                  style={{
                    fontSize: 11,
                    fontFamily: "Montserrat_600SemiBold",
                    color: colors.primary,
                    textTransform: "capitalize",
                  }}
                >
                  {mission.difficulty}
                </Text>
              </View>

              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Clock size={12} color={colors.secondary} />
                <Text
                  style={{
                    fontSize: 11,
                    fontFamily: "Montserrat_500Medium",
                    color: colors.secondary,
                    marginLeft: 4,
                  }}
                >
                  {mission.durationMinutes} min
                </Text>
              </View>
            </View>
          </View>

          <View
            style={{
              backgroundColor: colors.yellowLight,
              borderRadius: 12,
              paddingHorizontal: 10,
              paddingVertical: 6,
              alignSelf: "flex-start",
            }}
          >
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              +{mission.xpReward}
            </Text>
          </View>
        </View>

        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
            lineHeight: 20,
          }}
        >
          {mission.description}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Today's Missions
        </Text>

        {/* Stats Row */}
        <View style={{ flexDirection: "row", gap: 12 }}>
          <View
            style={{
              flex: 1,
              backgroundColor: colors.orangeLight,
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.orange,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 4,
              }}
            >
              <Flame size={16} color={colors.orange} />
              <Text
                style={{
                  fontSize: 12,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                  marginLeft: 6,
                }}
              >
                Streak
              </Text>
            </View>
            <Text
              style={{
                fontSize: 24,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              {streak}
            </Text>
          </View>

          <View
            style={{
              flex: 1,
              backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.purple,
            }}
          >
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                marginBottom: 4,
              }}
            >
              Total XP
            </Text>
            <Text
              style={{
                fontSize: 24,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              {totalXP}
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <Text
          style={{
            fontSize: 16,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Pick a mission to start
        </Text>

        {missions.map((mission) => (
          <MissionCard key={mission.id} mission={mission} />
        ))}
      </ScrollView>
    </View>
  );
}
