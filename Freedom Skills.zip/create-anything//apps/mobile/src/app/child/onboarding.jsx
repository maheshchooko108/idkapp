import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { ArrowLeft, Sparkles, Check } from "lucide-react-native";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAppTheme } from "../../utils/theme";

const AVATAR_EMOJIS = ["✨", "🚀", "⚡", "🌟", "🎯", "💪", "🔥", "🌈"];

export default function ChildOnboardingScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [familyCode, setFamilyCode] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState("✨");
  const [loading, setLoading] = useState(false);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleJoinFamily = async () => {
    if (!familyCode.trim()) {
      Alert.alert("Oops!", "Please enter the family code");
      return;
    }

    setStep(2);
  };

  const handleCreateProfile = async () => {
    if (!name.trim()) {
      Alert.alert("Oops!", "Please enter your name");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/families/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          familyCode,
          name,
          avatarEmoji: selectedAvatar,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to join family");
      }

      const data = await response.json();

      // Store child profile in AsyncStorage so they stay signed in on this device
      const childProfile = {
        childId: data.userId,
        familyId: data.familyId,
        name: name,
        avatarEmoji: selectedAvatar,
      };

      await AsyncStorage.setItem("childProfile", JSON.stringify(childProfile));
      console.log("Child profile stored:", childProfile);

      router.replace("/child/(tabs)");
    } catch (error) {
      console.error(error);
      Alert.alert(
        "Error",
        "Could not join the family. Check your code and try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
          paddingHorizontal: 20,
        }}
      >
        <TouchableOpacity
          onPress={() => (step === 1 ? router.back() : setStep(1))}
          style={{
            width: 40,
            height: 40,
            justifyContent: "center",
            marginBottom: 20,
          }}
        >
          <ArrowLeft size={24} color={colors.primary} />
        </TouchableOpacity>

        {step === 1 ? (
          <>
            <View style={{ marginBottom: 40 }}>
              <View
                style={{
                  width: 64,
                  height: 64,
                  borderRadius: 32,
                  backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
                  justifyContent: "center",
                  alignItems: "center",
                  marginBottom: 20,
                }}
              >
                <Sparkles size={32} color={colors.purple} />
              </View>

              <Text
                style={{
                  fontSize: 28,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 8,
                }}
              >
                Ready to Level Up?
              </Text>

              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                  lineHeight: 24,
                }}
              >
                Enter your family code to get started with missions and
                challenges.
              </Text>
            </View>

            <View style={{ marginBottom: 40 }}>
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 8,
                }}
              >
                Family Code
              </Text>

              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 16,
                  borderWidth: 1,
                  borderColor: colors.borderLight,
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  fontSize: 20,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  letterSpacing: 4,
                  textAlign: "center",
                  textTransform: "uppercase",
                }}
                placeholder="ABCD1234"
                placeholderTextColor={colors.placeholder}
                value={familyCode}
                onChangeText={setFamilyCode}
                autoFocus
                maxLength={8}
                autoCapitalize="characters"
              />
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: colors.purple,
                borderRadius: 16,
                paddingVertical: 16,
                alignItems: "center",
              }}
              onPress={handleJoinFamily}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_600SemiBold",
                  color: isDark ? colors.primary : "#FFFFFF",
                }}
              >
                Continue
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <View style={{ marginBottom: 32 }}>
              <View
                style={{
                  width: 64,
                  height: 64,
                  borderRadius: 32,
                  backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
                  justifyContent: "center",
                  alignItems: "center",
                  marginBottom: 20,
                }}
              >
                <Text style={{ fontSize: 32 }}>{selectedAvatar}</Text>
              </View>

              <Text
                style={{
                  fontSize: 28,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 8,
                }}
              >
                Create Your Profile
              </Text>

              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                  lineHeight: 24,
                }}
              >
                Pick an avatar and tell us your name.
              </Text>
            </View>

            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 12,
                }}
              >
                Choose Your Avatar
              </Text>

              <View
                style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                  gap: 12,
                }}
              >
                {AVATAR_EMOJIS.map((emoji) => (
                  <TouchableOpacity
                    key={emoji}
                    style={{
                      width: 64,
                      height: 64,
                      borderRadius: 32,
                      backgroundColor:
                        selectedAvatar === emoji
                          ? colors.purple
                          : colors.surface,
                      borderWidth: 2,
                      borderColor:
                        selectedAvatar === emoji
                          ? colors.purple
                          : colors.borderLight,
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                    onPress={() => setSelectedAvatar(emoji)}
                  >
                    <Text style={{ fontSize: 32 }}>{emoji}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={{ marginBottom: 32 }}>
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginBottom: 8,
                }}
              >
                Your Name
              </Text>

              <TextInput
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 16,
                  borderWidth: 1,
                  borderColor: colors.borderLight,
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  fontSize: 16,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                }}
                placeholder="What should we call you?"
                placeholderTextColor={colors.placeholder}
                value={name}
                onChangeText={setName}
              />
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: colors.purple,
                borderRadius: 16,
                paddingVertical: 16,
                alignItems: "center",
                opacity: loading ? 0.6 : 1,
              }}
              onPress={handleCreateProfile}
              disabled={loading}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_600SemiBold",
                  color: isDark ? colors.primary : "#FFFFFF",
                }}
              >
                {loading ? "Joining Family..." : "Start My Journey"}
              </Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </View>
  );
}
