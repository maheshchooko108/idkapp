import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { Send, Users, ChevronDown, ChevronUp, Bug } from "lucide-react-native";
import { useAppTheme } from "../../../utils/theme";
import KeyboardAvoidingAnimatedView from "../../../components/KeyboardAvoidingAnimatedView";

// Set to false to hide debug panel in production
const SHOW_DEBUG = true;

export default function ChildMessagesScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();

  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [childId, setChildId] = useState(null);
  const [familyId, setFamilyId] = useState(null);
  const [parentUserId, setParentUserId] = useState(null);
  const scrollViewRef = useRef(null);

  // Debug state
  const [debugExpanded, setDebugExpanded] = useState(false);
  const [lastFetchUrl, setLastFetchUrl] = useState("");
  const [lastFetchTime, setLastFetchTime] = useState(null);
  const [lastFetchCount, setLastFetchCount] = useState(0);
  const [parentResolveMethod, setParentResolveMethod] = useState("");

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadContext();
  }, []);

  useEffect(() => {
    if (childId && familyId) {
      loadMessages();
      const interval = setInterval(loadMessages, 5000);
      return () => clearInterval(interval);
    }
  }, [childId, familyId]);

  const loadContext = async () => {
    try {
      const storedChildId = await AsyncStorage.getItem("childId");
      const storedFamilyId = await AsyncStorage.getItem("familyId");

      if (storedChildId && storedFamilyId) {
        setChildId(parseInt(storedChildId));
        setFamilyId(parseInt(storedFamilyId));

        // FIX: Use the correct endpoint to get parent user ID
        const familyResponse = await fetch(
          `/api/families/parent?familyId=${storedFamilyId}`,
        );
        if (familyResponse.ok) {
          const familyData = await familyResponse.json();
          if (familyData.ok && familyData.parent) {
            setParentUserId(familyData.parent.id);
            setParentResolveMethod(
              `GET /api/families/parent?familyId=${storedFamilyId} → parentId=${familyData.parent.id}`,
            );
          } else {
            setParentResolveMethod(
              `Failed to resolve parent from familyId=${storedFamilyId}`,
            );
          }
        } else {
          setParentResolveMethod(
            `Error: ${familyResponse.status} from /api/families/parent`,
          );
        }
      }
    } catch (err) {
      console.error("Error loading context:", err);
      setParentResolveMethod(`Exception: ${err.message}`);
    }
  };

  const loadMessages = async () => {
    if (!familyId || !childId) return;

    try {
      const url = `/api/families/messages?familyId=${familyId}&withUserId=${childId}`;
      setLastFetchUrl(url);
      setLastFetchTime(new Date());

      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
        setLastFetchCount(data.length);
      } else {
        setLastFetchCount(0);
      }
    } catch (err) {
      console.error("Error loading messages:", err);
      setLastFetchCount(0);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!newMessage.trim() || !familyId || !childId || !parentUserId) return;

    setSending(true);
    try {
      const response = await fetch("/api/families/messages/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          familyId,
          fromUserId: childId,
          toUserId: parentUserId,
          messageText: newMessage.trim(),
        }),
      });

      if (response.ok) {
        setNewMessage("");
        await loadMessages();
        setTimeout(() => {
          scrollViewRef.current?.scrollToEnd({ animated: true });
        }, 100);
      }
    } catch (err) {
      console.error("Error sending message:", err);
    } finally {
      setSending(false);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={colors.purple} />
      </View>
    );
  }

  const MessageBubble = ({ message, isFromMe }) => {
    return (
      <View
        style={{
          alignSelf: isFromMe ? "flex-end" : "flex-start",
          maxWidth: "75%",
          marginBottom: 12,
        }}
      >
        {!isFromMe && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 6,
            }}
          >
            <Text style={{ fontSize: 16, marginRight: 6 }}>👨‍👩‍👧</Text>
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.secondary,
              }}
            >
              Parent
            </Text>
          </View>
        )}

        <View
          style={{
            backgroundColor: isFromMe ? colors.purple : colors.surface,
            borderRadius: 16,
            padding: 12,
            borderWidth: isFromMe ? 0 : 1,
            borderColor: colors.borderLight,
          }}
        >
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: isFromMe ? "#FFFFFF" : colors.primary,
              lineHeight: 20,
            }}
          >
            {message.message_text}
          </Text>
        </View>

        <Text
          style={{
            fontSize: 11,
            fontFamily: "Montserrat_500Medium",
            color: colors.placeholder,
            marginTop: 4,
            textAlign: isFromMe ? "right" : "left",
          }}
        >
          {new Date(message.created_at).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>
      </View>
    );
  };

  return (
    <KeyboardAvoidingAnimatedView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior="padding"
    >
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 4,
          }}
        >
          Messages
        </Text>
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
          }}
        >
          Chat with your parent
        </Text>
      </View>

      {/* DEBUG PANEL */}
      {SHOW_DEBUG && (
        <View
          style={{
            marginHorizontal: 20,
            marginBottom: 12,
            backgroundColor: colors.orangeLight,
            borderRadius: 12,
            borderWidth: 2,
            borderColor: colors.orange,
            overflow: "hidden",
          }}
        >
          <TouchableOpacity
            onPress={() => setDebugExpanded(!debugExpanded)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              padding: 12,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Bug size={16} color={colors.orange} />
              <Text
                style={{
                  fontSize: 12,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.orange,
                  marginLeft: 6,
                }}
              >
                DEBUG PANEL (dev-only)
              </Text>
            </View>
            {debugExpanded ? (
              <ChevronUp size={16} color={colors.orange} />
            ) : (
              <ChevronDown size={16} color={colors.orange} />
            )}
          </TouchableOpacity>

          {debugExpanded && (
            <View
              style={{
                padding: 12,
                paddingTop: 0,
                borderTopWidth: 1,
                borderTopColor: colors.orange,
              }}
            >
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                <Text style={{ fontFamily: "Montserrat_600SemiBold" }}>
                  childUserId:
                </Text>{" "}
                {childId || "null"}
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                <Text style={{ fontFamily: "Montserrat_600SemiBold" }}>
                  familyId:
                </Text>{" "}
                {familyId || "null"}
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                <Text style={{ fontFamily: "Montserrat_600SemiBold" }}>
                  parentUserId:
                </Text>{" "}
                {parentUserId || "null"}
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                <Text style={{ fontFamily: "Montserrat_600SemiBold" }}>
                  Parent Resolve:
                </Text>{" "}
                {parentResolveMethod || "Not attempted"}
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                <Text style={{ fontFamily: "Montserrat_600SemiBold" }}>
                  Last Fetch URL:
                </Text>{" "}
                {lastFetchUrl || "Not fetched yet"}
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                  marginBottom: 4,
                }}
              >
                <Text style={{ fontFamily: "Montserrat_600SemiBold" }}>
                  Last Fetch Time:
                </Text>{" "}
                {lastFetchTime ? lastFetchTime.toLocaleTimeString() : "Never"}
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.primary,
                }}
              >
                <Text style={{ fontFamily: "Montserrat_600SemiBold" }}>
                  Messages Returned:
                </Text>{" "}
                {lastFetchCount}
              </Text>
            </View>
          )}
        </View>
      )}

      {/* Messages */}
      <ScrollView
        ref={scrollViewRef}
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() =>
          scrollViewRef.current?.scrollToEnd({ animated: false })
        }
      >
        {messages.length === 0 ? (
          <View
            style={{
              flex: 1,
              justifyContent: "center",
              alignItems: "center",
              paddingVertical: 60,
            }}
          >
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: colors.purpleLight,
                justifyContent: "center",
                alignItems: "center",
                marginBottom: 20,
              }}
            >
              <Users size={40} color={colors.purple} />
            </View>
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 8,
                textAlign: "center",
              }}
            >
              No messages yet
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                textAlign: "center",
                paddingHorizontal: 40,
              }}
            >
              Start a conversation with your parent!
            </Text>
          </View>
        ) : (
          messages.map((message) => (
            <MessageBubble
              key={message.id}
              message={message}
              isFromMe={message.from_user_id === childId}
            />
          ))
        )}
      </ScrollView>

      {/* Input */}
      <View
        style={{
          backgroundColor: colors.background,
          borderTopWidth: 1,
          borderTopColor: colors.borderLight,
          paddingHorizontal: 20,
          paddingTop: 12,
          paddingBottom: Math.max(insets.bottom, 12),
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
          }}
        >
          <TextInput
            style={{
              flex: 1,
              backgroundColor: colors.surface,
              borderRadius: 20,
              borderWidth: 1,
              borderColor: colors.borderLight,
              paddingHorizontal: 16,
              paddingVertical: 12,
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
              maxHeight: 100,
            }}
            placeholder="Type your message..."
            placeholderTextColor={colors.placeholder}
            value={newMessage}
            onChangeText={setNewMessage}
            multiline
            maxLength={500}
            editable={!sending}
          />

          <TouchableOpacity
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: newMessage.trim()
                ? colors.purple
                : colors.surface,
              justifyContent: "center",
              alignItems: "center",
            }}
            onPress={handleSend}
            disabled={!newMessage.trim() || sending}
          >
            {sending ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Send
                size={20}
                color={newMessage.trim() ? "#FFFFFF" : colors.placeholder}
              />
            )}
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingAnimatedView>
  );
}
