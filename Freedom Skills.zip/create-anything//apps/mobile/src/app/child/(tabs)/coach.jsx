import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import { Send, Sparkles } from "lucide-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { useAppTheme } from "../../../utils/theme";

export default function ChildCoachScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollViewRef = useRef();
  const [childId, setChildId] = useState(null);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadChildId();
  }, []);

  useEffect(() => {
    if (childId) {
      loadMessages();
    }
  }, [childId]);

  const loadChildId = async () => {
    try {
      const storedChildId = await AsyncStorage.getItem("childUserId");
      if (!storedChildId) {
        router.replace("/child/onboarding");
        return;
      }
      setChildId(storedChildId);
    } catch (error) {
      console.error("Error loading child ID:", error);
    }
  };

  const loadMessages = async () => {
    try {
      const response = await fetch(`/api/coach/messages?childId=${childId}`);
      if (response.ok) {
        const data = await response.json();
        if (data.length === 0) {
          setMessages([
            {
              id: 0,
              message:
                "Hey! I'm your Freedom Skills coach. I'm here to support you on your journey. What's on your mind?",
              isUser: false,
            },
          ]);
        } else {
          setMessages(data);
        }
      }
    } catch (error) {
      console.error("Error loading messages:", error);
    }
  };

  const handleSend = async () => {
    if (!inputText.trim() || loading || !childId) return;

    const userMessage = inputText.trim();
    setInputText("");

    setMessages((prev) => [
      ...prev,
      { id: Date.now(), message: userMessage, isUser: true },
    ]);
    setLoading(true);

    try {
      const response = await fetch("/api/coach/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage, childId }),
      });

      if (response.ok) {
        const data = await response.json();
        setMessages((prev) => [
          ...prev,
          { id: Date.now() + 1, message: data.reply, isUser: false },
        ]);
      }
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 1,
          message:
            "I'm having trouble connecting right now. Let's try again in a moment.",
          isUser: false,
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  const MessageBubble = ({ message, isUser }) => (
    <View
      style={{
        alignSelf: isUser ? "flex-end" : "flex-start",
        maxWidth: "80%",
        marginBottom: 12,
      }}
    >
      <View
        style={{
          backgroundColor: isUser ? colors.purple : colors.surface,
          borderRadius: 20,
          padding: 16,
          borderWidth: isUser ? 0 : 1,
          borderColor: colors.borderLight,
        }}
      >
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: isUser && !isDark ? "#FFFFFF" : colors.primary,
            lineHeight: 20,
          }}
        >
          {message}
        </Text>
      </View>
    </View>
  );

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={90}
    >
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: 24,
              backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
              justifyContent: "center",
              alignItems: "center",
              marginRight: 12,
            }}
          >
            <Sparkles size={24} color={colors.purple} />
          </View>

          <View>
            <Text
              style={{
                fontSize: 20,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
              }}
            >
              Your Coach
            </Text>
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
              }}
            >
              Always here to help
            </Text>
          </View>
        </View>
      </View>

      {/* Messages */}
      <ScrollView
        ref={scrollViewRef}
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() =>
          scrollViewRef.current?.scrollToEnd({ animated: true })
        }
      >
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg.message}
            isUser={msg.isUser}
          />
        ))}

        {loading && (
          <View
            style={{
              alignSelf: "flex-start",
              backgroundColor: colors.surface,
              borderRadius: 20,
              padding: 16,
              borderWidth: 1,
              borderColor: colors.borderLight,
              marginBottom: 12,
            }}
          >
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
              }}
            >
              Thinking...
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Input */}
      <View
        style={{
          backgroundColor: colors.surface,
          borderTopWidth: 1,
          borderTopColor: colors.border,
          paddingHorizontal: 20,
          paddingTop: 12,
          paddingBottom: insets.bottom + 12,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <TextInput
            style={{
              flex: 1,
              backgroundColor: colors.background,
              borderRadius: 24,
              borderWidth: 1,
              borderColor: colors.borderLight,
              paddingHorizontal: 16,
              paddingVertical: 12,
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.primary,
            }}
            placeholder="Type your message..."
            placeholderTextColor={colors.placeholder}
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={500}
          />

          <TouchableOpacity
            style={{
              width: 48,
              height: 48,
              borderRadius: 24,
              backgroundColor: colors.purple,
              justifyContent: "center",
              alignItems: "center",
              opacity: inputText.trim() && !loading ? 1 : 0.5,
            }}
            onPress={handleSend}
            disabled={!inputText.trim() || loading}
          >
            <Send size={20} color={isDark ? colors.primary : "#FFFFFF"} />
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}
