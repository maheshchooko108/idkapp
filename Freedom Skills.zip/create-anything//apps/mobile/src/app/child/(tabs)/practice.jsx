import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Linking,
  Alert,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import {
  Book,
  Eye,
  MessageCircle,
  Users,
  Heart,
  Smile,
  Play,
} from "lucide-react-native";
import { router } from "expo-router";
import { useAppTheme } from "../../../utils/theme";

export default function ChildPracticeScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadLessons();
  }, []);

  const loadLessons = async () => {
    try {
      const response = await fetch("/api/lessons/active");
      if (response.ok) {
        const data = await response.json();
        setLessons(data.lessons || []);
      }
    } catch (error) {
      console.error("Error loading lessons:", error);
    } finally {
      setLoading(false);
    }
  };

  // Map categories to icons and colors
  const getCategoryStyle = (category) => {
    const lowerCategory = category.toLowerCase();

    if (lowerCategory.includes("conversation")) {
      return {
        icon: MessageCircle,
        color: colors.blue,
        bgColor: colors.blueLight,
      };
    } else if (lowerCategory.includes("eye")) {
      return { icon: Eye, color: colors.green, bgColor: colors.greenLight };
    } else if (lowerCategory.includes("social")) {
      return {
        icon: Users,
        color: colors.purple,
        bgColor: isDark ? "#2A2044" : "#F0E6FF",
      };
    } else if (
      lowerCategory.includes("interest") ||
      lowerCategory.includes("heart")
    ) {
      return {
        icon: Heart,
        color: colors.pink,
        bgColor: isDark ? "#2A1A2A" : "#FFE8F0",
      };
    } else if (
      lowerCategory.includes("present") ||
      lowerCategory.includes("mindful")
    ) {
      return { icon: Smile, color: colors.orange, bgColor: colors.orangeLight };
    } else {
      return {
        icon: Book,
        color: colors.purple,
        bgColor: isDark ? "#2A2044" : "#F0E6FF",
      };
    }
  };

  const handleVideoPress = (youtubeUrl) => {
    if (youtubeUrl) {
      Linking.openURL(youtubeUrl).catch(() => {
        Alert.alert("Error", "Could not open video");
      });
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={colors.purple} />
      </View>
    );
  }

  const LessonCard = ({ lesson }) => {
    const { icon: Icon, color, bgColor } = getCategoryStyle(lesson.category);

    return (
      <View
        style={{
          backgroundColor: bgColor,
          borderRadius: 20,
          padding: 20,
          marginBottom: 16,
          borderWidth: 1,
          borderColor: color,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 12,
          }}
        >
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: 24,
              backgroundColor: color,
              justifyContent: "center",
              alignItems: "center",
              marginRight: 12,
            }}
          >
            <Icon size={24} color="#FFFFFF" />
          </View>

          <Text
            style={{
              fontSize: 18,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              flex: 1,
            }}
          >
            {lesson.title}
          </Text>
        </View>

        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
            lineHeight: 20,
            marginBottom: lesson.youtube_url ? 12 : 0,
          }}
        >
          {lesson.body_text}
        </Text>

        {lesson.youtube_url && (
          <TouchableOpacity
            style={{
              backgroundColor: color,
              borderRadius: 12,
              paddingVertical: 10,
              paddingHorizontal: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => handleVideoPress(lesson.youtube_url)}
          >
            <Play size={16} color="#FFFFFF" style={{ marginRight: 6 }} />
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_600SemiBold",
                color: "#FFFFFF",
              }}
            >
              Watch Video
            </Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 4,
          }}
        >
          Real-Life Practice
        </Text>
        <Text
          style={{
            fontSize: 14,
            fontFamily: "Montserrat_500Medium",
            color: colors.secondary,
          }}
        >
          Skills you're building
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View
          style={{
            backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
            borderRadius: 20,
            padding: 20,
            marginBottom: 24,
            borderWidth: 2,
            borderColor: colors.purple,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 8,
            }}
          >
            💡 Why These Matter
          </Text>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 20,
            }}
          >
            These skills help you connect with people, feel confident, and enjoy
            life beyond the screen.
          </Text>
        </View>

        <Text
          style={{
            fontSize: 18,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 16,
          }}
        >
          Core Skills
        </Text>

        {lessons.length > 0 ? (
          lessons.map((lesson) => (
            <LessonCard key={lesson.id} lesson={lesson} />
          ))
        ) : (
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 16,
              padding: 32,
              alignItems: "center",
              borderWidth: 1,
              borderColor: colors.borderLight,
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 8,
              }}
            >
              No lessons available
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                textAlign: "center",
              }}
            >
              Check back soon for new practice lessons
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
