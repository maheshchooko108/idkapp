import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import {
  useFonts,
  Montserrat_500Medium,
  Montserrat_600SemiBold,
} from "@expo-google-fonts/montserrat";
import {
  ArrowLeft,
  Clock,
  Star,
  Play,
  CheckCircle,
  Sparkles,
  Send,
  HourglassIcon,
} from "lucide-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAppTheme } from "../../../utils/theme";

export default function MissionDetailScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useAppTheme();
  const params = useLocalSearchParams();
  const [mission, setMission] = useState(null);
  const [childId, setChildId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [proofText, setProofText] = useState("");
  const [showProofSection, setShowProofSection] = useState(false);

  const [fontsLoaded] = useFonts({
    Montserrat_500Medium,
    Montserrat_600SemiBold,
  });

  useEffect(() => {
    loadChildId();
  }, []);

  useEffect(() => {
    if (params.missionData) {
      try {
        setMission(JSON.parse(params.missionData));
      } catch (error) {
        console.error("Error parsing mission data:", error);
      }
    }
  }, [params.missionData]);

  useEffect(() => {
    let timer;
    if (status === "in_progress" && timeRemaining > 0) {
      timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [status, timeRemaining]);

  const loadChildId = async () => {
    try {
      const storedProfile = await AsyncStorage.getItem("childProfile");
      if (storedProfile) {
        const profile = JSON.parse(storedProfile);
        setChildId(profile.childId);
      }
    } catch (error) {
      console.error("Error loading child ID:", error);
    }
  };

  const handleStartMission = async () => {
    if (!childId || !mission) return;

    setLoading(true);
    try {
      const response = await fetch("/api/missions/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: childId,
          missionId: mission.id,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setStatus(data.status);
        setTimeRemaining(mission.durationMinutes * 60);
        Alert.alert(
          "Mission Started! 🚀",
          "Go complete this mission and come back when you're done!",
        );
      } else {
        throw new Error("Failed to start mission");
      }
    } catch (error) {
      console.error(error);
      Alert.alert("Error", "Could not start the mission. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleRequestCompletion = async () => {
    if (!childId || !mission) return;

    if (!proofText || proofText.trim().length < 10) {
      Alert.alert(
        "Reflection Required",
        "Please write at least a short reflection about what you did (1-2 sentences).",
      );
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/missions/request-complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: childId,
          missionId: mission.id,
          proofType: "reflection",
          proofText: proofText.trim(),
        }),
      });

      if (response.ok) {
        setStatus("pending_approval");
        setShowProofSection(false);
        Alert.alert(
          "Sent to Parent! 📬",
          "Your parent will review your mission and approve it soon!",
        );
      } else {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to request completion");
      }
    } catch (error) {
      console.error(error);
      Alert.alert(
        "Error",
        error.message || "Could not submit for approval. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  if (!fontsLoaded || !mission) {
    return null;
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getDifficultyColor = (difficulty) => {
    if (difficulty === "easy")
      return { bg: colors.greenLight, color: colors.green };
    if (difficulty === "medium")
      return { bg: colors.yellowLight, color: colors.yellow };
    return { bg: colors.orangeLight, color: colors.orange };
  };

  const difficultyColors = getDifficultyColor(mission.difficulty);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? "light" : "dark"} />

      {/* Header */}
      <View
        style={{
          backgroundColor: colors.background,
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            width: 40,
            height: 40,
            justifyContent: "center",
            marginBottom: 16,
          }}
        >
          <ArrowLeft size={24} color={colors.primary} />
        </TouchableOpacity>

        <Text
          style={{
            fontSize: 28,
            fontFamily: "Montserrat_600SemiBold",
            color: colors.primary,
            marginBottom: 8,
          }}
        >
          {mission.title}
        </Text>

        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <View
            style={{
              backgroundColor: difficultyColors.bg,
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 12,
            }}
          >
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                textTransform: "capitalize",
              }}
            >
              {mission.difficulty}
            </Text>
          </View>

          <View
            style={{
              backgroundColor: colors.yellowLight,
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 12,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Star size={14} color={colors.yellow} />
            <Text
              style={{
                fontSize: 12,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 4,
              }}
            >
              +{mission.xpReward} XP
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Description Card */}
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 20,
            padding: 20,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: colors.borderLight,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
              marginBottom: 12,
            }}
          >
            What You'll Do
          </Text>
          <Text
            style={{
              fontSize: 14,
              fontFamily: "Montserrat_500Medium",
              color: colors.secondary,
              lineHeight: 22,
            }}
          >
            {mission.description}
          </Text>
        </View>

        {/* Time Card */}
        <View
          style={{
            backgroundColor: colors.blueLight,
            borderRadius: 20,
            padding: 20,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: colors.blue,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <Clock size={20} color={colors.blue} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 8,
              }}
            >
              Time Commitment
            </Text>
          </View>
          <Text
            style={{
              fontSize: 24,
              fontFamily: "Montserrat_600SemiBold",
              color: colors.primary,
            }}
          >
            {mission.durationMinutes} minutes
          </Text>

          {status === "in_progress" && timeRemaining > 0 && (
            <View style={{ marginTop: 12 }}>
              <Text
                style={{
                  fontSize: 12,
                  fontFamily: "Montserrat_500Medium",
                  color: colors.secondary,
                  marginBottom: 4,
                }}
              >
                Timer (optional)
              </Text>
              <Text
                style={{
                  fontSize: 32,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.blue,
                }}
              >
                {formatTime(timeRemaining)}
              </Text>
            </View>
          )}
        </View>

        {/* Proof Section (when mission is in progress) */}
        {status === "in_progress" && showProofSection && (
          <View
            style={{
              backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
              borderRadius: 20,
              padding: 20,
              marginBottom: 16,
              borderWidth: 2,
              borderColor: colors.purple,
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginBottom: 8,
              }}
            >
              ✍️ Tell Your Parent What You Did
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                marginBottom: 12,
                lineHeight: 18,
              }}
            >
              Write 1-2 sentences about what you did. Who did you talk to? What
              happened?
            </Text>
            <TextInput
              style={{
                backgroundColor: colors.background,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: colors.borderLight,
                padding: 12,
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.primary,
                minHeight: 80,
                textAlignVertical: "top",
              }}
              placeholder="Example: I had a 5-minute conversation with my neighbor about their garden. I made eye contact and asked questions."
              placeholderTextColor={colors.placeholder}
              value={proofText}
              onChangeText={setProofText}
              multiline
              maxLength={300}
            />
            <Text
              style={{
                fontSize: 11,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                marginTop: 4,
              }}
            >
              {proofText.length}/300 characters
            </Text>
          </View>
        )}

        {/* Encouragement Card */}
        {status !== "pending_approval" && status !== "approved" && (
          <View
            style={{
              backgroundColor: isDark ? "#2A2044" : "#F0E6FF",
              borderRadius: 20,
              padding: 20,
              marginBottom: 24,
              borderWidth: 2,
              borderColor: colors.purple,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Sparkles size={20} color={colors.purple} />
              <Text
                style={{
                  fontSize: 16,
                  fontFamily: "Montserrat_600SemiBold",
                  color: colors.primary,
                  marginLeft: 8,
                }}
              >
                You Got This!
              </Text>
            </View>
            <Text
              style={{
                fontSize: 14,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                lineHeight: 20,
              }}
            >
              This mission will help you build real skills and confidence. Take
              your time and enjoy the experience!
            </Text>
          </View>
        )}

        {/* Action Buttons */}
        {!status && (
          <TouchableOpacity
            style={{
              backgroundColor: colors.purple,
              borderRadius: 16,
              paddingVertical: 18,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
              opacity: loading ? 0.6 : 1,
            }}
            onPress={handleStartMission}
            disabled={loading}
          >
            <Play size={20} color={isDark ? colors.primary : "#FFFFFF"} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: isDark ? colors.primary : "#FFFFFF",
                marginLeft: 8,
              }}
            >
              {loading ? "Starting..." : "Start Mission"}
            </Text>
          </TouchableOpacity>
        )}

        {status === "in_progress" && !showProofSection && (
          <TouchableOpacity
            style={{
              backgroundColor: colors.green,
              borderRadius: 16,
              paddingVertical: 18,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
            }}
            onPress={() => setShowProofSection(true)}
          >
            <Send size={20} color={isDark ? colors.primary : "#FFFFFF"} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: isDark ? colors.primary : "#FFFFFF",
                marginLeft: 8,
              }}
            >
              Request Completion
            </Text>
          </TouchableOpacity>
        )}

        {status === "in_progress" && showProofSection && (
          <TouchableOpacity
            style={{
              backgroundColor: colors.purple,
              borderRadius: 16,
              paddingVertical: 18,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
              opacity: loading ? 0.6 : 1,
            }}
            onPress={handleRequestCompletion}
            disabled={loading}
          >
            <Send size={20} color={isDark ? colors.primary : "#FFFFFF"} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: isDark ? colors.primary : "#FFFFFF",
                marginLeft: 8,
              }}
            >
              {loading ? "Submitting..." : "Submit for Approval"}
            </Text>
          </TouchableOpacity>
        )}

        {status === "pending_approval" && (
          <View
            style={{
              backgroundColor: colors.yellowLight,
              borderRadius: 16,
              paddingVertical: 18,
              paddingHorizontal: 20,
              alignItems: "center",
              borderWidth: 2,
              borderColor: colors.yellow,
            }}
          >
            <HourglassIcon size={24} color={colors.yellow} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginTop: 8,
                textAlign: "center",
              }}
            >
              Waiting for Parent Approval
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontFamily: "Montserrat_500Medium",
                color: colors.secondary,
                marginTop: 4,
                textAlign: "center",
              }}
            >
              Your parent will review and approve your mission soon!
            </Text>
          </View>
        )}

        {status === "approved" && (
          <View
            style={{
              backgroundColor: colors.greenLight,
              borderRadius: 16,
              paddingVertical: 18,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
              borderWidth: 2,
              borderColor: colors.green,
            }}
          >
            <CheckCircle size={20} color={colors.green} />
            <Text
              style={{
                fontSize: 16,
                fontFamily: "Montserrat_600SemiBold",
                color: colors.primary,
                marginLeft: 8,
              }}
            >
              Mission Completed! 🎉
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
