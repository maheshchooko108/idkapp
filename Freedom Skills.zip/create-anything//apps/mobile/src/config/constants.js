// App-wide configuration constants

// Replace with actual Stripe Payment Link when ready
export const DONATION_URL = "https://example.com/donate";

// Add other app constants here as needed
export const APP_NAME = "Freedom Skills";
export const APP_VERSION = "1.0.0";
