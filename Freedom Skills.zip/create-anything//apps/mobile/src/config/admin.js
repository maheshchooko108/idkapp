// Admin configuration

// Allowlist of admin emails
// Add admin emails here to grant admin access
export const ADMIN_EMAILS = [
  "jim@example.com", // Replace with actual admin email
  "mahesh@example.com", // Replace with actual admin email
  // Add more admin emails as needed
];

// Check if an email is an admin
export function isAdminEmail(email) {
  if (!email) return false;
  return ADMIN_EMAILS.includes(email.toLowerCase());
}
